import type {
  CapabilitySnapshot,
  MembershipSummary,
  OrganizationSummary,
  SessionSnapshot
} from "@daftar/types";

export type PlatformClientOptions = {
  baseUrl: string;
  headers?: HeadersInit;
  credentials?: RequestCredentials;
};

export class PlatformClient {
  constructor(private readonly options: PlatformClientOptions) {}

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await fetch(`${this.options.baseUrl}${path}`, {
      credentials: this.options.credentials ?? "include",
      ...init,
      headers: {
        "content-type": "application/json",
        ...(this.options.headers ?? {}),
        ...(init?.headers ?? {})
      }
    });

    if (!response.ok) {
      throw new Error(`Request failed: ${response.status}`);
    }

    return (await response.json()) as T;
  }

  session() {
    return this.request<SessionSnapshot>("/v1/auth/session");
  }

  me() {
    return this.request<SessionSnapshot["user"]>("/v1/me");
  }

  organizations() {
    return this.request<OrganizationSummary[]>("/v1/organizations");
  }

  currentOrganization() {
    return this.request<OrganizationSummary | null>("/v1/organizations/current");
  }

  memberships() {
    return this.request<MembershipSummary[]>("/v1/memberships");
  }

  capabilities() {
    return this.request<CapabilitySnapshot>("/v1/rbac/capabilities");
  }

  switchOrganization(orgSlug: string) {
    return this.request<OrganizationSummary>("/v1/organizations/switch", {
      method: "POST",
      body: JSON.stringify({ orgSlug })
    });
  }
}
