import request from "supertest";
import type { INestApplication } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { loadEnv } from "@daftar/config";
import { createApp } from "./bootstrap";

describe.sequential("Daftar Week 4 release blockers", () => {
  const env = loadEnv();
  const prisma = new PrismaClient({
    datasources: {
      db: {
        url: env.DATABASE_URL
      }
    }
  });
  let app: INestApplication;

  async function signIn(email: string) {
    const response = await request(app.getHttpServer())
      .post("/v1/auth/sign-in")
      .send({ email, password: "Password123!" })
      .expect(201);

    const cookies = response.headers["set-cookie"];
    return Array.isArray(cookies) ? cookies : [cookies].filter(Boolean);
  }

  async function switchOrg(cookies: string[], orgSlug: string) {
    await request(app.getHttpServer())
      .post("/v1/organizations/switch")
      .set("Cookie", cookies)
      .send({ orgSlug })
      .expect(201);
  }

  beforeAll(async () => {
    app = await createApp();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
    await prisma.$disconnect();
  });

  it("validates connector bootstrap import job execution, retry handling, and tenant isolation across Xero, QuickBooks Online, and Zoho Books", async () => {
    const cookies = await signIn("owner@daftar.local");
    await switchOrg(cookies, "nomad-events");

    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const labsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-labs" }
    });
    const expectedImportedNames = [
      `${eventsOrg.name} QBO Customer`,
      `${eventsOrg.name} Xero Customer`,
      `${eventsOrg.name} Zoho Contact`
    ];
    const xeroAccount = await prisma.connectorAccount.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, provider: "XERO" }
    });
    const qboAccount = await prisma.connectorAccount.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, provider: "QUICKBOOKS_ONLINE" }
    });
    const zohoAccount = await prisma.connectorAccount.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, provider: "ZOHO_BOOKS" }
    });
    const failedQboLog = await prisma.connectorSyncLog.findFirstOrThrow({
      where: {
        organizationId: eventsOrg.id,
        connectorAccountId: qboAccount.id,
        status: "FAILED"
      }
    });

    const accountsBefore = await request(app.getHttpServer())
      .get("/v1/connectors/accounts")
      .set("Cookie", cookies)
      .expect(200);
    expect(accountsBefore.body.length).toBe(3);

    await request(app.getHttpServer())
      .patch(`/v1/connectors/accounts/${qboAccount.id}`)
      .set("Cookie", cookies)
      .send({
        status: "CONNECTED",
        externalTenantId: "qbo-events-prod"
      })
      .expect(200);
    await request(app.getHttpServer())
      .patch(`/v1/connectors/accounts/${zohoAccount.id}`)
      .set("Cookie", cookies)
      .send({
        status: "CONNECTED",
        externalTenantId: "zoho-events-prod"
      })
      .expect(200);

    const labsImportedBefore = await prisma.contact.count({
      where: {
        organizationId: labsOrg.id,
        displayName: {
          in: expectedImportedNames
        }
      }
    });

    const exportPreview = await request(app.getHttpServer())
      .get(`/v1/connectors/accounts/${xeroAccount.id}/export-preview`)
      .set("Cookie", cookies)
      .expect(200);
    expect(exportPreview.body.provider).toBe("XERO");

    const exportRun = await request(app.getHttpServer())
      .post(`/v1/connectors/accounts/${xeroAccount.id}/sync`)
      .set("Cookie", cookies)
      .send({ direction: "EXPORT", scope: "contacts,invoices,bills,quotes,assets" })
      .expect(201);
    expect(exportRun.body.status).toBe("SUCCESS");

    const xeroImport = await request(app.getHttpServer())
      .post(`/v1/connectors/accounts/${xeroAccount.id}/sync`)
      .set("Cookie", cookies)
      .send({ direction: "IMPORT", scope: "bootstrap-import" })
      .expect(201);
    const qboImport = await request(app.getHttpServer())
      .post(`/v1/connectors/accounts/${qboAccount.id}/sync`)
      .set("Cookie", cookies)
      .send({ direction: "IMPORT", scope: "bootstrap-import" })
      .expect(201);
    const zohoImport = await request(app.getHttpServer())
      .post(`/v1/connectors/accounts/${zohoAccount.id}/sync`)
      .set("Cookie", cookies)
      .send({ direction: "IMPORT", scope: "bootstrap-import" })
      .expect(201);

    expect(xeroImport.body.status).toBe("SUCCESS");
    expect(qboImport.body.status).toBe("SUCCESS");
    expect(zohoImport.body.status).toBe("SUCCESS");

    const retriedImport = await request(app.getHttpServer())
      .post(`/v1/connectors/logs/${failedQboLog.id}/retry`)
      .set("Cookie", cookies)
      .expect(201);
    expect(retriedImport.body.status).toBe("SUCCESS");

    const importedContacts = await prisma.contact.findMany({
      where: {
        organizationId: eventsOrg.id,
        displayName: {
          in: expectedImportedNames
        }
      },
      orderBy: { displayName: "asc" }
    });
    const importedTaxRates = await prisma.taxRate.findMany({
      where: {
        organizationId: eventsOrg.id,
        name: {
          in: ["Xero VAT 15", "QBO VAT 15", "Zoho VAT 15"]
        }
      },
      orderBy: { name: "asc" }
    });
    const importedAccounts = await prisma.account.findMany({
      where: {
        organizationId: eventsOrg.id,
        code: {
          in: ["4190", "5290", "1390"]
        }
      },
      orderBy: { code: "asc" }
    });
    const qboLogs = await request(app.getHttpServer())
      .get(`/v1/connectors/logs?connectorAccountId=${qboAccount.id}`)
      .set("Cookie", cookies)
      .expect(200);

    expect(importedContacts.map((contact) => contact.displayName)).toEqual(expectedImportedNames);
    expect(importedTaxRates.map((taxRate) => taxRate.name)).toEqual([
      "QBO VAT 15",
      "Xero VAT 15",
      "Zoho VAT 15"
    ]);
    expect(importedAccounts.map((account) => account.code)).toEqual(["1390", "4190", "5290"]);
    expect(qboLogs.body.some((log: { status: string; direction: string }) => log.status === "SUCCESS" && log.direction === "IMPORT")).toBe(true);

    const labsImportedAfter = await prisma.contact.count({
      where: {
        organizationId: labsOrg.id,
        displayName: {
          in: expectedImportedNames
        }
      }
    });
    expect(labsImportedBefore).toBe(0);
    expect(labsImportedAfter).toBe(0);
  });

  it("validates Stripe plans, subscription lifecycle, webhook handling, invoice history, and tenant isolation", async () => {
    const cookies = await signIn("owner@daftar.local");
    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const labsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-labs" }
    });

    await prisma.billingInvoice.deleteMany({ where: { organizationId: labsOrg.id } });
    await prisma.stripeSubscription.deleteMany({ where: { organizationId: labsOrg.id } });
    await prisma.stripeCustomer.deleteMany({ where: { organizationId: labsOrg.id } });

    await switchOrg(cookies, "nomad-labs");

    const plans = await request(app.getHttpServer())
      .get("/v1/billing/plans")
      .set("Cookie", cookies)
      .expect(200);
    expect(plans.body.map((plan: { code: string }) => plan.code)).toEqual([
      "STARTER",
      "GROWTH",
      "SCALE"
    ]);

    const createdSubscription = await request(app.getHttpServer())
      .post("/v1/billing/subscription")
      .set("Cookie", cookies)
      .send({
        stripeCustomerId: "cus_NL_release",
        billingEmail: "billing@nomad-labs.example",
        subscriptionId: "sub_NL_release",
        planCode: "STARTER",
        status: "TRIALING",
        seats: 3,
        currentPeriodStart: "2026-05-01T00:00:00.000Z",
        currentPeriodEnd: "2026-05-31T23:59:59.000Z",
        cancelAtPeriodEnd: false
      })
      .expect(201);
    expect(createdSubscription.body.planCode).toBe("STARTER");

    const updatedSubscription = await request(app.getHttpServer())
      .patch("/v1/billing/subscription")
      .set("Cookie", cookies)
      .send({
        planCode: "GROWTH",
        status: "ACTIVE",
        seats: 6
      })
      .expect(200);
    expect(updatedSubscription.body.planCode).toBe("GROWTH");
    expect(updatedSubscription.body.seats).toBe(6);

    const canceledSubscription = await request(app.getHttpServer())
      .post("/v1/billing/subscription/cancel")
      .set("Cookie", cookies)
      .send({ immediate: false })
      .expect(201);
    expect(canceledSubscription.body.status).toBe("CANCELED");
    expect(canceledSubscription.body.cancelAtPeriodEnd).toBe(true);

    const webhookUpdated = await request(app.getHttpServer())
      .post("/v1/billing/webhooks/stripe")
      .set("x-stripe-signature", env.STRIPE_WEBHOOK_SECRET)
      .send({
        type: "customer.subscription.updated",
        data: {
          organizationId: labsOrg.id,
          stripeCustomerId: "cus_NL_release",
          stripeSubscriptionId: "sub_NL_release",
          billingEmail: "finance@nomad-labs.example",
          planCode: "SCALE",
          status: "ACTIVE",
          seats: 8,
          currentPeriodStart: "2026-06-01T00:00:00.000Z",
          currentPeriodEnd: "2026-06-30T23:59:59.000Z",
          cancelAtPeriodEnd: false
        }
      })
      .expect(201);
    expect(webhookUpdated.body.status).toBe("ACTIVE");

    await request(app.getHttpServer())
      .post("/v1/billing/webhooks/stripe")
      .set("x-stripe-signature", env.STRIPE_WEBHOOK_SECRET)
      .send({
        type: "invoice.payment_failed",
        data: {
          stripeSubscriptionId: "sub_NL_release",
          invoice: {
            stripeInvoiceId: "in_NL_release_1",
            invoiceNumber: "SUB-NL-REL-0001",
            status: "open",
            total: "199.00",
            currencyCode: "USD",
            issuedAt: "2026-06-01T00:00:00.000Z",
            dueAt: "2026-06-05T00:00:00.000Z",
            hostedInvoiceUrl: "https://billing.daftar.local/sub-nl-rel-0001"
          }
        }
      })
      .expect(201);

    const webhookPaid = await request(app.getHttpServer())
      .post("/v1/billing/webhooks/stripe")
      .set("x-stripe-signature", env.STRIPE_WEBHOOK_SECRET)
      .send({
        type: "invoice.paid",
        data: {
          stripeSubscriptionId: "sub_NL_release",
          invoice: {
            stripeInvoiceId: "in_NL_release_1",
            invoiceNumber: "SUB-NL-REL-0001",
            status: "paid",
            total: "199.00",
            currencyCode: "USD",
            issuedAt: "2026-06-01T00:00:00.000Z",
            dueAt: "2026-06-05T00:00:00.000Z",
            paidAt: "2026-06-03T00:00:00.000Z",
            hostedInvoiceUrl: "https://billing.daftar.local/sub-nl-rel-0001"
          }
        }
      })
      .expect(201);
    expect(webhookPaid.body.status).toBe("ACTIVE");

    await request(app.getHttpServer())
      .post("/v1/billing/webhooks/stripe")
      .set("x-stripe-signature", env.STRIPE_WEBHOOK_SECRET)
      .send({
        type: "customer.subscription.deleted",
        data: {
          stripeSubscriptionId: "sub_NL_release"
        }
      })
      .expect(201);

    const labsSummary = await request(app.getHttpServer())
      .get("/v1/billing/summary")
      .set("Cookie", cookies)
      .expect(200);
    const labsInvoices = await request(app.getHttpServer())
      .get("/v1/billing/invoices")
      .set("Cookie", cookies)
      .expect(200);

    expect(labsSummary.body.planCode).toBe("SCALE");
    expect(labsSummary.body.status).toBe("CANCELED");
    expect(labsInvoices.body.some((invoice: { invoiceNumber: string; status: string }) => invoice.invoiceNumber === "SUB-NL-REL-0001" && invoice.status === "paid")).toBe(true);

    await switchOrg(cookies, "nomad-events");
    const eventsSummary = await request(app.getHttpServer())
      .get("/v1/billing/summary")
      .set("Cookie", cookies)
      .expect(200);
    expect(eventsSummary.body.subscriptionId).toBe("sub_NE_growth");
    expect(eventsSummary.body.planCode).toBe("GROWTH");
    expect(eventsSummary.body.stripeCustomerId).not.toBe("cus_NL_release");
  });

  it("validates repeating invoice and repeating bill run behavior", async () => {
    const cookies = await signIn("admin@daftar.local");
    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const customer = await prisma.contact.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, isCustomer: true }
    });
    const supplier = await prisma.contact.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, isSupplier: true }
    });
    const vatRate = await prisma.taxRate.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, code: "VAT15" }
    });

    const invoiceCountBefore = await prisma.salesInvoice.count({
      where: { organizationId: eventsOrg.id }
    });
    const billCountBefore = await prisma.purchaseBill.count({
      where: { organizationId: eventsOrg.id }
    });

    const repeatingInvoice = await request(app.getHttpServer())
      .post("/v1/sales/repeating-invoices")
      .set("Cookie", cookies)
      .send({
        contactId: customer.id,
        templateName: "Release Validation Invoice",
        status: "ACTIVE",
        frequencyLabel: "Monthly",
        intervalCount: 1,
        nextRunAt: "2026-06-10T09:00:00.000Z",
        currencyCode: "SAR",
        notes: "Release validation repeating invoice",
        lines: [
          {
            description: "Support retainer",
            quantity: "1",
            unitPrice: "300.00",
            taxRateId: vatRate.id
          }
        ]
      })
      .expect(201);

    const invoiceRun = await request(app.getHttpServer())
      .post(`/v1/sales/repeating-invoices/${repeatingInvoice.body.id}/run`)
      .set("Cookie", cookies)
      .send({ runAt: "2026-06-10T09:00:00.000Z" })
      .expect(201);
    expect(invoiceRun.body.invoice.status).toBe("ISSUED");
    expect(invoiceRun.body.schedule.nextRunAt).toBe("2026-07-10T09:00:00.000Z");

    const repeatingBill = await request(app.getHttpServer())
      .post("/v1/purchases/repeating-bills")
      .set("Cookie", cookies)
      .send({
        contactId: supplier.id,
        templateName: "Release Validation Bill",
        status: "ACTIVE",
        frequencyLabel: "Monthly",
        intervalCount: 1,
        nextRunAt: "2026-06-11T09:00:00.000Z",
        currencyCode: "SAR",
        notes: "Release validation repeating bill",
        lines: [
          {
            description: "Facilities retainer",
            quantity: "1",
            unitPrice: "200.00",
            taxRateId: vatRate.id
          }
        ]
      })
      .expect(201);

    const billRun = await request(app.getHttpServer())
      .post(`/v1/purchases/repeating-bills/${repeatingBill.body.id}/run`)
      .set("Cookie", cookies)
      .send({ runAt: "2026-06-11T09:00:00.000Z" })
      .expect(201);
    expect(billRun.body.bill.status).toBe("APPROVED");
    expect(billRun.body.schedule.nextRunAt).toBe("2026-07-11T09:00:00.000Z");

    const invoiceCountAfter = await prisma.salesInvoice.count({
      where: { organizationId: eventsOrg.id }
    });
    const billCountAfter = await prisma.purchaseBill.count({
      where: { organizationId: eventsOrg.id }
    });
    const auditLogs = await prisma.auditLog.findMany({
      where: {
        organizationId: eventsOrg.id,
        action: {
          in: ["sales.repeating_invoice.run", "purchases.repeating_bill.run"]
        }
      }
    });

    expect(invoiceCountAfter).toBe(invoiceCountBefore + 1);
    expect(billCountAfter).toBe(billCountBefore + 1);
    expect(auditLogs.length).toBeGreaterThanOrEqual(2);
  });

  it("validates journal-backed consistency for extended reports and charts on live data", async () => {
    const cookies = await signIn("admin@daftar.local");

    const reports = await request(app.getHttpServer())
      .get("/v1/reports/dashboard")
      .set("Cookie", cookies)
      .expect(200);
    const charts = await request(app.getHttpServer())
      .get("/v1/charts/dashboard")
      .set("Cookie", cookies)
      .expect(200);

    expect(Number(reports.body.balanceSheet.assets)).toBeCloseTo(
      Number(reports.body.balanceSheet.liabilities) +
        Number(reports.body.balanceSheet.equity),
      2
    );
    expect(reports.body.trialBalance.totalDebit).toBe(reports.body.trialBalance.totalCredit);
    expect(Number(reports.body.expenseBreakdown.totalExpenses)).toBeCloseTo(
      Number(reports.body.expenseBreakdown.billsExpense) +
        Number(reports.body.expenseBreakdown.depreciationExpense),
      2
    );
    expect(charts.body.balanceChart).toEqual([
      { label: "Assets", value: reports.body.balanceSheet.assets },
      { label: "Liabilities", value: reports.body.balanceSheet.liabilities },
      { label: "Equity", value: reports.body.balanceSheet.equity }
    ]);
    expect(charts.body.expenses.length).toBeGreaterThanOrEqual(3);
  });
});
