import request from "supertest";
import type { INestApplication } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { loadEnv } from "@daftar/config";
import { createApp } from "./bootstrap";

describe.sequential("Daftar Week 3 accounting core", () => {
  const prisma = new PrismaClient({
    datasources: {
      db: {
        url: loadEnv().DATABASE_URL
      }
    }
  });
  let app: INestApplication;

  async function signIn(email: string) {
    const response = await request(app.getHttpServer())
      .post("/v1/auth/sign-in")
      .send({ email, password: "Password123!" })
      .expect(201);

    return response.headers["set-cookie"];
  }

  beforeAll(async () => {
    app = await createApp();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
    await prisma.$disconnect();
  });

  it("supports sales invoices end to end including compliance reporting", async () => {
    const cookies = await signIn("admin@daftar.local");
    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const otherOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-labs" }
    });
    const customer = await prisma.contact.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, isCustomer: true }
    });
    const vatRate = await prisma.taxRate.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, code: "VAT15" }
    });
    const otherOrgInvoice = await prisma.salesInvoice.findFirstOrThrow({
      where: { organizationId: otherOrg.id }
    });

    const invoicesBefore = await request(app.getHttpServer())
      .get("/v1/sales/invoices")
      .set("Cookie", cookies)
      .expect(200);
    expect(invoicesBefore.body.length).toBeGreaterThanOrEqual(2);

    const createdInvoice = await request(app.getHttpServer())
      .post("/v1/sales/invoices")
      .set("Cookie", cookies)
      .send({
        contactId: customer.id,
        invoiceNumber: "INV-NE-0901",
        status: "ISSUED",
        complianceInvoiceKind: "STANDARD",
        issueDate: "2026-04-12T09:00:00.000Z",
        dueDate: "2026-04-22T09:00:00.000Z",
        currencyCode: "SAR",
        notes: "Week 3 test invoice",
        lines: [
          {
            description: "Implementation sprint",
            quantity: "2",
            unitPrice: "500.00",
            taxRateId: vatRate.id
          }
        ]
      })
      .expect(201);
    expect(createdInvoice.body.total).toBe("1150.00");
    expect(createdInvoice.body.status).toBe("ISSUED");

    const updatedInvoice = await request(app.getHttpServer())
      .patch(`/v1/sales/invoices/${createdInvoice.body.id}`)
      .set("Cookie", cookies)
      .send({
        notes: "Week 3 test invoice updated"
      })
      .expect(200);
    expect(updatedInvoice.body.notes).toContain("updated");

    const paidInvoice = await request(app.getHttpServer())
      .post(`/v1/sales/invoices/${createdInvoice.body.id}/payments`)
      .set("Cookie", cookies)
      .send({
        paymentDate: "2026-04-13T09:00:00.000Z",
        amount: "300.00",
        method: "Bank Transfer",
        reference: "WK3-PMT-001",
        notes: "Partial payment"
      })
      .expect(201);
    expect(paidInvoice.body.status).toBe("PARTIALLY_PAID");
    expect(paidInvoice.body.amountDue).toBe("850.00");

    const complianceDocument = await request(app.getHttpServer())
      .post(`/v1/compliance/invoices/${createdInvoice.body.id}/report`)
      .set("Cookie", cookies)
      .expect(201);
    expect(complianceDocument.body.status).toBe("REPORTED");

    const invoiceDetail = await request(app.getHttpServer())
      .get(`/v1/sales/invoices/${createdInvoice.body.id}`)
      .set("Cookie", cookies)
      .expect(200);
    expect(invoiceDetail.body.compliance.status).toBe("REPORTED");
    expect(invoiceDetail.body.statusEvents.length).toBeGreaterThanOrEqual(3);

    const reportedDocuments = await request(app.getHttpServer())
      .get("/v1/compliance/reported-documents")
      .set("Cookie", cookies)
      .expect(200);
    expect(
      reportedDocuments.body.some(
        (document: { documentNumber: string }) =>
          document.documentNumber === "INV-NE-0901"
      )
    ).toBe(true);

    await request(app.getHttpServer())
      .get(`/v1/sales/invoices/${otherOrgInvoice.id}`)
      .set("Cookie", cookies)
      .expect(404);

    const auditLogs = await prisma.auditLog.findMany({
      where: {
        organizationId: eventsOrg.id,
        action: {
          in: [
            "sales.invoice.create",
            "sales.invoice.update",
            "sales.invoice.payment",
            "compliance.invoice.report"
          ]
        }
      }
    });
    expect(auditLogs.length).toBeGreaterThanOrEqual(4);
  });

  it("supports purchases end to end", async () => {
    const cookies = await signIn("admin@daftar.local");
    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const supplier = await prisma.contact.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, isSupplier: true }
    });
    const vatRate = await prisma.taxRate.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, code: "VAT15" }
    });

    const createdBill = await request(app.getHttpServer())
      .post("/v1/purchases/bills")
      .set("Cookie", cookies)
      .send({
        contactId: supplier.id,
        billNumber: "BILL-NE-0901",
        status: "APPROVED",
        issueDate: "2026-04-12T09:00:00.000Z",
        dueDate: "2026-04-24T09:00:00.000Z",
        currencyCode: "SAR",
        notes: "Week 3 vendor bill",
        lines: [
          {
            description: "Production support",
            quantity: "1",
            unitPrice: "750.00",
            taxRateId: vatRate.id
          }
        ]
      })
      .expect(201);
    expect(createdBill.body.total).toBe("862.50");
    expect(createdBill.body.status).toBe("APPROVED");

    const updatedBill = await request(app.getHttpServer())
      .patch(`/v1/purchases/bills/${createdBill.body.id}`)
      .set("Cookie", cookies)
      .send({
        notes: "Week 3 vendor bill updated"
      })
      .expect(200);
    expect(updatedBill.body.notes).toContain("updated");

    const paidBill = await request(app.getHttpServer())
      .post(`/v1/purchases/bills/${createdBill.body.id}/payments`)
      .set("Cookie", cookies)
      .send({
        paymentDate: "2026-04-14T09:00:00.000Z",
        amount: "862.50",
        method: "Bank Transfer",
        reference: "WK3-BILL-001",
        notes: "Settled in full"
      })
      .expect(201);
    expect(paidBill.body.status).toBe("PAID");
    expect(paidBill.body.amountDue).toBe("0.00");
  });

  it("supports quotes end to end including conversion to invoice", async () => {
    const cookies = await signIn("admin@daftar.local");
    const eventsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-events" }
    });
    const customer = await prisma.contact.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, isCustomer: true }
    });
    const zeroRate = await prisma.taxRate.findFirstOrThrow({
      where: { organizationId: eventsOrg.id, code: "ZERO" }
    });

    const createdQuote = await request(app.getHttpServer())
      .post("/v1/quotes")
      .set("Cookie", cookies)
      .send({
        contactId: customer.id,
        quoteNumber: "QUO-NE-0901",
        status: "SENT",
        issueDate: "2026-04-12T09:00:00.000Z",
        expiryDate: "2026-04-29T09:00:00.000Z",
        currencyCode: "SAR",
        notes: "Week 3 client quote",
        lines: [
          {
            description: "Discovery workshop",
            quantity: "1",
            unitPrice: "900.00",
            taxRateId: zeroRate.id
          }
        ]
      })
      .expect(201);
    expect(createdQuote.body.total).toBe("900.00");

    const updatedQuote = await request(app.getHttpServer())
      .patch(`/v1/quotes/${createdQuote.body.id}`)
      .set("Cookie", cookies)
      .send({
        notes: "Week 3 client quote updated"
      })
      .expect(200);
    expect(updatedQuote.body.notes).toContain("updated");

    const conversion = await request(app.getHttpServer())
      .post(`/v1/quotes/${createdQuote.body.id}/convert`)
      .set("Cookie", cookies)
      .expect(201);
    expect(conversion.body.invoiceId).toBeTruthy();
    expect(conversion.body.quote.status).toBe("CONVERTED");

    const convertedInvoice = await request(app.getHttpServer())
      .get(`/v1/sales/invoices/${conversion.body.invoiceId}`)
      .set("Cookie", cookies)
      .expect(200);
    expect(convertedInvoice.body.status).toBe("DRAFT");

    const auditLogs = await prisma.auditLog.findMany({
      where: {
        organizationId: eventsOrg.id,
        action: {
          in: ["quotes.quote.create", "quotes.quote.update", "quotes.quote.convert"]
        }
      }
    });
    expect(auditLogs.length).toBeGreaterThanOrEqual(3);
  });

  it("returns live core-v1 reports and charts data and enforces read-only permissions", async () => {
    const cookies = await signIn("viewer@daftar.local");
    const labsOrg = await prisma.organization.findUniqueOrThrow({
      where: { slug: "nomad-labs" }
    });
    const labsInvoice = await prisma.salesInvoice.findFirstOrThrow({
      where: { organizationId: labsOrg.id }
    });
    const labsCustomer = await prisma.contact.findFirstOrThrow({
      where: { organizationId: labsOrg.id, isCustomer: true }
    });

    const reports = await request(app.getHttpServer())
      .get("/v1/reports/dashboard")
      .set("Cookie", cookies)
      .expect(200);
    expect(Number(reports.body.executiveSummary.totalSales)).toBeGreaterThan(0);
    expect(reports.body.contactTransactions.length).toBeGreaterThan(0);

    const charts = await request(app.getHttpServer())
      .get("/v1/charts/dashboard")
      .set("Cookie", cookies)
      .expect(200);
    expect(charts.body.bankBalances.length).toBeGreaterThan(0);
    expect(charts.body.salesPurchases.length).toBeGreaterThan(0);

    const compliance = await request(app.getHttpServer())
      .get("/v1/compliance/overview")
      .set("Cookie", cookies)
      .expect(200);
    expect(compliance.body.totalReportedDocuments).toBeGreaterThanOrEqual(1);

    await request(app.getHttpServer())
      .post("/v1/sales/invoices")
      .set("Cookie", cookies)
      .send({
        contactId: labsCustomer.id,
        status: "DRAFT",
        complianceInvoiceKind: "STANDARD",
        issueDate: "2026-04-12T09:00:00.000Z",
        dueDate: "2026-04-20T09:00:00.000Z",
        currencyCode: "USD",
        lines: [{ description: "Forbidden", quantity: "1", unitPrice: "10.00" }]
      })
      .expect(403);

    await request(app.getHttpServer())
      .post(`/v1/compliance/invoices/${labsInvoice.id}/report`)
      .set("Cookie", cookies)
      .expect(403);
  });
});
