import { Controller, Get, Inject, UseGuards } from "@nestjs/common";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { ReportsService } from "./reports.service";

@Controller("v1/reports")
@UseGuards(AuthenticatedGuard)
export class ReportsController {
  private readonly reportsService: ReportsService;

  constructor(@Inject(ReportsService) reportsService: ReportsService) {
    this.reportsService = reportsService;
  }

  @Get("dashboard")
  getDashboard(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "shell.reports.read");
    return this.reportsService.getDashboard(session!.organization!.id);
  }
}
