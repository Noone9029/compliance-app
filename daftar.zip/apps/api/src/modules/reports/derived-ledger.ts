import type {
  BalanceSheetRecord,
  TrialBalanceLineRecord,
  TrialBalanceRecord
} from "@daftar/types";

export type DerivedLedgerInput = {
  cash: number;
  receivables: number;
  fixedAssets: number;
  accumulatedDepreciation: number;
  payables: number;
  revenue: number;
  billExpenses: number;
  depreciationExpense: number;
};

type LedgerCategory = "ASSET" | "LIABILITY" | "EQUITY" | "REVENUE" | "EXPENSE";

export type DerivedLedgerLine = TrialBalanceLineRecord & {
  category: LedgerCategory;
};

function money(value: number) {
  return value.toFixed(2);
}

function accountBalance(line: DerivedLedgerLine) {
  switch (line.category) {
    case "ASSET":
      return Number(line.debit) - Number(line.credit);
    case "LIABILITY":
      return Number(line.credit) - Number(line.debit);
    case "EQUITY":
      return Number(line.credit) - Number(line.debit);
    case "REVENUE":
      return Number(line.credit) - Number(line.debit);
    case "EXPENSE":
      return Number(line.debit) - Number(line.credit);
  }
}

export function buildDerivedLedger(input: DerivedLedgerInput): {
  lines: DerivedLedgerLine[];
  balanceSheet: BalanceSheetRecord;
  trialBalance: TrialBalanceRecord;
} {
  const lines: DerivedLedgerLine[] = [
    {
      accountCode: "1000",
      accountName: "Cash at Bank",
      category: "ASSET",
      debit: money(input.cash),
      credit: "0.00"
    },
    {
      accountCode: "1100",
      accountName: "Accounts Receivable",
      category: "ASSET",
      debit: money(input.receivables),
      credit: "0.00"
    },
    {
      accountCode: "1200",
      accountName: "Fixed Assets",
      category: "ASSET",
      debit: money(input.fixedAssets),
      credit: "0.00"
    },
    {
      accountCode: "1700",
      accountName: "Accumulated Depreciation",
      category: "ASSET",
      debit: "0.00",
      credit: money(input.accumulatedDepreciation)
    },
    {
      accountCode: "2000",
      accountName: "Accounts Payable",
      category: "LIABILITY",
      debit: "0.00",
      credit: money(input.payables)
    },
    {
      accountCode: "4000",
      accountName: "Sales Revenue",
      category: "REVENUE",
      debit: "0.00",
      credit: money(input.revenue)
    },
    {
      accountCode: "5100",
      accountName: "Bills Expense",
      category: "EXPENSE",
      debit: money(input.billExpenses),
      credit: "0.00"
    },
    {
      accountCode: "5200",
      accountName: "Depreciation Expense",
      category: "EXPENSE",
      debit: money(input.depreciationExpense),
      credit: "0.00"
    }
  ];

  let totalDebit = lines.reduce((sum, line) => sum + Number(line.debit), 0);
  let totalCredit = lines.reduce((sum, line) => sum + Number(line.credit), 0);
  const difference = Number((totalDebit - totalCredit).toFixed(2));

  if (difference > 0) {
    lines.push({
      accountCode: "3000",
      accountName: "Owner Equity",
      category: "EQUITY",
      debit: "0.00",
      credit: money(difference)
    });
    totalCredit += difference;
  } else if (difference < 0) {
    lines.push({
      accountCode: "3000",
      accountName: "Owner Equity",
      category: "EQUITY",
      debit: money(Math.abs(difference)),
      credit: "0.00"
    });
    totalDebit += Math.abs(difference);
  }

  const assets = lines
    .filter((line) => line.category === "ASSET")
    .reduce((sum, line) => sum + accountBalance(line), 0);
  const liabilities = lines
    .filter((line) => line.category === "LIABILITY")
    .reduce((sum, line) => sum + accountBalance(line), 0);
  const equity = lines.reduce((sum, line) => {
    if (line.category === "ASSET" || line.category === "LIABILITY") {
      return sum;
    }

    return sum + (Number(line.credit) - Number(line.debit));
  }, 0);

  return {
    lines,
    balanceSheet: {
      assets: money(assets),
      liabilities: money(liabilities),
      equity: money(equity)
    },
    trialBalance: {
      lines: lines.map(({ category, ...line }) => line),
      totalDebit: money(totalDebit),
      totalCredit: money(totalCredit)
    }
  };
}
