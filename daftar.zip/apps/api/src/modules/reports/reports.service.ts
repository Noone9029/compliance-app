import { Inject, Injectable } from "@nestjs/common";
import type {
  BalanceSheetRecord,
  BankSummaryRecord,
  BudgetSummaryRecord,
  ContactTransactionRecord,
  ExpenseBreakdownRecord,
  ExecutiveSummaryRecord,
  PayablesReceivablesRecord,
  ProfitLossRecord,
  ReportsDashboardRecord,
  SalesPurchasesSeriesPoint,
  SalesTaxReportRecord,
  TrialBalanceRecord
} from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";
import { buildDerivedLedger } from "./derived-ledger";

function money(value: { toString(): string } | string | number | null | undefined) {
  return Number(value ?? 0).toFixed(2);
}

@Injectable()
export class ReportsService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async getDashboard(organizationId: string): Promise<ReportsDashboardRecord> {
    const [
      executiveSummary,
      salesTax,
      payablesReceivables,
      profitLoss,
      bankSummary,
      budgetSummary,
      expenseBreakdown,
      balanceSheet,
      trialBalance,
      salesPurchasesSeries,
      contactTransactions,
      reportedDocuments
    ] = await Promise.all([
      this.getExecutiveSummary(organizationId),
      this.getSalesTax(organizationId),
      this.getPayablesReceivables(organizationId),
      this.getProfitLoss(organizationId),
      this.getBankSummary(organizationId),
      this.getBudgetSummary(organizationId),
      this.getExpenseBreakdown(organizationId),
      this.getBalanceSheet(organizationId),
      this.getTrialBalance(organizationId),
      this.getSalesPurchasesSeries(organizationId),
      this.getContactTransactions(organizationId),
      this.prisma.reportedDocument.findMany({
        where: { organizationId },
        orderBy: { submittedAt: "desc" },
        take: 10
      })
    ]);

    return {
      executiveSummary,
      salesTax,
      payablesReceivables,
      profitLoss,
      bankSummary,
      budgetSummary,
      expenseBreakdown,
      balanceSheet,
      trialBalance,
      salesPurchasesSeries,
      contactTransactions,
      reportedDocuments: reportedDocuments.map((document) => ({
        id: document.id,
        organizationId: document.organizationId,
        salesInvoiceId: document.salesInvoiceId,
        complianceDocumentId: document.complianceDocumentId,
        documentNumber: document.documentNumber,
        status: document.status,
        responseCode: document.responseCode,
        responseMessage: document.responseMessage,
        submittedAt: document.submittedAt.toISOString(),
        createdAt: document.createdAt.toISOString()
      }))
    };
  }

  private async getExecutiveSummary(
    organizationId: string
  ): Promise<ExecutiveSummaryRecord> {
    const [sales, purchases, quotes, reportedDocuments] = await Promise.all([
      this.prisma.salesInvoice.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { total: true, amountDue: true }
      }),
      this.prisma.purchaseBill.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { total: true, amountDue: true }
      }),
      this.prisma.quote.count({
        where: { organizationId, status: "DRAFT" }
      }),
      this.prisma.reportedDocument.count({
        where: { organizationId }
      })
    ]);

    return {
      totalSales: money(sales._sum.total),
      totalPurchases: money(purchases._sum.total),
      receivables: money(sales._sum.amountDue),
      payables: money(purchases._sum.amountDue),
      reportedDocumentsCount: reportedDocuments,
      draftQuotesCount: quotes
    };
  }

  private async getSalesTax(organizationId: string): Promise<SalesTaxReportRecord> {
    const invoices = await this.prisma.salesInvoice.aggregate({
      where: {
        organizationId,
        status: {
          notIn: ["DRAFT", "VOID"]
        }
      },
      _sum: { subtotal: true, taxTotal: true },
      _count: { id: true }
    });

    return {
      taxableSales: money(invoices._sum.subtotal),
      taxCollected: money(invoices._sum.taxTotal),
      invoiceCount: invoices._count.id
    };
  }

  private async getPayablesReceivables(
    organizationId: string
  ): Promise<PayablesReceivablesRecord> {
    const [sales, bills] = await Promise.all([
      this.prisma.salesInvoice.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { amountDue: true }
      }),
      this.prisma.purchaseBill.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { amountDue: true }
      })
    ]);

    return {
      totalReceivables: money(sales._sum.amountDue),
      totalPayables: money(bills._sum.amountDue),
      overdueReceivables: money(sales._sum.amountDue),
      unpaidBills: money(bills._sum.amountDue)
    };
  }

  private async getProfitLoss(organizationId: string): Promise<ProfitLossRecord> {
    const [sales, expenseBreakdown] = await Promise.all([
      this.prisma.salesInvoice.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { total: true }
      }),
      this.getExpenseBreakdown(organizationId)
    ]);

    const revenue = Number(sales._sum.total ?? 0);
    const expenses = Number(expenseBreakdown.totalExpenses);

    return {
      revenue: revenue.toFixed(2),
      expenses: expenses.toFixed(2),
      profit: (revenue - expenses).toFixed(2)
    };
  }

  private async getBankSummary(organizationId: string): Promise<BankSummaryRecord> {
    const [bankAccounts, invoicePayments, billPayments] = await Promise.all([
      this.prisma.bankAccount.aggregate({
        where: { organizationId, isActive: true },
        _sum: { openingBalance: true },
        _count: { id: true }
      }),
      this.prisma.invoicePayment.aggregate({
        where: {
          salesInvoice: { organizationId }
        },
        _sum: { amount: true }
      }),
      this.prisma.billPayment.aggregate({
        where: {
          purchaseBill: { organizationId }
        },
        _sum: { amount: true }
      })
    ]);

    const opening = Number(bankAccounts._sum.openingBalance ?? 0);
    const inflow = Number(invoicePayments._sum.amount ?? 0);
    const outflow = Number(billPayments._sum.amount ?? 0);

    return {
      totalOpeningBalance: opening.toFixed(2),
      estimatedCurrentBalance: (opening + inflow - outflow).toFixed(2),
      accountCount: bankAccounts._count.id
    };
  }

  private async getBudgetSummary(organizationId: string): Promise<BudgetSummaryRecord> {
    const [repeatingInvoices, repeatingBills] = await Promise.all([
      this.prisma.repeatingInvoice.aggregate({
        where: { organizationId, status: "ACTIVE" },
        _sum: { total: true },
        _count: { id: true }
      }),
      this.prisma.repeatingBill.aggregate({
        where: { organizationId, status: "ACTIVE" },
        _sum: { total: true },
        _count: { id: true }
      })
    ]);

    const projectedRevenue = Number(repeatingInvoices._sum.total ?? 0);
    const projectedExpenses = Number(repeatingBills._sum.total ?? 0);

    return {
      projectedMonthlyRevenue: projectedRevenue.toFixed(2),
      projectedMonthlyExpenses: projectedExpenses.toFixed(2),
      projectedMonthlyNet: (projectedRevenue - projectedExpenses).toFixed(2),
      activeRepeatingInvoices: repeatingInvoices._count.id,
      activeRepeatingBills: repeatingBills._count.id
    };
  }

  private async getExpenseBreakdown(
    organizationId: string
  ): Promise<ExpenseBreakdownRecord> {
    const [bills, depreciation] = await Promise.all([
      this.prisma.purchaseBill.aggregate({
        where: { organizationId, status: { not: "VOID" } },
        _sum: { total: true }
      }),
      this.prisma.depreciationRun.aggregate({
        where: { organizationId },
        _sum: { depreciationAmount: true }
      })
    ]);

    const billsExpense = Number(bills._sum.total ?? 0);
    const depreciationExpense = Number(depreciation._sum.depreciationAmount ?? 0);

    return {
      billsExpense: billsExpense.toFixed(2),
      depreciationExpense: depreciationExpense.toFixed(2),
      totalExpenses: (billsExpense + depreciationExpense).toFixed(2)
    };
  }

  private async getBalanceSheet(organizationId: string): Promise<BalanceSheetRecord> {
    return (await this.getDerivedLedger(organizationId)).balanceSheet;
  }

  private async getTrialBalance(organizationId: string): Promise<TrialBalanceRecord> {
    return (await this.getDerivedLedger(organizationId)).trialBalance;
  }

  private async getSalesPurchasesSeries(
    organizationId: string
  ): Promise<SalesPurchasesSeriesPoint[]> {
    const [sales, purchases, quotes] = await Promise.all([
      this.prisma.salesInvoice.findMany({
        where: { organizationId, status: { not: "VOID" } },
        select: { issueDate: true, total: true }
      }),
      this.prisma.purchaseBill.findMany({
        where: { organizationId, status: { not: "VOID" } },
        select: { issueDate: true, total: true }
      }),
      this.prisma.quote.findMany({
        where: { organizationId },
        select: { issueDate: true, total: true }
      })
    ]);

    const bucket = new Map<string, SalesPurchasesSeriesPoint>();

    function ensure(label: string) {
      if (!bucket.has(label)) {
        bucket.set(label, {
          label,
          salesTotal: "0.00",
          purchasesTotal: "0.00",
          quotesTotal: "0.00"
        });
      }

      return bucket.get(label)!;
    }

    for (const invoice of sales) {
      const label = invoice.issueDate.toISOString().slice(0, 7);
      const point = ensure(label);
      point.salesTotal = (Number(point.salesTotal) + Number(invoice.total)).toFixed(2);
    }

    for (const bill of purchases) {
      const label = bill.issueDate.toISOString().slice(0, 7);
      const point = ensure(label);
      point.purchasesTotal = (Number(point.purchasesTotal) + Number(bill.total)).toFixed(2);
    }

    for (const quote of quotes) {
      const label = quote.issueDate.toISOString().slice(0, 7);
      const point = ensure(label);
      point.quotesTotal = (Number(point.quotesTotal) + Number(quote.total)).toFixed(2);
    }

    return Array.from(bucket.values()).sort((left, right) =>
      left.label.localeCompare(right.label)
    );
  }

  private async getContactTransactions(
    organizationId: string
  ): Promise<ContactTransactionRecord[]> {
    const contacts = await this.prisma.contact.findMany({
      where: {
        organizationId,
        OR: [{ isCustomer: true }, { isSupplier: true }]
      },
      orderBy: { displayName: "asc" },
      include: {
        _count: {
          select: {
            salesInvoices: true,
            purchaseBills: true
          }
        }
      },
      take: 10
    });

    return contacts.map((contact) => ({
      contactId: contact.id,
      contactName: contact.displayName,
      receivableBalance: money(contact.receivableBalance),
      payableBalance: money(contact.payableBalance),
      salesCount: contact._count.salesInvoices,
      billCount: contact._count.purchaseBills
    }));
  }

  private async getDerivedLedger(organizationId: string) {
    const [bankSummary, payablesReceivables, sales, bills, fixedAssets, depreciation] =
      await Promise.all([
        this.getBankSummary(organizationId),
        this.getPayablesReceivables(organizationId),
        this.prisma.salesInvoice.aggregate({
          where: { organizationId, status: { not: "VOID" } },
          _sum: { total: true }
        }),
        this.prisma.purchaseBill.aggregate({
          where: { organizationId, status: { not: "VOID" } },
          _sum: { total: true }
        }),
        this.prisma.fixedAsset.aggregate({
          where: { organizationId, status: { not: "DISPOSED" } },
          _sum: {
            cost: true,
            accumulatedDepreciation: true
          }
        }),
        this.prisma.depreciationRun.aggregate({
          where: { organizationId },
          _sum: { depreciationAmount: true }
        })
      ]);

    return buildDerivedLedger({
      cash: Number(bankSummary.estimatedCurrentBalance),
      receivables: Number(payablesReceivables.totalReceivables),
      fixedAssets: Number(fixedAssets._sum.cost ?? 0),
      accumulatedDepreciation: Number(fixedAssets._sum.accumulatedDepreciation ?? 0),
      payables: Number(payablesReceivables.totalPayables),
      revenue: Number(sales._sum.total ?? 0),
      billExpenses: Number(bills._sum.total ?? 0),
      depreciationExpense: Number(depreciation._sum.depreciationAmount ?? 0)
    });
  }
}
