import { describe, expect, it } from "vitest";

import { buildDerivedLedger } from "./derived-ledger";

describe("derived-ledger", () => {
  it("keeps trial balance debits and credits aligned", () => {
    const ledger = buildDerivedLedger({
      cash: 5000,
      receivables: 1200,
      fixedAssets: 8000,
      accumulatedDepreciation: 500,
      payables: 1500,
      revenue: 6200,
      billExpenses: 1800,
      depreciationExpense: 500
    });

    expect(ledger.trialBalance.totalDebit).toBe(ledger.trialBalance.totalCredit);
  });

  it("keeps balance sheet assets equal to liabilities plus equity", () => {
    const ledger = buildDerivedLedger({
      cash: 4000,
      receivables: 900,
      fixedAssets: 6000,
      accumulatedDepreciation: 600,
      payables: 1100,
      revenue: 5100,
      billExpenses: 1700,
      depreciationExpense: 600
    });

    expect(Number(ledger.balanceSheet.assets)).toBeCloseTo(
      Number(ledger.balanceSheet.liabilities) + Number(ledger.balanceSheet.equity),
      2
    );
  });

  it("includes revenue, expense, and balancing equity lines for extended report validation", () => {
    const ledger = buildDerivedLedger({
      cash: 3200,
      receivables: 400,
      fixedAssets: 2500,
      accumulatedDepreciation: 200,
      payables: 300,
      revenue: 4100,
      billExpenses: 900,
      depreciationExpense: 200
    });

    expect(ledger.trialBalance.lines.some((line) => line.accountCode === "4000")).toBe(true);
    expect(ledger.trialBalance.lines.some((line) => line.accountCode === "5100")).toBe(true);
    expect(ledger.trialBalance.lines.some((line) => line.accountCode === "3000")).toBe(true);
  });
});
