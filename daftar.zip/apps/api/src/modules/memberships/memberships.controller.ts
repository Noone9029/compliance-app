import { Controller, Get, Inject, UseGuards } from "@nestjs/common";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { MembershipsService } from "./memberships.service";

@Controller("v1/memberships")
export class MembershipsController {
  private readonly membershipsService: MembershipsService;

  constructor(@Inject(MembershipsService) membershipsService: MembershipsService) {
    this.membershipsService = membershipsService;
  }

  @Get()
  @UseGuards(AuthenticatedGuard)
  async list(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    return this.membershipsService.listForUser(session!.user!.id);
  }
}
