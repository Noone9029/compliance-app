import { Inject, Injectable } from "@nestjs/common";
import type { MembershipSummary } from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";

@Injectable()
export class MembershipsService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async listForUser(userId: string): Promise<MembershipSummary[]> {
    const memberships = await this.prisma.membership.findMany({
      where: { userId },
      include: { organization: true, role: true },
      orderBy: { createdAt: "asc" }
    });

    return memberships.map((membership) => ({
      id: membership.id,
      organizationId: membership.organizationId,
      organizationName: membership.organization.name,
      organizationSlug: membership.organization.slug,
      roleKey: membership.role.key,
      status: membership.status
    }));
  }
}
