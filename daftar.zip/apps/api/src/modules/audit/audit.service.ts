import { Inject, Injectable } from "@nestjs/common";
import type { AuditActorType, AuditResult, Prisma } from "@prisma/client";

import { PrismaService } from "../../common/prisma/prisma.service";

export type AuditLogInput = {
  organizationId?: string | null;
  actorType: AuditActorType;
  actorUserId?: string | null;
  action: string;
  targetType: string;
  targetId?: string | null;
  result?: AuditResult;
  requestId?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  metadata?: Record<string, unknown> | null;
};

@Injectable()
export class AuditService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async log(event: AuditLogInput) {
    return this.prisma.auditLog.create({
      data: {
        organizationId: event.organizationId ?? null,
        actorType: event.actorType,
        actorUserId: event.actorUserId ?? null,
        action: event.action,
        targetType: event.targetType,
        targetId: event.targetId ?? null,
        result: event.result ?? "INFO",
        requestId: event.requestId ?? null,
        ipAddress: event.ipAddress ?? null,
        userAgent: event.userAgent ?? null,
        metadata: (event.metadata ?? undefined) as Prisma.InputJsonValue | undefined
      }
    });
  }
}
