import { Module } from "@nestjs/common";

import { AuditModule } from "../audit/audit.module";
import { QuickBooksAdapter } from "./quickbooks.adapter";
import { XeroAdapter } from "./xero.adapter";
import { ZohoBooksAdapter } from "./zoho-books.adapter";
import { ConnectorsController } from "./connectors.controller";
import { ConnectorsService } from "./connectors.service";

@Module({
  imports: [AuditModule],
  controllers: [ConnectorsController],
  providers: [ConnectorsService, XeroAdapter, QuickBooksAdapter, ZohoBooksAdapter],
  exports: [ConnectorsService]
})
export class ConnectorsModule {}
