import { Inject, Injectable, NotFoundException } from "@nestjs/common";
import { Prisma } from "@prisma/client";
import type {
  ConnectorAccountRecord,
  ConnectorSyncLogRecord,
  ConnectorSyncPreviewRecord
} from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";
import type {
  ConnectorAdapter,
  ConnectorBootstrapImportBundle,
  ConnectorCanonicalExportRecord
} from "./connector-adapter";
import { QuickBooksAdapter } from "./quickbooks.adapter";
import { XeroAdapter } from "./xero.adapter";
import { ZohoBooksAdapter } from "./zoho-books.adapter";

@Injectable()
export class ConnectorsService {
  private readonly prisma: PrismaService;
  private readonly adapters: Map<string, ConnectorAdapter>;

  constructor(
    @Inject(PrismaService) prisma: PrismaService,
    @Inject(XeroAdapter) xeroAdapter: XeroAdapter,
    @Inject(QuickBooksAdapter) quickBooksAdapter: QuickBooksAdapter,
    @Inject(ZohoBooksAdapter) zohoBooksAdapter: ZohoBooksAdapter
  ) {
    this.prisma = prisma;
    this.adapters = new Map(
      [xeroAdapter, quickBooksAdapter, zohoBooksAdapter].map((adapter) => [
        adapter.provider,
        adapter
      ])
    );
  }

  async listAccounts(organizationId: string): Promise<ConnectorAccountRecord[]> {
    const accounts = await this.prisma.connectorAccount.findMany({
      where: { organizationId },
      orderBy: { provider: "asc" }
    });

    return accounts.map((account) => this.mapAccount(account));
  }

  async createAccount(
    organizationId: string,
    userId: string,
    input: {
      provider: "XERO" | "QUICKBOOKS_ONLINE" | "ZOHO_BOOKS";
      displayName: string;
      status: "PENDING" | "CONNECTED" | "DISCONNECTED" | "ERROR";
      externalTenantId?: string | null;
      scopes: string[];
      metadata?: Record<string, unknown> | null;
    }
  ): Promise<ConnectorAccountRecord> {
    const account = await this.prisma.connectorAccount.create({
      data: {
        organizationId,
        provider: input.provider,
        displayName: input.displayName,
        status: input.status,
        externalTenantId: input.externalTenantId ?? null,
        scopes: input.scopes,
        connectedByUserId: userId,
        connectedAt: input.status === "CONNECTED" ? new Date() : null,
        metadata: (input.metadata ?? undefined) as Prisma.InputJsonValue | undefined
      }
    });

    return this.mapAccount(account);
  }

  async updateAccount(
    organizationId: string,
    connectorAccountId: string,
    input: Partial<{
      displayName: string;
      status: "PENDING" | "CONNECTED" | "DISCONNECTED" | "ERROR";
      externalTenantId: string | null;
      scopes: string[];
      metadata: Record<string, unknown> | null;
      lastSyncedAt: string | null;
    }>
  ): Promise<ConnectorAccountRecord> {
    await this.ensureAccount(organizationId, connectorAccountId);

    const account = await this.prisma.connectorAccount.update({
      where: { id: connectorAccountId },
      data: {
        displayName: input.displayName,
        status: input.status,
        externalTenantId: input.externalTenantId,
        scopes: input.scopes,
        metadata: (input.metadata ?? undefined) as Prisma.InputJsonValue | undefined,
        connectedAt:
          input.status === "CONNECTED" ? new Date() : input.status ? null : undefined,
        lastSyncedAt: input.lastSyncedAt ? new Date(input.lastSyncedAt) : undefined
      }
    });

    return this.mapAccount(account);
  }

  async listLogs(
    organizationId: string,
    connectorAccountId?: string
  ): Promise<ConnectorSyncLogRecord[]> {
    const logs = await this.prisma.connectorSyncLog.findMany({
      where: {
        organizationId,
        ...(connectorAccountId ? { connectorAccountId } : {})
      },
      orderBy: { createdAt: "desc" }
    });

    return logs.map((log) => ({
      id: log.id,
      organizationId: log.organizationId,
      connectorAccountId: log.connectorAccountId,
      direction: log.direction,
      scope: log.scope,
      status: log.status,
      retryable: log.retryable,
      message: log.message,
      startedAt: log.startedAt.toISOString(),
      finishedAt: log.finishedAt?.toISOString() ?? null,
      createdAt: log.createdAt.toISOString()
    }));
  }

  async getExportPreview(
    organizationId: string,
    connectorAccountId: string
  ): Promise<ConnectorSyncPreviewRecord> {
    const account = await this.ensureAccount(organizationId, connectorAccountId);
    const adapter = this.getAdapter(account.provider);
    const counts = await this.getSnapshotCounts(organizationId);

    return adapter.buildPreview({
      connectorAccountId,
      direction: "EXPORT",
      ...counts
    });
  }

  async runSync(
    organizationId: string,
    connectorAccountId: string,
    input: {
      direction: "IMPORT" | "EXPORT";
      scope?: string | null;
    }
  ): Promise<ConnectorSyncLogRecord> {
    const account = await this.ensureAccount(organizationId, connectorAccountId);

    if (account.status !== "CONNECTED") {
      const failedLog = await this.prisma.connectorSyncLog.create({
        data: {
          organizationId,
          connectorAccountId,
          direction: input.direction,
          scope: input.scope ?? "full-export",
          status: "FAILED",
          retryable: true,
          message: "Connector account must be connected before sync can run.",
          startedAt: new Date(),
          finishedAt: new Date(),
          metadata: { status: account.status }
        }
      });

      return this.mapLog(failedLog);
    }

    const adapter = this.getAdapter(account.provider);
    const startedAt = new Date();
    const pendingLog = await this.prisma.connectorSyncLog.create({
      data: {
        organizationId,
        connectorAccountId,
        direction: input.direction,
        scope: input.scope ?? (input.direction === "IMPORT" ? "bootstrap-import" : "full-export"),
        status: "PENDING",
        retryable: true,
        message:
          input.direction === "IMPORT"
            ? "Bootstrap import job created."
            : "Export sync job created.",
        startedAt
      }
    });

    try {
      if (input.direction === "IMPORT") {
        const result = await this.runBootstrapImport(organizationId, account.provider);
        const finishedLog = await this.prisma.connectorSyncLog.update({
          where: { id: pendingLog.id },
          data: {
            status: "SUCCESS",
            retryable: false,
            message: adapter.buildImportSuccessMessage(3),
            finishedAt: new Date(),
            metadata: {
              phase: "bootstrap-import",
              imported: result.imported,
              canonicalPreview: result.canonicalPreview
            } as Prisma.InputJsonValue
          }
        });

        await this.prisma.connectorAccount.update({
          where: { id: connectorAccountId },
          data: {
            lastSyncedAt: new Date(),
            metadata: {
              ...(account.metadata as Record<string, unknown> | null),
              lastBootstrapImport: result.imported
            }
          }
        });

        return this.mapLog(finishedLog);
      }

      const preview = await this.getExportPreview(organizationId, connectorAccountId);
      const exportSnapshot = await this.getCanonicalExportSnapshot(organizationId);
      const finishedLog = await this.prisma.connectorSyncLog.update({
        where: { id: pendingLog.id },
        data: {
          scope: input.scope ?? preview.scopes.map((entry) => entry.scope).join(", "),
          status: "SUCCESS",
          retryable: false,
          message: adapter.buildSuccessMessage(preview.scopes.length),
          finishedAt: new Date(),
          metadata: {
            preview,
            exportRecords: exportSnapshot.map((record) =>
              adapter.mapCanonicalExportRecord(record)
            )
          } as Prisma.InputJsonValue
        }
      });

      await this.prisma.connectorAccount.update({
        where: { id: connectorAccountId },
        data: {
          lastSyncedAt: new Date(),
          metadata: {
            ...(account.metadata as Record<string, unknown> | null),
            lastPreview: preview
          }
        }
      });

      return this.mapLog(finishedLog);
    } catch (error) {
      const failedLog = await this.prisma.connectorSyncLog.update({
        where: { id: pendingLog.id },
        data: {
          status: "FAILED",
          retryable: true,
          message: error instanceof Error ? error.message : "Connector sync failed.",
          finishedAt: new Date()
        }
      });

      return this.mapLog(failedLog);
    }
  }

  async retryLog(
    organizationId: string,
    logId: string
  ): Promise<ConnectorSyncLogRecord> {
    const log = await this.prisma.connectorSyncLog.findFirst({
      where: { id: logId, organizationId }
    });

    if (!log) {
      throw new NotFoundException("Connector sync log not found.");
    }

    return this.runSync(organizationId, log.connectorAccountId, {
      direction: log.direction,
      scope: log.scope
    });
  }

  private getAdapter(provider: string) {
    const adapter = this.adapters.get(provider);

    if (!adapter) {
      throw new NotFoundException(`No connector adapter registered for ${provider}.`);
    }

    return adapter;
  }

  private async getSnapshotCounts(organizationId: string) {
    const [contactCount, invoiceCount, billCount, quoteCount, assetCount] =
      await Promise.all([
        this.prisma.contact.count({ where: { organizationId } }),
        this.prisma.salesInvoice.count({ where: { organizationId } }),
        this.prisma.purchaseBill.count({ where: { organizationId } }),
        this.prisma.quote.count({ where: { organizationId } }),
        this.prisma.fixedAsset.count({ where: { organizationId } })
      ]);

    return {
      contactCount,
      invoiceCount,
      billCount,
      quoteCount,
      assetCount
    };
  }

  private async getCanonicalExportSnapshot(
    organizationId: string
  ): Promise<ConnectorCanonicalExportRecord[]> {
    const [contact, invoice, bill, quote, asset] = await Promise.all([
      this.prisma.contact.findFirst({
        where: { organizationId },
        orderBy: { createdAt: "asc" }
      }),
      this.prisma.salesInvoice.findFirst({
        where: { organizationId },
        include: { contact: true },
        orderBy: { createdAt: "asc" }
      }),
      this.prisma.purchaseBill.findFirst({
        where: { organizationId },
        include: { contact: true },
        orderBy: { createdAt: "asc" }
      }),
      this.prisma.quote.findFirst({
        where: { organizationId },
        include: { contact: true },
        orderBy: { createdAt: "asc" }
      }),
      this.prisma.fixedAsset.findFirst({
        where: { organizationId },
        orderBy: { createdAt: "asc" }
      })
    ]);

    const records: ConnectorCanonicalExportRecord[] = [];
    if (contact) {
      records.push({
        entity: "contact",
        displayName: contact.displayName,
        email: contact.email,
        isCustomer: contact.isCustomer,
        isSupplier: contact.isSupplier,
        currencyCode: contact.currencyCode
      });
    }
    if (invoice) {
      records.push({
        entity: "invoice",
        documentNumber: invoice.invoiceNumber,
        contactName: invoice.contact.displayName,
        total: invoice.total.toString(),
        currencyCode: invoice.currencyCode,
        status: invoice.status
      });
    }
    if (bill) {
      records.push({
        entity: "bill",
        documentNumber: bill.billNumber,
        contactName: bill.contact.displayName,
        total: bill.total.toString(),
        currencyCode: bill.currencyCode,
        status: bill.status
      });
    }
    if (quote) {
      records.push({
        entity: "quote",
        documentNumber: quote.quoteNumber,
        contactName: quote.contact.displayName,
        total: quote.total.toString(),
        currencyCode: quote.currencyCode,
        status: quote.status
      });
    }
    if (asset) {
      records.push({
        entity: "asset",
        assetNumber: asset.assetNumber,
        name: asset.name,
        netBookValue: asset.netBookValue.toString(),
        currencyCode: "USD"
      });
    }

    return records;
  }

  private async runBootstrapImport(
    organizationId: string,
    provider: "XERO" | "QUICKBOOKS_ONLINE" | "ZOHO_BOOKS"
  ) {
    const organization = await this.prisma.organization.findUniqueOrThrow({
      where: { id: organizationId }
    });
    const baseCurrency = await this.prisma.currency.findFirst({
      where: { organizationId, isBase: true }
    });
    const adapter = this.getAdapter(provider);
    const payload = adapter.buildBootstrapImportPayload({
      organizationName: organization.name,
      organizationSlug: organization.slug,
      currencyCode: baseCurrency?.code ?? "USD"
    });
    const canonicalBundle = adapter.mapBootstrapImportPayload(payload);

    const imported = await this.prisma.$transaction(async (transaction) => {
      return this.upsertBootstrapImportRecords(
        transaction,
        organizationId,
        canonicalBundle
      );
    });

    return {
      imported,
      canonicalPreview: {
        contacts: canonicalBundle.contacts.length,
        taxRates: canonicalBundle.taxRates.length,
        accounts: canonicalBundle.accounts.length
      }
    };
  }

  private async upsertBootstrapImportRecords(
    transaction: Prisma.TransactionClient,
    organizationId: string,
    bundle: ConnectorBootstrapImportBundle
  ) {
    let contactCount = 0;
    let taxRateCount = 0;
    let accountCount = 0;

    for (const contact of bundle.contacts) {
      const existing = await transaction.contact.findFirst({
        where: {
          organizationId,
          displayName: contact.displayName
        }
      });

      if (existing) {
        await transaction.contact.update({
          where: { id: existing.id },
          data: {
            email: contact.email,
            isCustomer: contact.isCustomer,
            isSupplier: contact.isSupplier,
            currencyCode: contact.currencyCode
          }
        });
      } else {
        await transaction.contact.create({
          data: {
            organizationId,
            displayName: contact.displayName,
            email: contact.email,
            isCustomer: contact.isCustomer,
            isSupplier: contact.isSupplier,
            currencyCode: contact.currencyCode
          }
        });
      }

      contactCount += 1;
    }

    for (const taxRate of bundle.taxRates) {
      await transaction.taxRate.upsert({
        where: {
          organizationId_name: {
            organizationId,
            name: taxRate.name
          }
        },
        update: {
          code: taxRate.code,
          rate: taxRate.rate,
          scope: taxRate.scope
        },
        create: {
          organizationId,
          name: taxRate.name,
          code: taxRate.code,
          rate: taxRate.rate,
          scope: taxRate.scope
        }
      });
      taxRateCount += 1;
    }

    for (const account of bundle.accounts) {
      await transaction.account.upsert({
        where: {
          organizationId_code: {
            organizationId,
            code: account.code
          }
        },
        update: {
          name: account.name,
          type: account.type
        },
        create: {
          organizationId,
          code: account.code,
          name: account.name,
          type: account.type
        }
      });
      accountCount += 1;
    }

    return {
      contacts: contactCount,
      taxRates: taxRateCount,
      accounts: accountCount
    };
  }

  private async ensureAccount(organizationId: string, connectorAccountId: string) {
    const account = await this.prisma.connectorAccount.findFirst({
      where: { id: connectorAccountId, organizationId }
    });

    if (!account) {
      throw new NotFoundException("Connector account not found.");
    }

    return account;
  }

  private mapAccount(account: {
    id: string;
    organizationId: string;
    provider: "XERO" | "QUICKBOOKS_ONLINE" | "ZOHO_BOOKS";
    displayName: string;
    status: "PENDING" | "CONNECTED" | "DISCONNECTED" | "ERROR";
    externalTenantId: string | null;
    scopes: unknown;
    connectedAt: Date | null;
    lastSyncedAt: Date | null;
    metadata: unknown;
    createdAt: Date;
    updatedAt: Date;
  }): ConnectorAccountRecord {
    return {
      id: account.id,
      organizationId: account.organizationId,
      provider: account.provider,
      displayName: account.displayName,
      status: account.status,
      externalTenantId: account.externalTenantId,
      scopes: Array.isArray(account.scopes) ? (account.scopes as string[]) : [],
      connectedAt: account.connectedAt?.toISOString() ?? null,
      lastSyncedAt: account.lastSyncedAt?.toISOString() ?? null,
      metadata: (account.metadata as Record<string, unknown> | null) ?? null,
      createdAt: account.createdAt.toISOString(),
      updatedAt: account.updatedAt.toISOString()
    };
  }

  private mapLog(log: {
    id: string;
    organizationId: string;
    connectorAccountId: string;
    direction: "IMPORT" | "EXPORT";
    scope: string;
    status: "PENDING" | "SUCCESS" | "FAILED";
    retryable: boolean;
    message: string | null;
    startedAt: Date;
    finishedAt: Date | null;
    createdAt: Date;
  }): ConnectorSyncLogRecord {
    return {
      id: log.id,
      organizationId: log.organizationId,
      connectorAccountId: log.connectorAccountId,
      direction: log.direction,
      scope: log.scope,
      status: log.status,
      retryable: log.retryable,
      message: log.message,
      startedAt: log.startedAt.toISOString(),
      finishedAt: log.finishedAt?.toISOString() ?? null,
      createdAt: log.createdAt.toISOString()
    };
  }
}
