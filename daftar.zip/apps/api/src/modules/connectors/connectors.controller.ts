import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Patch,
  Post,
  Query,
  UseGuards
} from "@nestjs/common";
import {
  connectorAccountStatuses,
  connectorProviders
} from "@daftar/types";
import { z } from "zod";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { ConnectorsService } from "./connectors.service";

const connectorAccountSchema = z.object({
  provider: z.enum(connectorProviders),
  displayName: z.string().min(1),
  status: z.enum(connectorAccountStatuses),
  externalTenantId: z.string().optional().nullable(),
  scopes: z.array(z.string().min(1)).default([]),
  metadata: z.record(z.string(), z.unknown()).optional().nullable()
});

const connectorAccountPatchSchema = connectorAccountSchema
  .omit({ provider: true })
  .extend({
    lastSyncedAt: z.string().datetime().optional().nullable()
  })
  .partial()
  .refine((value) => Object.keys(value).length > 0, "At least one field is required.");

const connectorSyncSchema = z.object({
  direction: z.enum(["IMPORT", "EXPORT"]).default("EXPORT"),
  scope: z.string().optional().nullable()
});

@Controller("v1/connectors")
@UseGuards(AuthenticatedGuard)
export class ConnectorsController {
  private readonly connectorsService: ConnectorsService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(ConnectorsService) connectorsService: ConnectorsService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.connectorsService = connectorsService;
    this.auditService = auditService;
  }

  @Get("accounts")
  listAccounts(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "connectors.read");
    return this.connectorsService.listAccounts(session!.organization!.id);
  }

  @Post("accounts")
  async createAccount(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "connectors.write");
    const parsed = connectorAccountSchema.parse(body);
    const account = await this.connectorsService.createAccount(
      session!.organization!.id,
      session!.user!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "connectors.account.create",
      targetType: "connector_account",
      targetId: account.id,
      result: "SUCCESS"
    });
    return account;
  }

  @Patch("accounts/:connectorAccountId")
  async updateAccount(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("connectorAccountId") connectorAccountId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "connectors.write");
    const parsed = connectorAccountPatchSchema.parse(body);
    const account = await this.connectorsService.updateAccount(
      session!.organization!.id,
      connectorAccountId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "connectors.account.update",
      targetType: "connector_account",
      targetId: account.id,
      result: "SUCCESS"
    });
    return account;
  }

  @Get("logs")
  listLogs(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Query("connectorAccountId") connectorAccountId: string | undefined
  ) {
    requirePermission(session, "connectors.read");
    return this.connectorsService.listLogs(
      session!.organization!.id,
      connectorAccountId?.trim() || undefined
    );
  }

  @Get("accounts/:connectorAccountId/export-preview")
  getExportPreview(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("connectorAccountId") connectorAccountId: string
  ) {
    requirePermission(session, "connectors.read");
    return this.connectorsService.getExportPreview(
      session!.organization!.id,
      connectorAccountId
    );
  }

  @Post("accounts/:connectorAccountId/sync")
  async runSync(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("connectorAccountId") connectorAccountId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "connectors.sync");
    const parsed = connectorSyncSchema.parse(body ?? {});
    const log = await this.connectorsService.runSync(
      session!.organization!.id,
      connectorAccountId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "connectors.sync.run",
      targetType: "connector_account",
      targetId: connectorAccountId,
      result: log.status === "FAILED" ? "FAILURE" : "SUCCESS",
      metadata: {
        syncLogId: log.id,
        direction: log.direction,
        scope: log.scope
      }
    });
    return log;
  }

  @Post("logs/:logId/retry")
  async retryLog(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("logId") logId: string
  ) {
    requirePermission(session, "connectors.sync");
    const log = await this.connectorsService.retryLog(session!.organization!.id, logId);
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "connectors.sync.retry",
      targetType: "connector_sync_log",
      targetId: logId,
      result: log.status === "FAILED" ? "FAILURE" : "SUCCESS",
      metadata: {
        retryLogId: log.id
      }
    });
    return log;
  }
}
