import { Injectable } from "@nestjs/common";
import type { ConnectorSyncPreviewRecord } from "@daftar/types";

import type {
  ConnectorAdapter,
  ConnectorBootstrapContext,
  ConnectorBootstrapImportBundle,
  ConnectorCanonicalExportRecord,
  ConnectorPreviewInput
} from "./connector-adapter";

@Injectable()
export class QuickBooksAdapter implements ConnectorAdapter {
  provider = "QUICKBOOKS_ONLINE" as const;

  buildPreview(input: ConnectorPreviewInput): ConnectorSyncPreviewRecord {
    return {
      connectorAccountId: input.connectorAccountId,
      provider: this.provider,
      direction: input.direction,
      scopes: [
        { scope: "customers-and-vendors", recordCount: input.contactCount },
        { scope: "sales", recordCount: input.invoiceCount },
        { scope: "expenses", recordCount: input.billCount },
        { scope: "estimates", recordCount: input.quoteCount }
      ],
      generatedAt: new Date().toISOString()
    };
  }

  buildSuccessMessage(scopeCount: number) {
    return `QuickBooks Online export completed for ${scopeCount} scopes.`;
  }

  buildImportSuccessMessage(scopeCount: number) {
    return `QuickBooks Online bootstrap import completed for ${scopeCount} scopes.`;
  }

  buildBootstrapImportPayload(context: ConnectorBootstrapContext) {
    return {
      Customer: [
        {
          Id: `${context.organizationSlug}-qbo-customer`,
          DisplayName: `${context.organizationName} QBO Customer`,
          PrimaryEmailAddr: { Address: `qbo.${context.organizationSlug}@example.com` },
          CurrencyRef: { value: context.currencyCode }
        }
      ],
      TaxRate: [
        {
          Name: "QBO VAT 15",
          RateValue: "15.00",
          TaxReturnLineRef: "QBO15"
        }
      ],
      Account: [
        {
          AcctNum: "5290",
          Name: "QBO Operating Expense",
          AccountType: "EXPENSE"
        }
      ]
    };
  }

  mapBootstrapImportPayload(
    payload: Record<string, unknown>
  ): ConnectorBootstrapImportBundle {
    const contacts = Array.isArray(payload.Customer) ? payload.Customer : [];
    const taxRates = Array.isArray(payload.TaxRate) ? payload.TaxRate : [];
    const accounts = Array.isArray(payload.Account) ? payload.Account : [];

    return {
      contacts: contacts.map((entry) => {
        const contact = entry as Record<string, unknown>;
        const primaryEmail = contact.PrimaryEmailAddr as Record<string, unknown> | undefined;
        const currencyRef = contact.CurrencyRef as Record<string, unknown> | undefined;
        return {
          displayName: String(contact.DisplayName ?? "Imported QBO Contact"),
          email: primaryEmail?.Address ? String(primaryEmail.Address) : null,
          isCustomer: true,
          isSupplier: false,
          currencyCode: currencyRef?.value ? String(currencyRef.value) : null
        };
      }),
      taxRates: taxRates.map((entry) => {
        const taxRate = entry as Record<string, unknown>;
        return {
          name: String(taxRate.Name ?? "Imported QBO Tax"),
          code: String(taxRate.TaxReturnLineRef ?? "QBO"),
          rate: String(taxRate.RateValue ?? "0.00"),
          scope: "BOTH"
        };
      }),
      accounts: accounts.map((entry) => {
        const account = entry as Record<string, unknown>;
        return {
          code: String(account.AcctNum ?? "5100"),
          name: String(account.Name ?? "Imported QBO Account"),
          type: String(account.AccountType ?? "EXPENSE") as
            | "ASSET"
            | "LIABILITY"
            | "EQUITY"
            | "REVENUE"
            | "EXPENSE"
        };
      })
    };
  }

  mapCanonicalExportRecord(record: ConnectorCanonicalExportRecord) {
    switch (record.entity) {
      case "contact":
        return {
          DisplayName: record.displayName,
          PrimaryEmailAddr: record.email ? { Address: record.email } : null,
          Customer: record.isCustomer,
          Vendor: record.isSupplier,
          CurrencyRef: record.currencyCode ? { value: record.currencyCode } : null
        };
      case "invoice":
        return {
          DocNumber: record.documentNumber,
          CustomerRef: { name: record.contactName },
          TotalAmt: record.total,
          CurrencyRef: { value: record.currencyCode },
          PrivateNote: record.status
        };
      case "bill":
        return {
          DocNumber: record.documentNumber,
          VendorRef: { name: record.contactName },
          TotalAmt: record.total,
          CurrencyRef: { value: record.currencyCode },
          PrivateNote: record.status
        };
      case "quote":
        return {
          DocNumber: record.documentNumber,
          CustomerRef: { name: record.contactName },
          TotalAmt: record.total,
          CurrencyRef: { value: record.currencyCode },
          PrivateNote: record.status
        };
      case "asset":
        return {
          Name: record.name,
          AcctNum: record.assetNumber,
          CurrentBalance: record.netBookValue,
          CurrencyRef: { value: record.currencyCode }
        };
    }
  }
}
