import type {
  ConnectorProvider,
  ConnectorSyncPreviewRecord
} from "@daftar/types";

export type ConnectorPreviewInput = {
  connectorAccountId: string;
  direction: "EXPORT" | "IMPORT";
  contactCount: number;
  invoiceCount: number;
  billCount: number;
  quoteCount: number;
  assetCount: number;
};

export type ConnectorBootstrapContext = {
  organizationName: string;
  organizationSlug: string;
  currencyCode: string;
};

export type ConnectorCanonicalContact = {
  displayName: string;
  email: string | null;
  isCustomer: boolean;
  isSupplier: boolean;
  currencyCode: string | null;
};

export type ConnectorCanonicalTaxRate = {
  name: string;
  code: string;
  rate: string;
  scope: "BOTH";
};

export type ConnectorCanonicalAccount = {
  code: string;
  name: string;
  type: "ASSET" | "LIABILITY" | "EQUITY" | "REVENUE" | "EXPENSE";
};

export type ConnectorBootstrapImportBundle = {
  contacts: ConnectorCanonicalContact[];
  taxRates: ConnectorCanonicalTaxRate[];
  accounts: ConnectorCanonicalAccount[];
};

export type ConnectorCanonicalExportRecord =
  | {
      entity: "contact";
      displayName: string;
      email: string | null;
      isCustomer: boolean;
      isSupplier: boolean;
      currencyCode: string | null;
    }
  | {
      entity: "invoice";
      documentNumber: string;
      contactName: string;
      total: string;
      currencyCode: string;
      status: string;
    }
  | {
      entity: "bill";
      documentNumber: string;
      contactName: string;
      total: string;
      currencyCode: string;
      status: string;
    }
  | {
      entity: "quote";
      documentNumber: string;
      contactName: string;
      total: string;
      currencyCode: string;
      status: string;
    }
  | {
      entity: "asset";
      assetNumber: string;
      name: string;
      netBookValue: string;
      currencyCode: string;
    };

export interface ConnectorAdapter {
  provider: ConnectorProvider;
  buildPreview(input: ConnectorPreviewInput): ConnectorSyncPreviewRecord;
  buildSuccessMessage(scopeCount: number): string;
  buildImportSuccessMessage(scopeCount: number): string;
  buildBootstrapImportPayload(
    context: ConnectorBootstrapContext
  ): Record<string, unknown>;
  mapBootstrapImportPayload(
    payload: Record<string, unknown>
  ): ConnectorBootstrapImportBundle;
  mapCanonicalExportRecord(
    record: ConnectorCanonicalExportRecord
  ): Record<string, unknown>;
}
