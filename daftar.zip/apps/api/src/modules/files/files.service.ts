import { Inject, Injectable } from "@nestjs/common";
import type { StoredFileRecord } from "@daftar/types";
import { Prisma } from "@prisma/client";

import { loadEnv } from "@daftar/config";
import { PrismaService } from "../../common/prisma/prisma.service";

@Injectable()
export class FilesService {
  private readonly prisma: PrismaService;
  private readonly env = loadEnv();

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async listFiles(
    organizationId: string,
    options: {
      relatedType?: string;
      relatedId?: string;
    }
  ): Promise<StoredFileRecord[]> {
    const files = await this.prisma.storedFile.findMany({
      where: {
        organizationId,
        ...(options.relatedType ? { relatedType: options.relatedType } : {}),
        ...(options.relatedId ? { relatedId: options.relatedId } : {})
      },
      orderBy: { createdAt: "desc" }
    });

    return files.map((file) => ({
      id: file.id,
      organizationId: file.organizationId,
      storageProvider: file.storageProvider,
      bucket: file.bucket,
      objectKey: file.objectKey,
      originalFileName: file.originalFileName,
      mimeType: file.mimeType,
      sizeBytes: file.sizeBytes,
      checksumSha256: file.checksumSha256,
      relatedType: file.relatedType,
      relatedId: file.relatedId,
      metadata: (file.metadata as Record<string, unknown> | null) ?? null,
      createdAt: file.createdAt.toISOString()
    }));
  }

  async createFileMetadata(
    organizationId: string,
    uploadedByUserId: string,
    input: {
      originalFileName: string;
      mimeType: string;
      sizeBytes: number;
      checksumSha256?: string | null;
      relatedType?: string | null;
      relatedId?: string | null;
      metadata?: Record<string, unknown> | null;
    }
  ): Promise<StoredFileRecord> {
    const objectKey = `${organizationId}/${Date.now()}-${input.originalFileName.replace(/\s+/g, "-").toLowerCase()}`;

    const file = await this.prisma.storedFile.create({
      data: {
        organizationId,
        uploadedByUserId,
        storageProvider: "S3_COMPAT",
        bucket: this.env.S3_BUCKET,
        objectKey,
        originalFileName: input.originalFileName,
        mimeType: input.mimeType,
        sizeBytes: input.sizeBytes,
        checksumSha256: input.checksumSha256 ?? null,
        relatedType: input.relatedType ?? null,
        relatedId: input.relatedId ?? null,
        metadata: (input.metadata ?? undefined) as Prisma.InputJsonValue | undefined
      }
    });

    return {
      id: file.id,
      organizationId: file.organizationId,
      storageProvider: file.storageProvider,
      bucket: file.bucket,
      objectKey: file.objectKey,
      originalFileName: file.originalFileName,
      mimeType: file.mimeType,
      sizeBytes: file.sizeBytes,
      checksumSha256: file.checksumSha256,
      relatedType: file.relatedType,
      relatedId: file.relatedId,
      metadata: (file.metadata as Record<string, unknown> | null) ?? null,
      createdAt: file.createdAt.toISOString()
    };
  }
}
