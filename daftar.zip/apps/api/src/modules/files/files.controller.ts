import {
  Body,
  Controller,
  Get,
  Inject,
  Post,
  Query,
  UseGuards
} from "@nestjs/common";
import { z } from "zod";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { FilesService } from "./files.service";

const fileMetadataSchema = z.object({
  originalFileName: z.string().min(1),
  mimeType: z.string().min(1),
  sizeBytes: z.coerce.number().int().positive(),
  checksumSha256: z.string().optional().nullable(),
  relatedType: z.string().optional().nullable(),
  relatedId: z.string().optional().nullable(),
  metadata: z.record(z.string(), z.unknown()).optional().nullable()
});

@Controller("v1/files")
@UseGuards(AuthenticatedGuard)
export class FilesController {
  private readonly filesService: FilesService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(FilesService) filesService: FilesService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.filesService = filesService;
    this.auditService = auditService;
  }

  @Get()
  listFiles(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Query("relatedType") relatedType: string | undefined,
    @Query("relatedId") relatedId: string | undefined
  ) {
    requirePermission(session, "files.read");
    return this.filesService.listFiles(session!.organization!.id, {
      relatedType: relatedType?.trim() || undefined,
      relatedId: relatedId?.trim() || undefined
    });
  }

  @Post()
  async createFileMetadata(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "files.write");
    const parsed = fileMetadataSchema.parse(body);
    const file = await this.filesService.createFileMetadata(
      session!.organization!.id,
      session!.user!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "files.metadata.create",
      targetType: "stored_file",
      targetId: file.id,
      result: "SUCCESS"
    });
    return file;
  }
}
