import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import type {
  ComplianceInvoiceKind,
  SalesInvoiceDetail,
  SalesInvoiceSummary,
  SalesInvoiceStatus,
  StoredFileRecord
} from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";
import {
  calculateDocumentLines,
  determineInvoiceStatus,
  type DraftDocumentLine
} from "./document-calculations";

function money(value: { toString(): string } | string | number | null | undefined) {
  return Number(value ?? 0).toFixed(2);
}

function fileRecord(file: {
  id: string;
  organizationId: string;
  storageProvider: "S3_COMPAT";
  bucket: string;
  objectKey: string;
  originalFileName: string;
  mimeType: string;
  sizeBytes: number;
  checksumSha256: string | null;
  relatedType: string | null;
  relatedId: string | null;
  metadata: unknown;
  createdAt: Date;
}): StoredFileRecord {
  return {
    id: file.id,
    organizationId: file.organizationId,
    storageProvider: file.storageProvider,
    bucket: file.bucket,
    objectKey: file.objectKey,
    originalFileName: file.originalFileName,
    mimeType: file.mimeType,
    sizeBytes: file.sizeBytes,
    checksumSha256: file.checksumSha256,
    relatedType: file.relatedType,
    relatedId: file.relatedId,
    metadata: (file.metadata as Record<string, unknown> | null) ?? null,
    createdAt: file.createdAt.toISOString()
  };
}

@Injectable()
export class SalesService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async listInvoices(
    organizationId: string,
    options: {
      status?: SalesInvoiceStatus;
      search?: string;
    }
  ): Promise<SalesInvoiceSummary[]> {
    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        organizationId,
        ...(options.status ? { status: options.status } : {}),
        ...(options.search
          ? {
              OR: [
                { invoiceNumber: { contains: options.search, mode: "insensitive" } },
                { contact: { displayName: { contains: options.search, mode: "insensitive" } } }
              ]
            }
          : {})
      },
      include: {
        contact: true,
        complianceDocument: true
      },
      orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }]
    });

    return invoices.map((invoice) => ({
      id: invoice.id,
      organizationId: invoice.organizationId,
      contactId: invoice.contactId,
      contactName: invoice.contact.displayName,
      invoiceNumber: invoice.invoiceNumber,
      status: invoice.status,
      complianceInvoiceKind: invoice.complianceInvoiceKind,
      complianceStatus: invoice.complianceDocument?.status ?? null,
      issueDate: invoice.issueDate.toISOString(),
      dueDate: invoice.dueDate.toISOString(),
      currencyCode: invoice.currencyCode,
      subtotal: money(invoice.subtotal),
      taxTotal: money(invoice.taxTotal),
      total: money(invoice.total),
      amountPaid: money(invoice.amountPaid),
      amountDue: money(invoice.amountDue),
      createdAt: invoice.createdAt.toISOString(),
      updatedAt: invoice.updatedAt.toISOString()
    }));
  }

  async getInvoice(
    organizationId: string,
    invoiceId: string
  ): Promise<SalesInvoiceDetail> {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id: invoiceId, organizationId },
      include: {
        contact: true,
        lines: {
          orderBy: { sortOrder: "asc" }
        },
        payments: {
          orderBy: { paymentDate: "desc" }
        },
        statusEvents: {
          orderBy: { createdAt: "desc" }
        },
        complianceDocument: true
      }
    });

    if (!invoice) {
      throw new NotFoundException("Invoice not found.");
    }

    const attachments = await this.prisma.storedFile.findMany({
      where: {
        organizationId,
        relatedType: "sales-invoice",
        relatedId: invoiceId
      },
      orderBy: { createdAt: "desc" }
    });

    return {
      id: invoice.id,
      organizationId: invoice.organizationId,
      contactId: invoice.contactId,
      contactName: invoice.contact.displayName,
      invoiceNumber: invoice.invoiceNumber,
      status: invoice.status,
      complianceInvoiceKind: invoice.complianceInvoiceKind,
      complianceStatus: invoice.complianceDocument?.status ?? null,
      issueDate: invoice.issueDate.toISOString(),
      dueDate: invoice.dueDate.toISOString(),
      currencyCode: invoice.currencyCode,
      subtotal: money(invoice.subtotal),
      taxTotal: money(invoice.taxTotal),
      total: money(invoice.total),
      amountPaid: money(invoice.amountPaid),
      amountDue: money(invoice.amountDue),
      notes: invoice.notes,
      createdAt: invoice.createdAt.toISOString(),
      updatedAt: invoice.updatedAt.toISOString(),
      lines: invoice.lines.map((line) => ({
        id: line.id,
        description: line.description,
        quantity: money(line.quantity),
        unitPrice: money(line.unitPrice),
        taxRateId: line.taxRateId,
        taxRateName: line.taxRateName,
        taxRatePercent: money(line.taxRatePercent),
        lineSubtotal: money(line.lineSubtotal),
        lineTax: money(line.lineTax),
        lineTotal: money(line.lineTotal),
        sortOrder: line.sortOrder
      })),
      payments: invoice.payments.map((payment) => ({
        id: payment.id,
        paymentDate: payment.paymentDate.toISOString(),
        amount: money(payment.amount),
        method: payment.method,
        reference: payment.reference,
        notes: payment.notes,
        createdAt: payment.createdAt.toISOString()
      })),
      attachments: attachments.map(fileRecord),
      statusEvents: invoice.statusEvents.map((event) => ({
        id: event.id,
        action: event.action,
        fromStatus: event.fromStatus,
        toStatus: event.toStatus,
        message: event.message,
        actorUserId: event.actorUserId,
        createdAt: event.createdAt.toISOString()
      })),
      compliance: invoice.complianceDocument
        ? {
            id: invoice.complianceDocument.id,
            salesInvoiceId: invoice.complianceDocument.salesInvoiceId,
            invoiceKind: invoice.complianceDocument.invoiceKind,
            uuid: invoice.complianceDocument.uuid,
            qrPayload: invoice.complianceDocument.qrPayload,
            previousHash: invoice.complianceDocument.previousHash,
            currentHash: invoice.complianceDocument.currentHash,
            status: invoice.complianceDocument.status,
            lastSubmissionStatus:
              invoice.complianceDocument.lastSubmissionStatus ?? null,
            lastSubmittedAt:
              invoice.complianceDocument.lastSubmittedAt?.toISOString() ?? null,
            lastError: invoice.complianceDocument.lastError,
            createdAt: invoice.complianceDocument.createdAt.toISOString(),
            updatedAt: invoice.complianceDocument.updatedAt.toISOString()
          }
        : null
    };
  }

  async createInvoice(
    organizationId: string,
    userId: string,
    input: {
      contactId: string;
      invoiceNumber?: string | null;
      status: SalesInvoiceStatus;
      complianceInvoiceKind: ComplianceInvoiceKind;
      issueDate: string;
      dueDate: string;
      currencyCode: string;
      notes?: string | null;
      lines: DraftDocumentLine[];
    }
  ) {
    const contact = await this.prisma.contact.findFirst({
      where: {
        id: input.contactId,
        organizationId,
        isCustomer: true
      }
    });

    if (!contact) {
      throw new NotFoundException("Customer contact not found.");
    }

    const resolvedLines = await this.resolveLines(organizationId, input.lines);
    const totals = calculateDocumentLines(resolvedLines);
    const invoiceNumber =
      input.invoiceNumber?.trim() || (await this.nextInvoiceNumber(organizationId));

    const invoice = await this.prisma.salesInvoice.create({
      data: {
        organizationId,
        contactId: input.contactId,
        invoiceNumber,
        status: input.status,
        complianceInvoiceKind: input.complianceInvoiceKind,
        issueDate: new Date(input.issueDate),
        dueDate: new Date(input.dueDate),
        currencyCode: input.currencyCode.toUpperCase(),
        notes: input.notes ?? null,
        subtotal: totals.subtotal,
        taxTotal: totals.taxTotal,
        total: totals.total,
        amountPaid: "0.00",
        amountDue: totals.total,
        lines: {
          create: totals.lines
        },
        statusEvents: {
          create: {
            actorUserId: userId,
            action: "sales.invoice.created",
            toStatus: input.status,
            message: "Invoice created."
          }
        }
      }
    });

    await this.refreshContactBalances(organizationId, input.contactId);
    return this.getInvoice(organizationId, invoice.id);
  }

  async updateInvoice(
    organizationId: string,
    userId: string,
    invoiceId: string,
    input: Partial<{
      contactId: string;
      invoiceNumber: string | null;
      status: SalesInvoiceStatus;
      complianceInvoiceKind: ComplianceInvoiceKind;
      issueDate: string;
      dueDate: string;
      currencyCode: string;
      notes: string | null;
      lines: DraftDocumentLine[];
    }>
  ) {
    const existing = await this.prisma.salesInvoice.findFirst({
      where: { id: invoiceId, organizationId },
      include: {
        lines: true,
        payments: true
      }
    });

    if (!existing) {
      throw new NotFoundException("Invoice not found.");
    }

    const contactId = input.contactId ?? existing.contactId;
    const contact = await this.prisma.contact.findFirst({
      where: { id: contactId, organizationId, isCustomer: true }
    });

    if (!contact) {
      throw new NotFoundException("Customer contact not found.");
    }

    const sourceLines =
      input.lines ??
      existing.lines.map((line) => ({
        description: line.description,
        quantity: line.quantity.toString(),
        unitPrice: line.unitPrice.toString(),
        taxRateId: line.taxRateId,
        taxRateName: line.taxRateName,
        taxRatePercent: line.taxRatePercent.toString()
      }));

    const resolvedLines = await this.resolveLines(organizationId, sourceLines);
    const totals = calculateDocumentLines(resolvedLines);
    const amountPaid = existing.payments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0
    );
    const amountDue = Number(totals.total) - amountPaid;
    const nextStatus =
      input.status ??
      determineInvoiceStatus({
        currentStatus: existing.status,
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2)
      });

    await this.prisma.salesInvoice.update({
      where: { id: invoiceId },
      data: {
        contactId,
        invoiceNumber: input.invoiceNumber?.trim() || existing.invoiceNumber,
        status: nextStatus,
        complianceInvoiceKind:
          input.complianceInvoiceKind ?? existing.complianceInvoiceKind,
        issueDate: input.issueDate ? new Date(input.issueDate) : existing.issueDate,
        dueDate: input.dueDate ? new Date(input.dueDate) : existing.dueDate,
        currencyCode: input.currencyCode?.toUpperCase() ?? existing.currencyCode,
        notes: input.notes === undefined ? existing.notes : input.notes,
        subtotal: totals.subtotal,
        taxTotal: totals.taxTotal,
        total: totals.total,
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2)
      }
    });

    if (input.lines) {
      await this.prisma.salesInvoiceLine.deleteMany({
        where: { salesInvoiceId: invoiceId }
      });

      await this.prisma.salesInvoiceLine.createMany({
        data: totals.lines.map((line) => ({
          salesInvoiceId: invoiceId,
          ...line
        }))
      });
    }

    await this.prisma.invoiceStatusEvent.create({
      data: {
        salesInvoiceId: invoiceId,
        actorUserId: userId,
        action: "sales.invoice.updated",
        fromStatus: existing.status,
        toStatus: nextStatus,
        message: "Invoice updated."
      }
    });

    await this.refreshContactBalances(organizationId, existing.contactId);
    if (contactId !== existing.contactId) {
      await this.refreshContactBalances(organizationId, contactId);
    }

    return this.getInvoice(organizationId, invoiceId);
  }

  async recordPayment(
    organizationId: string,
    userId: string,
    invoiceId: string,
    input: {
      paymentDate: string;
      amount: string;
      method: string;
      reference?: string | null;
      notes?: string | null;
    }
  ) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id: invoiceId, organizationId },
      include: { payments: true }
    });

    if (!invoice) {
      throw new NotFoundException("Invoice not found.");
    }

    await this.prisma.invoicePayment.create({
      data: {
        salesInvoiceId: invoiceId,
        paymentDate: new Date(input.paymentDate),
        amount: input.amount,
        method: input.method,
        reference: input.reference ?? null,
        notes: input.notes ?? null
      }
    });

    const payments = await this.prisma.invoicePayment.findMany({
      where: { salesInvoiceId: invoiceId }
    });
    const amountPaid = payments.reduce((sum, payment) => sum + Number(payment.amount), 0);
    const amountDue = Number(invoice.total) - amountPaid;
    const nextStatus = determineInvoiceStatus({
      currentStatus: invoice.status,
      amountPaid: amountPaid.toFixed(2),
      amountDue: amountDue.toFixed(2)
    });

    await this.prisma.salesInvoice.update({
      where: { id: invoiceId },
      data: {
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2),
        status: nextStatus
      }
    });

    await this.prisma.invoiceStatusEvent.create({
      data: {
        salesInvoiceId: invoiceId,
        actorUserId: userId,
        action: "sales.invoice.payment_recorded",
        fromStatus: invoice.status,
        toStatus: nextStatus,
        message: `Payment recorded via ${input.method}.`
      }
    });

    await this.refreshContactBalances(organizationId, invoice.contactId);
    return this.getInvoice(organizationId, invoiceId);
  }

  private async resolveLines(organizationId: string, lines: DraftDocumentLine[]) {
    if (lines.length === 0) {
      throw new BadRequestException("At least one line is required.");
    }

    const taxRateIds = lines
      .map((line) => line.taxRateId)
      .filter((value): value is string => Boolean(value));
    const taxRates = taxRateIds.length
      ? await this.prisma.taxRate.findMany({
          where: {
            organizationId,
            id: { in: taxRateIds }
          }
        })
      : [];
    const taxRateMap = new Map(taxRates.map((taxRate) => [taxRate.id, taxRate]));

    return lines.map((line) => {
      const taxRate = line.taxRateId ? taxRateMap.get(line.taxRateId) : null;
      return {
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        taxRateId: taxRate?.id ?? null,
        taxRateName: taxRate?.name ?? line.taxRateName ?? null,
        taxRatePercent: taxRate?.rate.toString() ?? line.taxRatePercent ?? 0
      };
    });
  }

  private async nextInvoiceNumber(organizationId: string) {
    const setting = await this.prisma.organizationSetting.findUnique({
      where: {
        organizationId_key: {
          organizationId,
          key: "week2.invoice.settings"
        }
      }
    });

    const prefix =
      (setting?.value as { invoicePrefix?: string } | null)?.invoicePrefix ?? "INV";
    const count = await this.prisma.salesInvoice.count({
      where: { organizationId }
    });

    return `${prefix}-${String(count + 1).padStart(4, "0")}`;
  }

  private async refreshContactBalances(organizationId: string, contactId: string) {
    const sales = await this.prisma.salesInvoice.aggregate({
      where: { organizationId, contactId, status: { not: "VOID" } },
      _sum: { amountDue: true }
    });
    const bills = await this.prisma.purchaseBill.aggregate({
      where: { organizationId, contactId, status: { not: "VOID" } },
      _sum: { amountDue: true }
    });

    await this.prisma.contact.update({
      where: { id: contactId },
      data: {
        receivableBalance: money(sales._sum.amountDue),
        payableBalance: money(bills._sum.amountDue)
      }
    });
  }
}
