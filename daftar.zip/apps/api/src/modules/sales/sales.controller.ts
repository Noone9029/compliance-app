import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Patch,
  Post,
  Query,
  UseGuards
} from "@nestjs/common";
import {
  complianceInvoiceKinds,
  salesInvoiceStatuses
} from "@daftar/types";
import { z } from "zod";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { SalesService } from "./sales.service";

const lineSchema = z.object({
  description: z.string().min(1),
  quantity: z.string().min(1),
  unitPrice: z.string().min(1),
  taxRateId: z.string().optional().nullable()
});

const invoiceSchema = z.object({
  contactId: z.string().min(1),
  invoiceNumber: z.string().optional().nullable(),
  status: z.enum(salesInvoiceStatuses).default("DRAFT"),
  complianceInvoiceKind: z.enum(complianceInvoiceKinds).default("STANDARD"),
  issueDate: z.string().min(1),
  dueDate: z.string().min(1),
  currencyCode: z.string().min(3).max(3),
  notes: z.string().optional().nullable(),
  lines: z.array(lineSchema).min(1)
});

const invoicePatchSchema = invoiceSchema
  .partial()
  .refine((value) => Object.keys(value).length > 0, "At least one field is required.");

const paymentSchema = z.object({
  paymentDate: z.string().min(1),
  amount: z.string().min(1),
  method: z.string().min(1),
  reference: z.string().optional().nullable(),
  notes: z.string().optional().nullable()
});

@Controller("v1/sales")
@UseGuards(AuthenticatedGuard)
export class SalesController {
  private readonly salesService: SalesService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(SalesService) salesService: SalesService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.salesService = salesService;
    this.auditService = auditService;
  }

  @Get("invoices")
  listInvoices(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Query("status") status: string | undefined,
    @Query("search") search: string | undefined
  ) {
    requirePermission(session, "sales.read");
    return this.salesService.listInvoices(session!.organization!.id, {
      status: status ? z.enum(salesInvoiceStatuses).parse(status) : undefined,
      search: search?.trim() || undefined
    });
  }

  @Post("invoices")
  async createInvoice(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "sales.write");
    const parsed = invoiceSchema.parse(body);
    const invoice = await this.salesService.createInvoice(
      session!.organization!.id,
      session!.user!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "sales.invoice.create",
      targetType: "sales_invoice",
      targetId: invoice.id,
      result: "SUCCESS"
    });
    return invoice;
  }

  @Get("invoices/:invoiceId")
  getInvoice(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("invoiceId") invoiceId: string
  ) {
    requirePermission(session, "sales.read");
    return this.salesService.getInvoice(session!.organization!.id, invoiceId);
  }

  @Patch("invoices/:invoiceId")
  async updateInvoice(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("invoiceId") invoiceId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "sales.write");
    const parsed = invoicePatchSchema.parse(body);
    const invoice = await this.salesService.updateInvoice(
      session!.organization!.id,
      session!.user!.id,
      invoiceId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "sales.invoice.update",
      targetType: "sales_invoice",
      targetId: invoice.id,
      result: "SUCCESS"
    });
    return invoice;
  }

  @Post("invoices/:invoiceId/payments")
  async recordPayment(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("invoiceId") invoiceId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "sales.write");
    const parsed = paymentSchema.parse(body);
    const invoice = await this.salesService.recordPayment(
      session!.organization!.id,
      session!.user!.id,
      invoiceId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "sales.invoice.payment",
      targetType: "sales_invoice",
      targetId: invoice.id,
      result: "SUCCESS"
    });
    return invoice;
  }
}
