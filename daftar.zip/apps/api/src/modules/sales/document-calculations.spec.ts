import { describe, expect, it } from "vitest";

import {
  calculateDocumentLines,
  determineBillStatus,
  determineInvoiceStatus
} from "./document-calculations";

describe("document-calculations", () => {
  it("calculates line totals, tax totals, and document totals", () => {
    const result = calculateDocumentLines([
      {
        description: "Service retainer",
        quantity: "2",
        unitPrice: "150.00",
        taxRatePercent: "15.00"
      },
      {
        description: "Support add-on",
        quantity: "1",
        unitPrice: "50.00",
        taxRatePercent: "0.00"
      }
    ]);

    expect(result.lines).toHaveLength(2);
    expect(result.lines[0].lineSubtotal).toBe("300.00");
    expect(result.lines[0].lineTax).toBe("45.00");
    expect(result.subtotal).toBe("350.00");
    expect(result.taxTotal).toBe("45.00");
    expect(result.total).toBe("395.00");
  });

  it("derives invoice status from payment progress", () => {
    expect(
      determineInvoiceStatus({
        currentStatus: "ISSUED",
        amountPaid: "0.00",
        amountDue: "395.00"
      })
    ).toBe("ISSUED");

    expect(
      determineInvoiceStatus({
        currentStatus: "ISSUED",
        amountPaid: "50.00",
        amountDue: "345.00"
      })
    ).toBe("PARTIALLY_PAID");

    expect(
      determineInvoiceStatus({
        currentStatus: "PARTIALLY_PAID",
        amountPaid: "395.00",
        amountDue: "0.00"
      })
    ).toBe("PAID");
  });

  it("derives bill status from payment progress", () => {
    expect(
      determineBillStatus({
        currentStatus: "APPROVED",
        amountPaid: "0.00",
        amountDue: "200.00"
      })
    ).toBe("APPROVED");

    expect(
      determineBillStatus({
        currentStatus: "APPROVED",
        amountPaid: "75.00",
        amountDue: "125.00"
      })
    ).toBe("PARTIALLY_PAID");

    expect(
      determineBillStatus({
        currentStatus: "PARTIALLY_PAID",
        amountPaid: "200.00",
        amountDue: "0.00"
      })
    ).toBe("PAID");
  });
});
