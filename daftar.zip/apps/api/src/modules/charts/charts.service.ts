import { Inject, Injectable } from "@nestjs/common";
import type { ChartsDashboardRecord } from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";
import { ReportsService } from "../reports/reports.service";

@Injectable()
export class ChartsService {
  private readonly prisma: PrismaService;
  private readonly reportsService: ReportsService;

  constructor(
    @Inject(PrismaService) prisma: PrismaService,
    @Inject(ReportsService) reportsService: ReportsService
  ) {
    this.prisma = prisma;
    this.reportsService = reportsService;
  }

  async getDashboard(organizationId: string): Promise<ChartsDashboardRecord> {
    const [reports, bankAccounts, invoicePayments, billPayments] = await Promise.all([
      this.reportsService.getDashboard(organizationId),
      this.prisma.bankAccount.findMany({
        where: { organizationId, isActive: true },
        orderBy: [{ isPrimary: "desc" }, { name: "asc" }]
      }),
      this.prisma.invoicePayment.aggregate({
        where: {
          salesInvoice: { organizationId }
        },
        _sum: { amount: true }
      }),
      this.prisma.billPayment.aggregate({
        where: {
          purchaseBill: { organizationId }
        },
        _sum: { amount: true }
      })
    ]);

    const primaryBankId = bankAccounts.find((account) => account.isPrimary)?.id ?? null;
    const cashMovement =
      Number(invoicePayments._sum.amount ?? 0) - Number(billPayments._sum.amount ?? 0);

    const bankBalances = bankAccounts.map((account) => ({
      label: account.name,
      value: (
        Number(account.openingBalance) + (account.id === primaryBankId ? cashMovement : 0)
      ).toFixed(2)
    }));

    return {
      bankBalances,
      balanceChart: [
        { label: "Assets", value: reports.balanceSheet.assets },
        { label: "Liabilities", value: reports.balanceSheet.liabilities },
        { label: "Equity", value: reports.balanceSheet.equity }
      ],
      profitLoss: [
        { label: "Revenue", value: reports.profitLoss.revenue },
        { label: "Expenses", value: reports.profitLoss.expenses },
        { label: "Profit", value: reports.profitLoss.profit }
      ],
      expenses: [
        { label: "Bills", value: reports.expenseBreakdown.billsExpense },
        { label: "Depreciation", value: reports.expenseBreakdown.depreciationExpense },
        { label: "Total", value: reports.expenseBreakdown.totalExpenses }
      ],
      receivablesPayables: [
        { label: "Receivables", value: reports.payablesReceivables.totalReceivables },
        { label: "Payables", value: reports.payablesReceivables.totalPayables }
      ],
      salesPurchases: reports.salesPurchasesSeries.map((point) => ({
        label: point.label,
        sales: point.salesTotal,
        purchases: point.purchasesTotal
      }))
    };
  }
}
