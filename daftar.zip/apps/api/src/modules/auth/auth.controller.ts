import {
  Body,
  Controller,
  Get,
  Inject,
  Post,
  Req,
  Res,
  UseGuards
} from "@nestjs/common";
import type { Request, Response } from "express";
import { z } from "zod";

import { loadEnv } from "@daftar/config";
import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuthService } from "./auth.service";

const signInSchema = z.object({
  email: z.email(),
  password: z.string().min(8)
});

const invitationSchema = z.object({
  token: z.string().min(1)
});

const env = loadEnv();

@Controller("v1/auth")
export class AuthController {
  private readonly authService: AuthService;

  constructor(@Inject(AuthService) authService: AuthService) {
    this.authService = authService;
  }

  @Post("sign-in")
  async signIn(
    @Body() body: unknown,
    @Req() request: Request & AuthenticatedRequest,
    @Res({ passthrough: true }) response: Response
  ) {
    const parsed = signInSchema.parse(body);
    const result = await this.authService.signIn({
      email: parsed.email,
      password: parsed.password,
      requestId: request.requestId,
      ipAddress: request.ip ?? null,
      userAgent: request.headers["user-agent"] ?? null
    });

    response.cookie(env.SESSION_COOKIE_NAME, result.token, {
      httpOnly: true,
      sameSite: "lax",
      secure: env.NODE_ENV === "production",
      path: "/",
      maxAge: env.SESSION_TTL_HOURS * 60 * 60 * 1000
    });

    return result.session;
  }

  @Post("sign-out")
  async signOut(
    @Req() request: Request & AuthenticatedRequest,
    @Res({ passthrough: true }) response: Response
  ) {
    const rawToken = request.cookies?.[env.SESSION_COOKIE_NAME];
    await this.authService.signOut({
      rawToken,
      requestId: request.requestId,
      ipAddress: request.ip ?? null,
      userAgent: request.headers["user-agent"] ?? null
    });
    response.clearCookie(env.SESSION_COOKIE_NAME, { path: "/" });
    return { ok: true };
  }

  @Get("session")
  async session(@Req() request: Request & AuthenticatedRequest) {
    return this.authService.sessionSnapshot(request.cookies?.[env.SESSION_COOKIE_NAME]);
  }

  @Post("refresh")
  @UseGuards(AuthenticatedGuard)
  async refresh(@Req() request: Request & AuthenticatedRequest) {
    return this.authService.refresh(request.cookies?.[env.SESSION_COOKIE_NAME]);
  }

  @Post("invitations/accept")
  acceptStub(@Body() body: unknown) {
    const parsed = invitationSchema.parse(body);
    return {
      accepted: false,
      token: parsed.token,
      status: "stubbed",
      message: "Invitation acceptance is intentionally stubbed in Week 1."
    };
  }

  @Get("debug")
  @UseGuards(AuthenticatedGuard)
  debug(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    return session;
  }
}
