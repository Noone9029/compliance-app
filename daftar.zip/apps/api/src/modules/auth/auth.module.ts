import { Global, Module } from "@nestjs/common";

import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { AuditModule } from "../audit/audit.module";
import { RbacModule } from "../rbac/rbac.module";
import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.service";

@Global()
@Module({
  imports: [RbacModule, AuditModule],
  controllers: [AuthController],
  providers: [AuthService, AuthenticatedGuard],
  exports: [AuthService, AuthenticatedGuard]
})
export class AuthModule {}
