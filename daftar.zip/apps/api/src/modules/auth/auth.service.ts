import {
  ForbiddenException,
  Inject,
  Injectable,
  UnauthorizedException
} from "@nestjs/common";
import bcrypt from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";
import type { CapabilitySnapshot, OrganizationSummary, SessionSnapshot } from "@daftar/types";

import { loadEnv } from "@daftar/config";
import { PrismaService } from "../../common/prisma/prisma.service";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { RbacService } from "../rbac/rbac.service";

function hashToken(rawToken: string) {
  return createHash("sha256").update(rawToken).digest("hex");
}

@Injectable()
export class AuthService {
  private readonly env = loadEnv();
  private readonly prisma: PrismaService;
  private readonly rbacService: RbacService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(PrismaService) prisma: PrismaService,
    @Inject(RbacService) rbacService: RbacService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.prisma = prisma;
    this.rbacService = rbacService;
    this.auditService = auditService;
  }

  async signIn({
    email,
    password,
    requestId,
    ipAddress,
    userAgent
  }: {
    email: string;
    password: string;
    requestId?: string | null;
    ipAddress?: string | null;
    userAgent?: string | null;
  }) {
    const normalizedEmail = email.trim().toLowerCase();
    const identity = await this.prisma.authIdentity.findUnique({
      where: {
        provider_identifier: {
          provider: "LOCAL",
          identifier: normalizedEmail
        }
      },
      include: {
        user: {
          include: {
            memberships: {
              where: { status: "ACTIVE" },
              include: {
                organization: true,
                role: true
              },
              orderBy: { createdAt: "asc" }
            }
          }
        }
      }
    });

    if (!identity || identity.user.status !== "ACTIVE") {
      throw new UnauthorizedException("Invalid credentials.");
    }

    const matches = await bcrypt.compare(password, identity.secretHash);
    if (!matches) {
      await this.auditService.log({
        actorType: "SYSTEM",
        action: "platform.auth.sign_in_failed",
        targetType: "auth_identity",
        targetId: identity.id,
        result: "FAILURE",
        requestId,
        ipAddress,
        userAgent,
        metadata: { email: normalizedEmail }
      });
      throw new UnauthorizedException("Invalid credentials.");
    }

    const primaryMembership = identity.user.memberships[0];
    if (!primaryMembership) {
      throw new ForbiddenException("User does not belong to an active organization.");
    }

    const rawToken = randomBytes(48).toString("hex");
    const session = await this.prisma.session.create({
      data: {
        userId: identity.user.id,
        organizationId: primaryMembership.organizationId,
        tokenHash: hashToken(rawToken),
        status: "ACTIVE",
        expiresAt: new Date(
          Date.now() + this.env.SESSION_TTL_HOURS * 60 * 60 * 1000
        ),
        lastSeenAt: new Date(),
        ipAddress,
        userAgent
      }
    });

    await this.auditService.log({
      organizationId: primaryMembership.organizationId,
      actorType: "USER",
      actorUserId: identity.user.id,
      action: "platform.auth.sign_in",
      targetType: "session",
      targetId: session.id,
      result: "SUCCESS",
      requestId,
      ipAddress,
      userAgent
    });

    return {
      token: rawToken,
      session: await this.buildSessionSnapshot({
        sessionId: session.id,
        userId: identity.user.id,
        organizationId: primaryMembership.organizationId
      })
    };
  }

  async signOut({
    rawToken,
    requestId,
    ipAddress,
    userAgent
  }: {
    rawToken: string | undefined;
    requestId?: string | null;
    ipAddress?: string | null;
    userAgent?: string | null;
  }) {
    if (!rawToken) {
      return;
    }

    const session = await this.prisma.session.findUnique({
      where: { tokenHash: hashToken(rawToken) }
    });

    if (!session) {
      return;
    }

    await this.prisma.session.update({
      where: { id: session.id },
      data: {
        status: "REVOKED"
      }
    });

    await this.auditService.log({
      organizationId: session.organizationId,
      actorType: "USER",
      actorUserId: session.userId,
      action: "platform.auth.sign_out",
      targetType: "session",
      targetId: session.id,
      result: "SUCCESS",
      requestId,
      ipAddress,
      userAgent
    });
  }

  async refresh(rawToken: string | undefined) {
    if (!rawToken) {
      throw new UnauthorizedException("Session cookie missing.");
    }

    const session = await this.prisma.session.findUnique({
      where: {
        tokenHash: hashToken(rawToken)
      }
    });

    if (!session || session.status !== "ACTIVE" || session.expiresAt < new Date()) {
      throw new UnauthorizedException("Session invalid.");
    }

    await this.prisma.session.update({
      where: { id: session.id },
      data: {
        expiresAt: new Date(
          Date.now() + this.env.SESSION_TTL_HOURS * 60 * 60 * 1000
        ),
        lastSeenAt: new Date()
      }
    });

    return this.buildSessionSnapshot({
      sessionId: session.id,
      userId: session.userId,
      organizationId: session.organizationId
    });
  }

  async resolveRequestSession(request: AuthenticatedRequest) {
    if (request.currentSession) {
      return request.currentSession;
    }

    const rawToken = (request as unknown as { cookies?: Record<string, string> }).cookies?.[
      this.env.SESSION_COOKIE_NAME
    ];

    if (!rawToken) {
      return null;
    }

    const session = await this.prisma.session.findUnique({
      where: { tokenHash: hashToken(rawToken) }
    });

    if (!session || session.status !== "ACTIVE" || session.expiresAt < new Date()) {
      return null;
    }

    const snapshot = await this.buildSessionSnapshot({
      sessionId: session.id,
      userId: session.userId,
      organizationId: session.organizationId
    });

    request.currentSession = snapshot;
    return snapshot;
  }

  async sessionSnapshot(rawToken: string | undefined): Promise<SessionSnapshot> {
    if (!rawToken) {
      return {
        authenticated: false,
        user: null,
        organization: null,
        membership: null
      };
    }

    const session = await this.prisma.session.findUnique({
      where: { tokenHash: hashToken(rawToken) }
    });

    if (!session || session.status !== "ACTIVE" || session.expiresAt < new Date()) {
      return {
        authenticated: false,
        user: null,
        organization: null,
        membership: null
      };
    }

    const snapshot = await this.buildSessionSnapshot({
      sessionId: session.id,
      userId: session.userId,
      organizationId: session.organizationId
    });

    return {
      authenticated: true,
      user: snapshot.user,
      organization: snapshot.organization,
      membership: snapshot.membership
    };
  }

  private async buildSessionSnapshot({
    sessionId,
    userId,
    organizationId
  }: {
    sessionId: string;
    userId: string;
    organizationId?: string | null;
  }) {
    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId }
    });

    let organization: OrganizationSummary | null = null;
    let membership: SessionSnapshot["membership"] = null;
    let capabilitySnapshot: CapabilitySnapshot = { roleKey: null, permissions: [] };

    if (organizationId) {
      const foundMembership = await this.prisma.membership.findUnique({
        where: {
          userId_organizationId: {
            userId,
            organizationId
          }
        },
        include: {
          organization: true,
          role: true
        }
      });

      if (foundMembership && foundMembership.status === "ACTIVE") {
        organization = {
          id: foundMembership.organization.id,
          name: foundMembership.organization.name,
          slug: foundMembership.organization.slug
        };
        membership = {
          id: foundMembership.id,
          roleKey: foundMembership.role.key,
          status: foundMembership.status
        };
        capabilitySnapshot = await this.rbacService.getCapabilitySnapshot(
          userId,
          organizationId
        );
      }
    }

    return {
      id: sessionId,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName
      },
      organization,
      membership,
      capabilitySnapshot
    };
  }
}
