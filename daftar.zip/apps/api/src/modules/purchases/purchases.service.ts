import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import type {
  PurchaseBillDetail,
  PurchaseBillStatus,
  PurchaseBillSummary,
  StoredFileRecord
} from "@daftar/types";

import { PrismaService } from "../../common/prisma/prisma.service";
import {
  calculateDocumentLines,
  determineBillStatus,
  type DraftDocumentLine
} from "../sales/document-calculations";

function money(value: { toString(): string } | string | number | null | undefined) {
  return Number(value ?? 0).toFixed(2);
}

function fileRecord(file: {
  id: string;
  organizationId: string;
  storageProvider: "S3_COMPAT";
  bucket: string;
  objectKey: string;
  originalFileName: string;
  mimeType: string;
  sizeBytes: number;
  checksumSha256: string | null;
  relatedType: string | null;
  relatedId: string | null;
  metadata: unknown;
  createdAt: Date;
}): StoredFileRecord {
  return {
    id: file.id,
    organizationId: file.organizationId,
    storageProvider: file.storageProvider,
    bucket: file.bucket,
    objectKey: file.objectKey,
    originalFileName: file.originalFileName,
    mimeType: file.mimeType,
    sizeBytes: file.sizeBytes,
    checksumSha256: file.checksumSha256,
    relatedType: file.relatedType,
    relatedId: file.relatedId,
    metadata: (file.metadata as Record<string, unknown> | null) ?? null,
    createdAt: file.createdAt.toISOString()
  };
}

@Injectable()
export class PurchasesService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async listBills(
    organizationId: string,
    options: {
      status?: PurchaseBillStatus;
      search?: string;
    }
  ): Promise<PurchaseBillSummary[]> {
    const bills = await this.prisma.purchaseBill.findMany({
      where: {
        organizationId,
        ...(options.status ? { status: options.status } : {}),
        ...(options.search
          ? {
              OR: [
                { billNumber: { contains: options.search, mode: "insensitive" } },
                { contact: { displayName: { contains: options.search, mode: "insensitive" } } }
              ]
            }
          : {})
      },
      include: {
        contact: true
      },
      orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }]
    });

    return bills.map((bill) => ({
      id: bill.id,
      organizationId: bill.organizationId,
      contactId: bill.contactId,
      contactName: bill.contact.displayName,
      billNumber: bill.billNumber,
      status: bill.status,
      issueDate: bill.issueDate.toISOString(),
      dueDate: bill.dueDate.toISOString(),
      currencyCode: bill.currencyCode,
      subtotal: money(bill.subtotal),
      taxTotal: money(bill.taxTotal),
      total: money(bill.total),
      amountPaid: money(bill.amountPaid),
      amountDue: money(bill.amountDue),
      createdAt: bill.createdAt.toISOString(),
      updatedAt: bill.updatedAt.toISOString()
    }));
  }

  async getBill(
    organizationId: string,
    billId: string
  ): Promise<PurchaseBillDetail> {
    const bill = await this.prisma.purchaseBill.findFirst({
      where: { id: billId, organizationId },
      include: {
        contact: true,
        lines: {
          orderBy: { sortOrder: "asc" }
        },
        payments: {
          orderBy: { paymentDate: "desc" }
        }
      }
    });

    if (!bill) {
      throw new NotFoundException("Bill not found.");
    }

    const attachments = await this.prisma.storedFile.findMany({
      where: {
        organizationId,
        relatedType: "purchase-bill",
        relatedId: billId
      },
      orderBy: { createdAt: "desc" }
    });

    return {
      id: bill.id,
      organizationId: bill.organizationId,
      contactId: bill.contactId,
      contactName: bill.contact.displayName,
      billNumber: bill.billNumber,
      status: bill.status,
      issueDate: bill.issueDate.toISOString(),
      dueDate: bill.dueDate.toISOString(),
      currencyCode: bill.currencyCode,
      subtotal: money(bill.subtotal),
      taxTotal: money(bill.taxTotal),
      total: money(bill.total),
      amountPaid: money(bill.amountPaid),
      amountDue: money(bill.amountDue),
      notes: bill.notes,
      createdAt: bill.createdAt.toISOString(),
      updatedAt: bill.updatedAt.toISOString(),
      lines: bill.lines.map((line) => ({
        id: line.id,
        description: line.description,
        quantity: money(line.quantity),
        unitPrice: money(line.unitPrice),
        taxRateId: line.taxRateId,
        taxRateName: line.taxRateName,
        taxRatePercent: money(line.taxRatePercent),
        lineSubtotal: money(line.lineSubtotal),
        lineTax: money(line.lineTax),
        lineTotal: money(line.lineTotal),
        sortOrder: line.sortOrder
      })),
      payments: bill.payments.map((payment) => ({
        id: payment.id,
        paymentDate: payment.paymentDate.toISOString(),
        amount: money(payment.amount),
        method: payment.method,
        reference: payment.reference,
        notes: payment.notes,
        createdAt: payment.createdAt.toISOString()
      })),
      attachments: attachments.map(fileRecord)
    };
  }

  async createBill(
    organizationId: string,
    input: {
      contactId: string;
      billNumber?: string | null;
      status: PurchaseBillStatus;
      issueDate: string;
      dueDate: string;
      currencyCode: string;
      notes?: string | null;
      lines: DraftDocumentLine[];
    }
  ) {
    const contact = await this.prisma.contact.findFirst({
      where: {
        id: input.contactId,
        organizationId,
        isSupplier: true
      }
    });

    if (!contact) {
      throw new NotFoundException("Supplier contact not found.");
    }

    const resolvedLines = await this.resolveLines(organizationId, input.lines);
    const totals = calculateDocumentLines(resolvedLines);
    const billNumber =
      input.billNumber?.trim() || (await this.nextBillNumber(organizationId));

    const bill = await this.prisma.purchaseBill.create({
      data: {
        organizationId,
        contactId: input.contactId,
        billNumber,
        status: input.status,
        issueDate: new Date(input.issueDate),
        dueDate: new Date(input.dueDate),
        currencyCode: input.currencyCode.toUpperCase(),
        notes: input.notes ?? null,
        subtotal: totals.subtotal,
        taxTotal: totals.taxTotal,
        total: totals.total,
        amountPaid: "0.00",
        amountDue: totals.total,
        lines: {
          create: totals.lines
        }
      }
    });

    await this.refreshContactBalances(organizationId, input.contactId);
    return this.getBill(organizationId, bill.id);
  }

  async updateBill(
    organizationId: string,
    billId: string,
    input: Partial<{
      contactId: string;
      billNumber: string | null;
      status: PurchaseBillStatus;
      issueDate: string;
      dueDate: string;
      currencyCode: string;
      notes: string | null;
      lines: DraftDocumentLine[];
    }>
  ) {
    const existing = await this.prisma.purchaseBill.findFirst({
      where: { id: billId, organizationId },
      include: { lines: true, payments: true }
    });

    if (!existing) {
      throw new NotFoundException("Bill not found.");
    }

    const contactId = input.contactId ?? existing.contactId;
    const contact = await this.prisma.contact.findFirst({
      where: { id: contactId, organizationId, isSupplier: true }
    });

    if (!contact) {
      throw new NotFoundException("Supplier contact not found.");
    }

    const sourceLines =
      input.lines ??
      existing.lines.map((line) => ({
        description: line.description,
        quantity: line.quantity.toString(),
        unitPrice: line.unitPrice.toString(),
        taxRateId: line.taxRateId,
        taxRateName: line.taxRateName,
        taxRatePercent: line.taxRatePercent.toString()
      }));

    const resolvedLines = await this.resolveLines(organizationId, sourceLines);
    const totals = calculateDocumentLines(resolvedLines);
    const amountPaid = existing.payments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0
    );
    const amountDue = Number(totals.total) - amountPaid;
    const nextStatus =
      input.status ??
      determineBillStatus({
        currentStatus: existing.status,
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2)
      });

    await this.prisma.purchaseBill.update({
      where: { id: billId },
      data: {
        contactId,
        billNumber: input.billNumber?.trim() || existing.billNumber,
        status: nextStatus,
        issueDate: input.issueDate ? new Date(input.issueDate) : existing.issueDate,
        dueDate: input.dueDate ? new Date(input.dueDate) : existing.dueDate,
        currencyCode: input.currencyCode?.toUpperCase() ?? existing.currencyCode,
        notes: input.notes === undefined ? existing.notes : input.notes,
        subtotal: totals.subtotal,
        taxTotal: totals.taxTotal,
        total: totals.total,
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2)
      }
    });

    if (input.lines) {
      await this.prisma.purchaseBillLine.deleteMany({
        where: { purchaseBillId: billId }
      });

      await this.prisma.purchaseBillLine.createMany({
        data: totals.lines.map((line) => ({
          purchaseBillId: billId,
          ...line
        }))
      });
    }

    await this.refreshContactBalances(organizationId, existing.contactId);
    if (contactId !== existing.contactId) {
      await this.refreshContactBalances(organizationId, contactId);
    }

    return this.getBill(organizationId, billId);
  }

  async recordPayment(
    organizationId: string,
    billId: string,
    input: {
      paymentDate: string;
      amount: string;
      method: string;
      reference?: string | null;
      notes?: string | null;
    }
  ) {
    const bill = await this.prisma.purchaseBill.findFirst({
      where: { id: billId, organizationId },
      include: { payments: true }
    });

    if (!bill) {
      throw new NotFoundException("Bill not found.");
    }

    await this.prisma.billPayment.create({
      data: {
        purchaseBillId: billId,
        paymentDate: new Date(input.paymentDate),
        amount: input.amount,
        method: input.method,
        reference: input.reference ?? null,
        notes: input.notes ?? null
      }
    });

    const payments = await this.prisma.billPayment.findMany({
      where: { purchaseBillId: billId }
    });
    const amountPaid = payments.reduce((sum, payment) => sum + Number(payment.amount), 0);
    const amountDue = Number(bill.total) - amountPaid;
    const nextStatus = determineBillStatus({
      currentStatus: bill.status,
      amountPaid: amountPaid.toFixed(2),
      amountDue: amountDue.toFixed(2)
    });

    await this.prisma.purchaseBill.update({
      where: { id: billId },
      data: {
        amountPaid: amountPaid.toFixed(2),
        amountDue: amountDue.toFixed(2),
        status: nextStatus
      }
    });

    await this.refreshContactBalances(organizationId, bill.contactId);
    return this.getBill(organizationId, billId);
  }

  private async resolveLines(organizationId: string, lines: DraftDocumentLine[]) {
    if (lines.length === 0) {
      throw new BadRequestException("At least one line is required.");
    }

    const taxRateIds = lines
      .map((line) => line.taxRateId)
      .filter((value): value is string => Boolean(value));
    const taxRates = taxRateIds.length
      ? await this.prisma.taxRate.findMany({
          where: {
            organizationId,
            id: { in: taxRateIds }
          }
        })
      : [];
    const taxRateMap = new Map(taxRates.map((taxRate) => [taxRate.id, taxRate]));

    return lines.map((line) => {
      const taxRate = line.taxRateId ? taxRateMap.get(line.taxRateId) : null;
      return {
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        taxRateId: taxRate?.id ?? null,
        taxRateName: taxRate?.name ?? line.taxRateName ?? null,
        taxRatePercent: taxRate?.rate.toString() ?? line.taxRatePercent ?? 0
      };
    });
  }

  private async nextBillNumber(organizationId: string) {
    const count = await this.prisma.purchaseBill.count({
      where: { organizationId }
    });

    return `BILL-${String(count + 1).padStart(4, "0")}`;
  }

  private async refreshContactBalances(organizationId: string, contactId: string) {
    const sales = await this.prisma.salesInvoice.aggregate({
      where: { organizationId, contactId, status: { not: "VOID" } },
      _sum: { amountDue: true }
    });
    const bills = await this.prisma.purchaseBill.aggregate({
      where: { organizationId, contactId, status: { not: "VOID" } },
      _sum: { amountDue: true }
    });

    await this.prisma.contact.update({
      where: { id: contactId },
      data: {
        receivableBalance: money(sales._sum.amountDue),
        payableBalance: money(bills._sum.amountDue)
      }
    });
  }
}
