import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Patch,
  Post,
  Query,
  UseGuards
} from "@nestjs/common";
import { purchaseBillStatuses } from "@daftar/types";
import { z } from "zod";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { PurchasesService } from "./purchases.service";

const lineSchema = z.object({
  description: z.string().min(1),
  quantity: z.string().min(1),
  unitPrice: z.string().min(1),
  taxRateId: z.string().optional().nullable()
});

const billSchema = z.object({
  contactId: z.string().min(1),
  billNumber: z.string().optional().nullable(),
  status: z.enum(purchaseBillStatuses).default("DRAFT"),
  issueDate: z.string().min(1),
  dueDate: z.string().min(1),
  currencyCode: z.string().min(3).max(3),
  notes: z.string().optional().nullable(),
  lines: z.array(lineSchema).min(1)
});

const billPatchSchema = billSchema
  .partial()
  .refine((value) => Object.keys(value).length > 0, "At least one field is required.");

const paymentSchema = z.object({
  paymentDate: z.string().min(1),
  amount: z.string().min(1),
  method: z.string().min(1),
  reference: z.string().optional().nullable(),
  notes: z.string().optional().nullable()
});

@Controller("v1/purchases")
@UseGuards(AuthenticatedGuard)
export class PurchasesController {
  private readonly purchasesService: PurchasesService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(PurchasesService) purchasesService: PurchasesService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.purchasesService = purchasesService;
    this.auditService = auditService;
  }

  @Get("bills")
  listBills(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Query("status") status: string | undefined,
    @Query("search") search: string | undefined
  ) {
    requirePermission(session, "purchases.read");
    return this.purchasesService.listBills(session!.organization!.id, {
      status: status ? z.enum(purchaseBillStatuses).parse(status) : undefined,
      search: search?.trim() || undefined
    });
  }

  @Post("bills")
  async createBill(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "purchases.write");
    const parsed = billSchema.parse(body);
    const bill = await this.purchasesService.createBill(session!.organization!.id, parsed);
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "purchases.bill.create",
      targetType: "purchase_bill",
      targetId: bill.id,
      result: "SUCCESS"
    });
    return bill;
  }

  @Get("bills/:billId")
  getBill(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("billId") billId: string
  ) {
    requirePermission(session, "purchases.read");
    return this.purchasesService.getBill(session!.organization!.id, billId);
  }

  @Patch("bills/:billId")
  async updateBill(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("billId") billId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "purchases.write");
    const parsed = billPatchSchema.parse(body);
    const bill = await this.purchasesService.updateBill(
      session!.organization!.id,
      billId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "purchases.bill.update",
      targetType: "purchase_bill",
      targetId: bill.id,
      result: "SUCCESS"
    });
    return bill;
  }

  @Post("bills/:billId/payments")
  async recordPayment(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("billId") billId: string,
    @Body() body: unknown
  ) {
    requirePermission(session, "purchases.write");
    const parsed = paymentSchema.parse(body);
    const bill = await this.purchasesService.recordPayment(
      session!.organization!.id,
      billId,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "purchases.bill.payment",
      targetType: "purchase_bill",
      targetId: bill.id,
      result: "SUCCESS"
    });
    return bill;
  }
}
