import { Inject, Injectable, NotFoundException } from "@nestjs/common";
import type {
  ComplianceOverviewRecord,
  ReportedDocumentRecord
} from "@daftar/types";

import { Prisma } from "@prisma/client";
import { PrismaService } from "../../common/prisma/prisma.service";
import { buildComplianceHashes, buildQrPayload, generateComplianceUuid } from "./compliance-core";

function reportedDocumentRecord(record: {
  id: string;
  organizationId: string;
  salesInvoiceId: string;
  complianceDocumentId: string;
  documentNumber: string;
  status: string;
  responseCode: string | null;
  responseMessage: string | null;
  submittedAt: Date;
  createdAt: Date;
}): ReportedDocumentRecord {
  return {
    id: record.id,
    organizationId: record.organizationId,
    salesInvoiceId: record.salesInvoiceId,
    complianceDocumentId: record.complianceDocumentId,
    documentNumber: record.documentNumber,
    status: record.status,
    responseCode: record.responseCode,
    responseMessage: record.responseMessage,
    submittedAt: record.submittedAt.toISOString(),
    createdAt: record.createdAt.toISOString()
  };
}

@Injectable()
export class ComplianceService {
  private readonly prisma: PrismaService;

  constructor(@Inject(PrismaService) prisma: PrismaService) {
    this.prisma = prisma;
  }

  async getOverview(organizationId: string): Promise<ComplianceOverviewRecord> {
    const [readyCount, submissions, recentReportedDocuments, totalReportedDocuments] =
      await Promise.all([
      this.prisma.salesInvoice.count({
        where: {
          organizationId,
          status: {
            in: ["ISSUED", "PARTIALLY_PAID", "PAID"]
          },
          complianceDocument: null
        }
      }),
      this.prisma.zatcaSubmission.groupBy({
        by: ["status"],
        where: { organizationId },
        _count: { status: true }
      }),
      this.prisma.reportedDocument.findMany({
        where: { organizationId },
        orderBy: { submittedAt: "desc" },
        take: 10
      }),
      this.prisma.reportedDocument.count({
        where: { organizationId }
      })
    ]);

    const queuedSubmissions =
      submissions.find((entry) => entry.status === "QUEUED")?._count.status ?? 0;
    const failedSubmissions =
      submissions.find((entry) => entry.status === "FAILED")?._count.status ?? 0;

    return {
      totalInvoicesReady: readyCount,
      totalReportedDocuments,
      queuedSubmissions,
      failedSubmissions,
      recentReportedDocuments: recentReportedDocuments.map(reportedDocumentRecord)
    };
  }

  async listReportedDocuments(
    organizationId: string
  ): Promise<ReportedDocumentRecord[]> {
    const documents = await this.prisma.reportedDocument.findMany({
      where: { organizationId },
      orderBy: { submittedAt: "desc" }
    });

    return documents.map(reportedDocumentRecord);
  }

  async reportInvoice(
    organizationId: string,
    userId: string,
    invoiceId: string
  ) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id: invoiceId, organizationId },
      include: {
        contact: true,
        complianceDocument: true
      }
    });

    if (!invoice) {
      throw new NotFoundException("Invoice not found.");
    }

    const organizationTaxDetail = await this.prisma.organizationTaxDetail.findUnique({
      where: { organizationId }
    });

    if (!organizationTaxDetail) {
      throw new NotFoundException("Organisation tax details are not configured.");
    }

    const previousDocument = await this.prisma.complianceDocument.findFirst({
      where: {
        organizationId,
        status: "REPORTED",
        salesInvoiceId: { not: invoiceId }
      },
      orderBy: { lastSubmittedAt: "desc" }
    });

    const uuid = invoice.complianceDocument?.uuid ?? generateComplianceUuid();
    const hashes = buildComplianceHashes({
      previousHash: previousDocument?.currentHash ?? null,
      invoiceNumber: invoice.invoiceNumber,
      total: invoice.total.toString(),
      taxTotal: invoice.taxTotal.toString(),
      issueDateIso: invoice.issueDate.toISOString(),
      uuid
    });

    const qrPayload = buildQrPayload({
      sellerName: organizationTaxDetail.legalName,
      taxNumber: organizationTaxDetail.taxNumber,
      issuedAtIso: invoice.issueDate.toISOString(),
      total: invoice.total.toString(),
      taxTotal: invoice.taxTotal.toString()
    });

    const complianceDocument = await this.prisma.complianceDocument.upsert({
      where: { salesInvoiceId: invoiceId },
      update: {
        invoiceKind: invoice.complianceInvoiceKind,
        uuid,
        qrPayload,
        previousHash: hashes.previousHash,
        currentHash: hashes.currentHash,
        status: "REPORTED",
        lastSubmissionStatus: "SUCCESS",
        lastSubmittedAt: new Date(),
        lastError: null
      },
      create: {
        organizationId,
        salesInvoiceId: invoiceId,
        invoiceKind: invoice.complianceInvoiceKind,
        uuid,
        qrPayload,
        previousHash: hashes.previousHash,
        currentHash: hashes.currentHash,
        status: "REPORTED",
        lastSubmissionStatus: "SUCCESS",
        lastSubmittedAt: new Date()
      }
    });

    await this.prisma.zatcaSubmission.create({
      data: {
        organizationId,
        complianceDocumentId: complianceDocument.id,
        status: "SUCCESS",
        retryable: false,
        requestPayload: {
          invoiceId,
          invoiceNumber: invoice.invoiceNumber
        } as Prisma.InputJsonValue,
        responsePayload: {
          responseCode: "REPORTED",
          provider: "INTERNAL_WEEK3"
        } as Prisma.InputJsonValue,
        submittedAt: new Date(),
        finishedAt: new Date()
      }
    });

    await this.prisma.reportedDocument.upsert({
      where: { salesInvoiceId: invoiceId },
      update: {
        documentNumber: invoice.invoiceNumber,
        status: "REPORTED",
        responseCode: "REPORTED",
        responseMessage: "Invoice reported through Week 3 compliance core.",
        submittedAt: new Date()
      },
      create: {
        organizationId,
        salesInvoiceId: invoiceId,
        complianceDocumentId: complianceDocument.id,
        documentNumber: invoice.invoiceNumber,
        status: "REPORTED",
        responseCode: "REPORTED",
        responseMessage: "Invoice reported through Week 3 compliance core.",
        submittedAt: new Date()
      }
    });

    await this.prisma.complianceEvent.createMany({
      data: [
        {
          organizationId,
          salesInvoiceId: invoiceId,
          complianceDocumentId: complianceDocument.id,
          actorUserId: userId,
          action: "compliance.invoice.queued",
          status: "QUEUED",
          message: "Invoice queued for reporting."
        },
        {
          organizationId,
          salesInvoiceId: invoiceId,
          complianceDocumentId: complianceDocument.id,
          actorUserId: userId,
          action: "compliance.invoice.reported",
          status: "SUCCESS",
          message: "Invoice reported successfully."
        }
      ]
    });

    await this.prisma.invoiceStatusEvent.create({
      data: {
        salesInvoiceId: invoiceId,
        actorUserId: userId,
        action: "sales.invoice.reported_to_zatca",
        fromStatus: invoice.status,
        toStatus: invoice.status,
        message: "Invoice reported to ZATCA compliance core."
      }
    });

    return this.prisma.complianceDocument.findUniqueOrThrow({
      where: { id: complianceDocument.id }
    });
  }
}
