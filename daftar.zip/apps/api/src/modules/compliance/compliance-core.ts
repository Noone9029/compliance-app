import { createHash, randomUUID } from "node:crypto";

export function generateComplianceUuid() {
  return randomUUID();
}

export function hashValue(input: string) {
  return createHash("sha256").update(input).digest("hex");
}

function tlvField(tag: number, value: string) {
  const valueBuffer = Buffer.from(value, "utf8");
  return Buffer.concat([Buffer.from([tag]), Buffer.from([valueBuffer.length]), valueBuffer]);
}

export function buildQrPayload(input: {
  sellerName: string;
  taxNumber: string;
  issuedAtIso: string;
  total: string;
  taxTotal: string;
}) {
  return Buffer.concat([
    tlvField(1, input.sellerName),
    tlvField(2, input.taxNumber),
    tlvField(3, input.issuedAtIso),
    tlvField(4, input.total),
    tlvField(5, input.taxTotal)
  ]).toString("base64");
}

export function buildComplianceHashes(input: {
  previousHash: string | null;
  invoiceNumber: string;
  total: string;
  taxTotal: string;
  issueDateIso: string;
  uuid: string;
}) {
  const previousHash = input.previousHash ?? "GENESIS";
  const currentHash = hashValue(
    [
      previousHash,
      input.invoiceNumber,
      input.total,
      input.taxTotal,
      input.issueDateIso,
      input.uuid
    ].join("|")
  );

  return { previousHash: input.previousHash, currentHash };
}
