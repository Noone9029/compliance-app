import { Controller, Get, Inject, Param, Post, UseGuards } from "@nestjs/common";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { ComplianceService } from "./compliance.service";

@Controller("v1/compliance")
@UseGuards(AuthenticatedGuard)
export class ComplianceController {
  private readonly complianceService: ComplianceService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(ComplianceService) complianceService: ComplianceService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.complianceService = complianceService;
    this.auditService = auditService;
  }

  @Get("overview")
  getOverview(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "compliance.read");
    return this.complianceService.getOverview(session!.organization!.id);
  }

  @Get("reported-documents")
  listReportedDocuments(
    @CurrentSession() session: AuthenticatedRequest["currentSession"]
  ) {
    requirePermission(session, "compliance.read");
    return this.complianceService.listReportedDocuments(session!.organization!.id);
  }

  @Post("invoices/:invoiceId/report")
  async reportInvoice(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Param("invoiceId") invoiceId: string
  ) {
    requirePermission(session, "compliance.report");
    const document = await this.complianceService.reportInvoice(
      session!.organization!.id,
      session!.user!.id,
      invoiceId
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "compliance.invoice.report",
      targetType: "sales_invoice",
      targetId: invoiceId,
      result: "SUCCESS"
    });
    return document;
  }
}
