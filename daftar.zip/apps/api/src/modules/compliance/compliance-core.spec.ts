import { describe, expect, it } from "vitest";

import {
  buildComplianceHashes,
  buildQrPayload,
  generateComplianceUuid,
  hashValue
} from "./compliance-core";

describe("compliance-core", () => {
  it("generates UUIDs", () => {
    const first = generateComplianceUuid();
    const second = generateComplianceUuid();

    expect(first).not.toBe(second);
    expect(first).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    );
  });

  it("hashes values deterministically", () => {
    expect(hashValue("week3-test")).toBe(hashValue("week3-test"));
    expect(hashValue("week3-test")).not.toBe(hashValue("week3-other"));
  });

  it("builds a base64 qr payload and chained hashes", () => {
    const qrPayload = buildQrPayload({
      sellerName: "Nomad Events Arabia Limited",
      taxNumber: "300123456700003",
      issuedAtIso: "2026-04-12T09:00:00.000Z",
      total: "115.00",
      taxTotal: "15.00"
    });
    const hashes = buildComplianceHashes({
      previousHash: "previous-hash-value",
      invoiceNumber: "INV-NE-0003",
      total: "115.00",
      taxTotal: "15.00",
      issueDateIso: "2026-04-12T09:00:00.000Z",
      uuid: "uuid-value"
    });

    expect(qrPayload).toMatch(/^[A-Za-z0-9+/=]+$/);
    expect(hashes.previousHash).toBe("previous-hash-value");
    expect(hashes.currentHash).toHaveLength(64);
  });
});
