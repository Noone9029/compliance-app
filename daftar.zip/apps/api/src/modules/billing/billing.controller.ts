import {
  Body,
  Controller,
  Get,
  Inject,
  Patch,
  Post,
  Put,
  UseGuards
} from "@nestjs/common";
import { billingPlanCodes, billingSubscriptionStatuses } from "@daftar/types";
import { z } from "zod";

import { CurrentSession } from "../../common/decorators/current-session.decorator";
import { AuthenticatedGuard } from "../../common/guards/authenticated.guard";
import { requirePermission } from "../../common/utils/require-permission";
import type { AuthenticatedRequest } from "../../common/utils/request-context";
import { AuditService } from "../audit/audit.service";
import { BillingService } from "./billing.service";

const billingSummarySchema = z.object({
  stripeCustomerId: z.string().optional().nullable(),
  billingEmail: z.string().email().optional().nullable(),
  subscriptionId: z.string().optional().nullable(),
  planCode: z.enum(billingPlanCodes),
  status: z.enum(billingSubscriptionStatuses),
  seats: z.number().int().positive(),
  currentPeriodStart: z.string().optional().nullable(),
  currentPeriodEnd: z.string().optional().nullable(),
  cancelAtPeriodEnd: z.boolean().default(false)
});

const billingInvoiceSchema = z.object({
  stripeInvoiceId: z.string().min(1),
  invoiceNumber: z.string().min(1),
  status: z.string().min(1),
  total: z.string().min(1),
  currencyCode: z.string().min(3).max(3),
  issuedAt: z.string().min(1),
  dueAt: z.string().optional().nullable(),
  paidAt: z.string().optional().nullable(),
  hostedInvoiceUrl: z.string().url().optional().nullable()
});

const billingSubscriptionSchema = z.object({
  stripeCustomerId: z.string().min(1),
  billingEmail: z.string().email().optional().nullable(),
  subscriptionId: z.string().min(1),
  planCode: z.enum(billingPlanCodes),
  status: z.enum(billingSubscriptionStatuses),
  seats: z.number().int().positive(),
  currentPeriodStart: z.string().optional().nullable(),
  currentPeriodEnd: z.string().optional().nullable(),
  cancelAtPeriodEnd: z.boolean().default(false)
});

const billingSubscriptionPatchSchema = billingSubscriptionSchema
  .partial()
  .refine((value) => Object.keys(value).length > 0, "At least one field is required.");

const billingCancelSchema = z.object({
  immediate: z.boolean().optional().nullable()
});

@Controller("v1/billing")
@UseGuards(AuthenticatedGuard)
export class BillingController {
  private readonly billingService: BillingService;
  private readonly auditService: AuditService;

  constructor(
    @Inject(BillingService) billingService: BillingService,
    @Inject(AuditService) auditService: AuditService
  ) {
    this.billingService = billingService;
    this.auditService = auditService;
  }

  @Get("plans")
  listPlans(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "billing.read");
    return this.billingService.listPlans();
  }

  @Get("summary")
  getSummary(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "billing.read");
    return this.billingService.getSummary(session!.organization!.id);
  }

  @Put("summary")
  async updateSummary(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "billing.write");
    const parsed = billingSummarySchema.parse(body);
    const summary = await this.billingService.updateSummary(
      session!.organization!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "billing.summary.update",
      targetType: "billing_subscription",
      targetId: summary.subscriptionId,
      result: "SUCCESS"
    });
    return summary;
  }

  @Get("invoices")
  listInvoices(@CurrentSession() session: AuthenticatedRequest["currentSession"]) {
    requirePermission(session, "billing.read");
    return this.billingService.listInvoices(session!.organization!.id);
  }

  @Post("subscription")
  async createSubscription(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "billing.write");
    const parsed = billingSubscriptionSchema.parse(body);
    const subscription = await this.billingService.createSubscription(
      session!.organization!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "billing.subscription.create",
      targetType: "billing_subscription",
      targetId: subscription.subscriptionId,
      result: "SUCCESS"
    });
    return subscription;
  }

  @Patch("subscription")
  async updateSubscription(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "billing.write");
    const parsed = billingSubscriptionPatchSchema.parse(body);
    const subscription = await this.billingService.updateSubscription(
      session!.organization!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "billing.subscription.update",
      targetType: "billing_subscription",
      targetId: subscription.subscriptionId,
      result: "SUCCESS"
    });
    return subscription;
  }

  @Post("subscription/cancel")
  async cancelSubscription(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "billing.write");
    const parsed = billingCancelSchema.parse(body ?? {});
    const subscription = await this.billingService.cancelSubscription(
      session!.organization!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "billing.subscription.cancel",
      targetType: "billing_subscription",
      targetId: subscription.subscriptionId,
      result: "SUCCESS"
    });
    return subscription;
  }

  @Post("invoices")
  async createInvoice(
    @CurrentSession() session: AuthenticatedRequest["currentSession"],
    @Body() body: unknown
  ) {
    requirePermission(session, "billing.write");
    const parsed = billingInvoiceSchema.parse(body);
    const invoice = await this.billingService.createInvoice(
      session!.organization!.id,
      parsed
    );
    await this.auditService.log({
      organizationId: session!.organization!.id,
      actorType: "USER",
      actorUserId: session!.user!.id,
      action: "billing.invoice.create",
      targetType: "billing_invoice",
      targetId: invoice.id,
      result: "SUCCESS"
    });
    return invoice;
  }
}
