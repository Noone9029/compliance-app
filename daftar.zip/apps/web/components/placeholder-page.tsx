import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";

export function PlaceholderPage({
  title,
  description,
  todo = "Week 1 shell only. Business workflows start in later slices."
}: {
  title: string;
  description: string;
  todo?: string;
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">{description}</p>
          </div>
          <StatusBadge label="Week 1 Shell" tone="warning" />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-slate-600">{todo}</p>
      </CardContent>
    </Card>
  );
}
