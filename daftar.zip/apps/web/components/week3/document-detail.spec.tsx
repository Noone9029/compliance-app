import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("next/link", () => ({
  default: ({
    children,
    href
  }: {
    children: React.ReactNode;
    href: string;
  }) => <a href={href}>{children}</a>
}));

import { DocumentDetail } from "./document-detail";

describe("DocumentDetail", () => {
  it("renders sales invoice detail including compliance metadata", () => {
    render(
      <DocumentDetail
        document={{
          id: "inv_1",
          organizationId: "org_1",
          contactId: "contact_1",
          contactName: "Al Noor Hospitality",
          invoiceNumber: "INV-NE-0001",
          status: "PARTIALLY_PAID",
          complianceInvoiceKind: "STANDARD",
          complianceStatus: "REPORTED",
          issueDate: "2026-04-12T09:00:00.000Z",
          dueDate: "2026-04-22T09:00:00.000Z",
          currencyCode: "SAR",
          subtotal: "1000.00",
          taxTotal: "150.00",
          total: "1150.00",
          amountPaid: "300.00",
          amountDue: "850.00",
          notes: "Week 3 invoice",
          createdAt: "2026-04-12T09:00:00.000Z",
          updatedAt: "2026-04-12T09:00:00.000Z",
          lines: [
            {
              id: "line_1",
              description: "Implementation sprint",
              quantity: "2.00",
              unitPrice: "500.00",
              taxRateId: "tax_1",
              taxRateName: "VAT 15%",
              taxRatePercent: "15.00",
              lineSubtotal: "1000.00",
              lineTax: "150.00",
              lineTotal: "1150.00",
              sortOrder: 0
            }
          ],
          payments: [
            {
              id: "payment_1",
              paymentDate: "2026-04-13T09:00:00.000Z",
              amount: "300.00",
              method: "Bank Transfer",
              reference: "WK3-PMT-001",
              notes: null,
              createdAt: "2026-04-13T09:00:00.000Z"
            }
          ],
          attachments: [],
          statusEvents: [
            {
              id: "event_1",
              action: "sales.invoice.created",
              fromStatus: null,
              toStatus: "ISSUED",
              message: "Invoice created.",
              actorUserId: "user_1",
              createdAt: "2026-04-12T09:00:00.000Z"
            }
          ],
          compliance: {
            id: "compliance_1",
            salesInvoiceId: "inv_1",
            invoiceKind: "STANDARD",
            uuid: "uuid-value",
            qrPayload: "qr-value",
            previousHash: null,
            currentHash: "hash-value",
            status: "REPORTED",
            lastSubmissionStatus: "SUCCESS",
            lastSubmittedAt: "2026-04-13T10:00:00.000Z",
            lastError: null,
            createdAt: "2026-04-13T10:00:00.000Z",
            updatedAt: "2026-04-13T10:00:00.000Z"
          }
        }}
        kind="sales"
      />
    );

    expect(screen.getByText("INV-NE-0001")).toBeTruthy();
    expect(screen.getByText("Compliance Metadata")).toBeTruthy();
    expect(screen.getByText("uuid-value")).toBeTruthy();
  });

  it("renders quote conversion link when a quote has been converted", () => {
    render(
      <DocumentDetail
        document={{
          id: "quote_1",
          organizationId: "org_1",
          contactId: "contact_1",
          contactName: "Al Noor Hospitality",
          quoteNumber: "QUO-NE-0001",
          status: "CONVERTED",
          expiryDate: "2026-04-22T09:00:00.000Z",
          issueDate: "2026-04-12T09:00:00.000Z",
          currencyCode: "SAR",
          subtotal: "900.00",
          taxTotal: "0.00",
          total: "900.00",
          convertedInvoiceId: "inv_99",
          notes: "Converted quote",
          createdAt: "2026-04-12T09:00:00.000Z",
          updatedAt: "2026-04-12T09:00:00.000Z",
          lines: [],
          attachments: []
        }}
        kind="quotes"
        orgSlug="nomad-events"
      />
    );

    expect(screen.getByText("Conversion Result")).toBeTruthy();
    expect(screen.getByText("Open converted invoice draft")).toBeTruthy();
  });
});
