import Link from "next/link";
import React from "react";
import type {
  ContactSummary,
  PurchaseBillDetail,
  PurchaseBillSummary,
  QuoteDetail,
  QuoteSummary,
  SalesInvoiceDetail,
  SalesInvoiceSummary,
  TaxRateRecord
} from "@daftar/types";
import {
  purchaseBillStatuses,
  quoteStatuses,
  salesInvoiceStatuses
} from "@daftar/types";
import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";

import { fetchServerJson } from "../api";
import { SectionNav } from "../week2/section-nav";
import { getCapabilities, hasPermission } from "../week2/route-utils";
import { ActionButton } from "./action-button";
import { DocumentDetail } from "./document-detail";
import { DocumentForm } from "./document-form";
import { PaymentForm } from "./payment-form";
import {
  formatDate,
  money,
  toneForBillStatus,
  toneForComplianceStatus,
  toneForInvoiceStatus,
  toneForQuoteStatus
} from "./shared";

function accountingNav(orgSlug: string, activeKey: "sales" | "purchases" | "quotes") {
  return [
    { href: `/${orgSlug}/accounting/sales`, label: "Sales", active: activeKey === "sales" },
    {
      href: `/${orgSlug}/accounting/purchases`,
      label: "Purchases",
      active: activeKey === "purchases"
    },
    { href: `/${orgSlug}/accounting/quotes`, label: "Quotes", active: activeKey === "quotes" }
  ];
}

function mapTaxRates(taxRates: TaxRateRecord[]) {
  return taxRates.map((taxRate) => ({
    id: taxRate.id,
    label: `${taxRate.name} (${taxRate.rate}%)`
  }));
}

function mapContacts(contacts: ContactSummary[]) {
  return contacts.map((contact) => ({
    id: contact.id,
    label: contact.displayName
  }));
}

function dateInputValue(value: string) {
  return value.slice(0, 10);
}

function lineStateFromDetail(
  detail: SalesInvoiceDetail | PurchaseBillDetail | QuoteDetail
) {
  return detail.lines.map((line) => ({
    description: line.description,
    quantity: line.quantity,
    unitPrice: line.unitPrice,
    taxRateId: line.taxRateId ?? ""
  }));
}

export async function renderWeek3AccountingPage(orgSlug: string, segments: string[]) {
  const pageKey = segments[1];

  if (pageKey === "sales") {
    return renderSalesPage(orgSlug, segments);
  }

  if (pageKey === "purchases") {
    return renderPurchasesPage(orgSlug, segments);
  }

  return renderQuotesPage(orgSlug, segments);
}

async function renderSalesPage(orgSlug: string, segments: string[]) {
  const capabilities = await getCapabilities();
  const canWrite = hasPermission(capabilities, "sales.write");
  const canReport = hasPermission(capabilities, "compliance.report");

  const [invoices, contacts, taxRates] = await Promise.all([
    fetchServerJson<SalesInvoiceSummary[]>("/v1/sales/invoices"),
    fetchServerJson<ContactSummary[]>("/v1/contacts?segment=customers"),
    fetchServerJson<TaxRateRecord[]>("/v1/setup/tax-rates")
  ]);

  const selectedId = segments[2] ?? null;
  const selectedInvoice = selectedId
    ? await fetchServerJson<SalesInvoiceDetail>(`/v1/sales/invoices/${selectedId}`)
    : null;

  return (
    <div className="space-y-6">
      <SectionNav items={accountingNav(orgSlug, "sales")} title="Accounting" />
      <InvoiceListCard invoices={invoices} orgSlug={orgSlug} />
      {selectedInvoice ? (
        <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <DocumentDetail document={selectedInvoice} kind="sales" />
          <div className="space-y-6">
            <DocumentForm
              canWrite={canWrite}
              contacts={mapContacts(contacts)}
              dateFields={[
                { name: "issueDate", label: "Issue Date" },
                { name: "dueDate", label: "Due Date" }
              ]}
              description="Update invoice values, line items, and financial status."
              endpoint={`/v1/sales/invoices/${selectedInvoice.id}`}
              includeComplianceKind
              initialValues={{
                contactId: selectedInvoice.contactId,
                numberValue: selectedInvoice.invoiceNumber,
                status: selectedInvoice.status,
                issueDate: dateInputValue(selectedInvoice.issueDate),
                dueOrExpiryDate: dateInputValue(selectedInvoice.dueDate),
                currencyCode: selectedInvoice.currencyCode,
                notes: selectedInvoice.notes ?? "",
                complianceInvoiceKind: selectedInvoice.complianceInvoiceKind,
                lines: lineStateFromDetail(selectedInvoice)
              }}
              method="PATCH"
              numberField={{ name: "invoiceNumber", label: "Invoice Number" }}
              statusOptions={salesInvoiceStatuses.map((status) => ({
                label: status,
                value: status
              }))}
              submitLabel="Update Invoice"
              taxRates={mapTaxRates(taxRates)}
              title="Edit Invoice"
            />
            <PaymentForm
              canWrite={canWrite}
              defaultAmount={selectedInvoice.amountDue}
              endpoint={`/v1/sales/invoices/${selectedInvoice.id}/payments`}
              title="Add Payment"
            />
            {selectedInvoice.complianceStatus !== "REPORTED" &&
            selectedInvoice.status !== "DRAFT" &&
            selectedInvoice.status !== "VOID" ? (
              <Card>
                <CardHeader>
                  <div className="space-y-1">
                    <h3 className="text-lg font-semibold">Report to ZATCA</h3>
                    <p className="text-sm text-slate-500">
                      Generate Week 3 compliance metadata and create a reported document log entry.
                    </p>
                  </div>
                </CardHeader>
                <CardContent>
                  <ActionButton
                    canWrite={canReport}
                    endpoint={`/v1/compliance/invoices/${selectedInvoice.id}/report`}
                    label="Report Invoice"
                    pendingLabel="Reporting..."
                  />
                </CardContent>
              </Card>
            ) : null}
          </div>
        </div>
      ) : (
        <DocumentForm
          canWrite={canWrite}
          contacts={mapContacts(contacts)}
          dateFields={[
            { name: "issueDate", label: "Issue Date" },
            { name: "dueDate", label: "Due Date" }
          ]}
          description="Create a sales invoice with live line totals and compliance classification."
          endpoint="/v1/sales/invoices"
          includeComplianceKind
          initialValues={{
            contactId: contacts[0]?.id ?? "",
            numberValue: "",
            status: "DRAFT",
            issueDate: "2026-04-12",
            dueOrExpiryDate: "2026-04-27",
            currencyCode: "SAR",
            notes: "",
            complianceInvoiceKind: "STANDARD",
            lines: [{ description: "", quantity: "1", unitPrice: "0.00", taxRateId: "" }]
          }}
          method="POST"
          numberField={{ name: "invoiceNumber", label: "Invoice Number" }}
          redirectTo={(result) => `/${orgSlug}/accounting/sales/${String(result.id)}`}
          statusOptions={salesInvoiceStatuses.map((status) => ({
            label: status,
            value: status
          }))}
          submitLabel="Create Invoice"
          taxRates={mapTaxRates(taxRates)}
          title="New Invoice"
        />
      )}
    </div>
  );
}

async function renderPurchasesPage(orgSlug: string, segments: string[]) {
  const capabilities = await getCapabilities();
  const canWrite = hasPermission(capabilities, "purchases.write");

  const [bills, contacts, taxRates] = await Promise.all([
    fetchServerJson<PurchaseBillSummary[]>("/v1/purchases/bills"),
    fetchServerJson<ContactSummary[]>("/v1/contacts?segment=suppliers"),
    fetchServerJson<TaxRateRecord[]>("/v1/setup/tax-rates")
  ]);

  const selectedId = segments[2] ?? null;
  const selectedBill = selectedId
    ? await fetchServerJson<PurchaseBillDetail>(`/v1/purchases/bills/${selectedId}`)
    : null;

  return (
    <div className="space-y-6">
      <SectionNav items={accountingNav(orgSlug, "purchases")} title="Accounting" />
      <BillListCard bills={bills} orgSlug={orgSlug} />
      {selectedBill ? (
        <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <DocumentDetail document={selectedBill} kind="purchases" />
          <div className="space-y-6">
            <DocumentForm
              canWrite={canWrite}
              contacts={mapContacts(contacts)}
              dateFields={[
                { name: "issueDate", label: "Issue Date" },
                { name: "dueDate", label: "Due Date" }
              ]}
              description="Update supplier bill values and line items."
              endpoint={`/v1/purchases/bills/${selectedBill.id}`}
              initialValues={{
                contactId: selectedBill.contactId,
                numberValue: selectedBill.billNumber,
                status: selectedBill.status,
                issueDate: dateInputValue(selectedBill.issueDate),
                dueOrExpiryDate: dateInputValue(selectedBill.dueDate),
                currencyCode: selectedBill.currencyCode,
                notes: selectedBill.notes ?? "",
                lines: lineStateFromDetail(selectedBill)
              }}
              method="PATCH"
              numberField={{ name: "billNumber", label: "Bill Number" }}
              statusOptions={purchaseBillStatuses.map((status) => ({
                label: status,
                value: status
              }))}
              submitLabel="Update Bill"
              taxRates={mapTaxRates(taxRates)}
              title="Edit Bill"
            />
            <PaymentForm
              canWrite={canWrite}
              defaultAmount={selectedBill.amountDue}
              endpoint={`/v1/purchases/bills/${selectedBill.id}/payments`}
              title="Add Payment"
            />
          </div>
        </div>
      ) : (
        <DocumentForm
          canWrite={canWrite}
          contacts={mapContacts(contacts)}
          dateFields={[
            { name: "issueDate", label: "Issue Date" },
            { name: "dueDate", label: "Due Date" }
          ]}
          description="Create a supplier bill and keep payable balances current."
          endpoint="/v1/purchases/bills"
          initialValues={{
            contactId: contacts[0]?.id ?? "",
            numberValue: "",
            status: "DRAFT",
            issueDate: "2026-04-12",
            dueOrExpiryDate: "2026-04-26",
            currencyCode: "SAR",
            notes: "",
            lines: [{ description: "", quantity: "1", unitPrice: "0.00", taxRateId: "" }]
          }}
          method="POST"
          numberField={{ name: "billNumber", label: "Bill Number" }}
          redirectTo={(result) => `/${orgSlug}/accounting/purchases/${String(result.id)}`}
          statusOptions={purchaseBillStatuses.map((status) => ({
            label: status,
            value: status
          }))}
          submitLabel="Create Bill"
          taxRates={mapTaxRates(taxRates)}
          title="New Bill"
        />
      )}
    </div>
  );
}

async function renderQuotesPage(orgSlug: string, segments: string[]) {
  const capabilities = await getCapabilities();
  const canWrite = hasPermission(capabilities, "quotes.write");
  const canConvert = hasPermission(capabilities, "quotes.convert");

  const [quotes, contacts, taxRates] = await Promise.all([
    fetchServerJson<QuoteSummary[]>("/v1/quotes"),
    fetchServerJson<ContactSummary[]>("/v1/contacts?segment=customers"),
    fetchServerJson<TaxRateRecord[]>("/v1/setup/tax-rates")
  ]);

  const selectedId = segments[2] ?? null;
  const selectedQuote = selectedId
    ? await fetchServerJson<QuoteDetail>(`/v1/quotes/${selectedId}`)
    : null;

  return (
    <div className="space-y-6">
      <SectionNav items={accountingNav(orgSlug, "quotes")} title="Accounting" />
      <QuoteListCard orgSlug={orgSlug} quotes={quotes} />
      {selectedQuote ? (
        <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <DocumentDetail document={selectedQuote} kind="quotes" orgSlug={orgSlug} />
          <div className="space-y-6">
            <DocumentForm
              canWrite={canWrite}
              contacts={mapContacts(contacts)}
              dateFields={[
                { name: "issueDate", label: "Issue Date" },
                { name: "expiryDate", label: "Expiry Date" }
              ]}
              description="Update quote lines and client-facing details."
              endpoint={`/v1/quotes/${selectedQuote.id}`}
              initialValues={{
                contactId: selectedQuote.contactId,
                numberValue: selectedQuote.quoteNumber,
                status: selectedQuote.status,
                issueDate: dateInputValue(selectedQuote.issueDate),
                dueOrExpiryDate: dateInputValue(selectedQuote.expiryDate),
                currencyCode: selectedQuote.currencyCode,
                notes: selectedQuote.notes ?? "",
                lines: lineStateFromDetail(selectedQuote)
              }}
              method="PATCH"
              numberField={{ name: "quoteNumber", label: "Quote Number" }}
              statusOptions={quoteStatuses.map((status) => ({
                label: status,
                value: status
              }))}
              submitLabel="Update Quote"
              taxRates={mapTaxRates(taxRates)}
              title="Edit Quote"
            />
            {selectedQuote.status !== "CONVERTED" ? (
              <Card>
                <CardHeader>
                  <div className="space-y-1">
                    <h3 className="text-lg font-semibold">Convert to Invoice</h3>
                    <p className="text-sm text-slate-500">
                      Create a draft sales invoice from this quote without leaving the Week 3 flow.
                    </p>
                  </div>
                </CardHeader>
                <CardContent>
                  <ActionButton
                    canWrite={canConvert}
                    endpoint={`/v1/quotes/${selectedQuote.id}/convert`}
                    label="Convert Quote"
                    pendingLabel="Converting..."
                    redirectTo={(payload) =>
                      `/${orgSlug}/accounting/sales/${String(payload.invoiceId)}`
                    }
                  />
                </CardContent>
              </Card>
            ) : null}
          </div>
        </div>
      ) : (
        <DocumentForm
          canWrite={canWrite}
          contacts={mapContacts(contacts)}
          dateFields={[
            { name: "issueDate", label: "Issue Date" },
            { name: "expiryDate", label: "Expiry Date" }
          ]}
          description="Create a quote and convert it to an invoice when the customer accepts."
          endpoint="/v1/quotes"
          initialValues={{
            contactId: contacts[0]?.id ?? "",
            numberValue: "",
            status: "DRAFT",
            issueDate: "2026-04-12",
            dueOrExpiryDate: "2026-04-30",
            currencyCode: "SAR",
            notes: "",
            lines: [{ description: "", quantity: "1", unitPrice: "0.00", taxRateId: "" }]
          }}
          method="POST"
          numberField={{ name: "quoteNumber", label: "Quote Number" }}
          redirectTo={(result) => `/${orgSlug}/accounting/quotes/${String(result.id)}`}
          statusOptions={quoteStatuses.map((status) => ({
            label: status,
            value: status
          }))}
          submitLabel="Create Quote"
          taxRates={mapTaxRates(taxRates)}
          title="New Quote"
        />
      )}
    </div>
  );
}

function InvoiceListCard({
  orgSlug,
  invoices
}: {
  orgSlug: string;
  invoices: SalesInvoiceSummary[];
}) {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-1">
          <h2 className="text-xl font-semibold">Sales Invoices</h2>
          <p className="text-sm text-slate-500">
            Real Week 3 invoice data with payment and compliance status.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <DocumentTable
          rows={invoices.map((invoice) => ({
            id: invoice.id,
            href: `/${orgSlug}/accounting/sales/${invoice.id}`,
            number: invoice.invoiceNumber,
            contactName: invoice.contactName,
            issueDate: invoice.issueDate,
            amountDue: money(invoice.amountDue, invoice.currencyCode),
            status: (
              <div className="flex flex-wrap gap-2">
                <StatusBadge
                  label={invoice.status}
                  tone={toneForInvoiceStatus(invoice.status)}
                />
                {invoice.complianceStatus ? (
                  <StatusBadge
                    label={invoice.complianceStatus}
                    tone={toneForComplianceStatus(invoice.complianceStatus)}
                  />
                ) : null}
              </div>
            )
          }))}
        />
      </CardContent>
    </Card>
  );
}

function BillListCard({ orgSlug, bills }: { orgSlug: string; bills: PurchaseBillSummary[] }) {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-1">
          <h2 className="text-xl font-semibold">Purchase Bills</h2>
          <p className="text-sm text-slate-500">
            Supplier bills with payable balances kept current from live data.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <DocumentTable
          rows={bills.map((bill) => ({
            id: bill.id,
            href: `/${orgSlug}/accounting/purchases/${bill.id}`,
            number: bill.billNumber,
            contactName: bill.contactName,
            issueDate: bill.issueDate,
            amountDue: money(bill.amountDue, bill.currencyCode),
            status: (
              <StatusBadge label={bill.status} tone={toneForBillStatus(bill.status)} />
            )
          }))}
        />
      </CardContent>
    </Card>
  );
}

function QuoteListCard({ orgSlug, quotes }: { orgSlug: string; quotes: QuoteSummary[] }) {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-1">
          <h2 className="text-xl font-semibold">Quotes</h2>
          <p className="text-sm text-slate-500">
            Quote flow with conversion into draft invoices.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <DocumentTable
          rows={quotes.map((quote) => ({
            id: quote.id,
            href: `/${orgSlug}/accounting/quotes/${quote.id}`,
            number: quote.quoteNumber,
            contactName: quote.contactName,
            issueDate: quote.issueDate,
            amountDue: money(quote.total, quote.currencyCode),
            status: (
              <StatusBadge label={quote.status} tone={toneForQuoteStatus(quote.status)} />
            )
          }))}
        />
      </CardContent>
    </Card>
  );
}

function DocumentTable({
  rows
}: {
  rows: {
    id: string;
    href: string;
    number: string;
    contactName: string;
    issueDate: string;
    amountDue: string;
    status: React.ReactNode;
  }[];
}) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead>
          <tr className="text-left text-slate-500">
            <th className="px-3 py-2 font-medium">Document</th>
            <th className="px-3 py-2 font-medium">Contact</th>
            <th className="px-3 py-2 font-medium">Date</th>
            <th className="px-3 py-2 font-medium">Amount Due</th>
            <th className="px-3 py-2 font-medium">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((row) => (
            <tr key={row.id}>
              <td className="px-3 py-3">
                <Link
                  className="font-medium text-slate-800 underline underline-offset-4"
                  href={row.href}
                >
                  {row.number}
                </Link>
              </td>
              <td className="px-3 py-3">{row.contactName}</td>
              <td className="px-3 py-3">{formatDate(row.issueDate)}</td>
              <td className="px-3 py-3">{row.amountDue}</td>
              <td className="px-3 py-3">{row.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
