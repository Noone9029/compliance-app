"use client";

import { useRouter } from "next/navigation";
import React, { useMemo, useState, useTransition } from "react";

import { Button, Card, CardContent, CardHeader } from "@daftar/ui";

export function PaymentForm({
  title,
  endpoint,
  canWrite,
  defaultAmount
}: {
  title: string;
  endpoint: string;
  canWrite: boolean;
  defaultAmount: string;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [paymentDate, setPaymentDate] = useState("2026-04-12");
  const [amount, setAmount] = useState(defaultAmount);
  const [method, setMethod] = useState("Bank Transfer");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const apiBaseUrl = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000",
    []
  );

  function submit() {
    setError(null);

    startTransition(async () => {
      const response = await fetch(`${apiBaseUrl}${endpoint}`, {
        method: "POST",
        credentials: "include",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify({
          paymentDate: new Date(`${paymentDate}T10:00:00.000Z`).toISOString(),
          amount,
          method,
          reference: reference || null,
          notes: notes || null
        })
      });

      if (!response.ok) {
        const message = await response.text();
        setError(message || "Unable to record payment.");
        return;
      }

      router.refresh();
      setReference("");
      setNotes("");
    });
  }

  return (
    <Card>
      <CardHeader>
        <div className="space-y-1">
          <h3 className="text-lg font-semibold">{title}</h3>
          <p className="text-sm text-slate-500">
            Post a payment and recalculate the remaining balance.
          </p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <label className="block space-y-2 text-sm">
          <span className="font-medium text-slate-700">Payment Date</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            disabled={!canWrite || isPending}
            onChange={(event) => setPaymentDate(event.target.value)}
            type="date"
            value={paymentDate}
          />
        </label>
        <label className="block space-y-2 text-sm">
          <span className="font-medium text-slate-700">Amount</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            disabled={!canWrite || isPending}
            onChange={(event) => setAmount(event.target.value)}
            type="number"
            value={amount}
          />
        </label>
        <label className="block space-y-2 text-sm">
          <span className="font-medium text-slate-700">Method</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            disabled={!canWrite || isPending}
            onChange={(event) => setMethod(event.target.value)}
            type="text"
            value={method}
          />
        </label>
        <label className="block space-y-2 text-sm">
          <span className="font-medium text-slate-700">Reference</span>
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            disabled={!canWrite || isPending}
            onChange={(event) => setReference(event.target.value)}
            type="text"
            value={reference}
          />
        </label>
        <label className="block space-y-2 text-sm">
          <span className="font-medium text-slate-700">Notes</span>
          <textarea
            className="min-h-20 w-full rounded-md border border-slate-300 px-3 py-2"
            disabled={!canWrite || isPending}
            onChange={(event) => setNotes(event.target.value)}
            value={notes}
          />
        </label>
        {error ? <p className="text-sm text-rose-600">{error}</p> : null}
        <Button disabled={!canWrite || isPending} onClick={submit} type="button">
          {isPending ? "Recording..." : "Record Payment"}
        </Button>
      </CardContent>
    </Card>
  );
}
