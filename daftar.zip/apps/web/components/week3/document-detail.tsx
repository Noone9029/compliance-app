import Link from "next/link";
import React from "react";
import type {
  PurchaseBillDetail,
  QuoteDetail,
  SalesInvoiceDetail
} from "@daftar/types";
import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";

import {
  formatDate,
  money,
  toneForBillStatus,
  toneForComplianceStatus,
  toneForInvoiceStatus,
  toneForQuoteStatus
} from "./shared";

export function DocumentDetail(props: {
  kind: "sales" | "purchases" | "quotes";
  document: SalesInvoiceDetail | PurchaseBillDetail | QuoteDetail;
  orgSlug?: string;
}) {
  if (props.kind === "sales") {
    return <SalesInvoiceDetailView document={props.document as SalesInvoiceDetail} />;
  }

  if (props.kind === "purchases") {
    return <PurchaseBillDetailView document={props.document as PurchaseBillDetail} />;
  }

  return (
    <QuoteDetailView
      document={props.document as QuoteDetail}
      orgSlug={props.orgSlug ?? ""}
    />
  );
}

function SalesInvoiceDetailView({ document }: { document: SalesInvoiceDetail }) {
  return (
    <div className="space-y-6">
      <DocumentHeader
        badges={[
          <StatusBadge
            key="invoice-status"
            label={document.status}
            tone={toneForInvoiceStatus(document.status)}
          />,
          ...(document.complianceStatus
            ? [
                <StatusBadge
                  key="compliance-status"
                  label={document.complianceStatus}
                  tone={toneForComplianceStatus(document.complianceStatus)}
                />
              ]
            : [])
        ]}
        contactName={document.contactName}
        currencyCode={document.currencyCode}
        dueLabel="Due Date"
        dueValue={document.dueDate}
        notes={document.notes}
        number={document.invoiceNumber}
        totals={[
          ["Subtotal", money(document.subtotal, document.currencyCode)],
          ["Tax", money(document.taxTotal, document.currencyCode)],
          ["Total", money(document.total, document.currencyCode)],
          ["Amount Due", money(document.amountDue, document.currencyCode)]
        ]}
      />

      <LinesCard currencyCode={document.currencyCode} lines={document.lines} />
      <PaymentsCard currencyCode={document.currencyCode} payments={document.payments} />
      <AttachmentsCard attachments={document.attachments} />
      <StatusEventsCard events={document.statusEvents} />
      {document.compliance ? <ComplianceCard document={document} /> : null}
    </div>
  );
}

function PurchaseBillDetailView({ document }: { document: PurchaseBillDetail }) {
  return (
    <div className="space-y-6">
      <DocumentHeader
        badges={[
          <StatusBadge
            key="bill-status"
            label={document.status}
            tone={toneForBillStatus(document.status)}
          />
        ]}
        contactName={document.contactName}
        currencyCode={document.currencyCode}
        dueLabel="Due Date"
        dueValue={document.dueDate}
        notes={document.notes}
        number={document.billNumber}
        totals={[
          ["Subtotal", money(document.subtotal, document.currencyCode)],
          ["Tax", money(document.taxTotal, document.currencyCode)],
          ["Total", money(document.total, document.currencyCode)],
          ["Amount Due", money(document.amountDue, document.currencyCode)]
        ]}
      />

      <LinesCard currencyCode={document.currencyCode} lines={document.lines} />
      <PaymentsCard currencyCode={document.currencyCode} payments={document.payments} />
      <AttachmentsCard attachments={document.attachments} />
    </div>
  );
}

function QuoteDetailView({
  document,
  orgSlug
}: {
  document: QuoteDetail;
  orgSlug: string;
}) {
  return (
    <div className="space-y-6">
      <DocumentHeader
        badges={[
          <StatusBadge
            key="quote-status"
            label={document.status}
            tone={toneForQuoteStatus(document.status)}
          />
        ]}
        contactName={document.contactName}
        currencyCode={document.currencyCode}
        dueLabel="Expiry Date"
        dueValue={document.expiryDate}
        notes={document.notes}
        number={document.quoteNumber}
        totals={[
          ["Subtotal", money(document.subtotal, document.currencyCode)],
          ["Tax", money(document.taxTotal, document.currencyCode)],
          ["Total", money(document.total, document.currencyCode)]
        ]}
      />

      <LinesCard currencyCode={document.currencyCode} lines={document.lines} />
      <AttachmentsCard attachments={document.attachments} />

      {document.convertedInvoiceId ? (
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Conversion Result</h3>
          </CardHeader>
          <CardContent>
            <Link
              className="text-sm font-medium text-slate-700 underline underline-offset-4"
              href={`/${orgSlug}/accounting/sales/${document.convertedInvoiceId}`}
            >
              Open converted invoice draft
            </Link>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

function DocumentHeader({
  number,
  contactName,
  dueLabel,
  dueValue,
  currencyCode,
  notes,
  totals,
  badges
}: {
  number: string;
  contactName: string;
  dueLabel: string;
  dueValue: string;
  currencyCode: string;
  notes: string | null;
  totals: [string, string][];
  badges: React.ReactNode[];
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-1">
            <h2 className="text-xl font-semibold">{number}</h2>
            <p className="text-sm text-slate-500">{contactName}</p>
          </div>
          <div className="flex flex-wrap gap-2">{badges}</div>
        </div>
      </CardHeader>
      <CardContent className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-3 text-sm">
          <div>
            <p className="font-medium text-slate-700">Currency</p>
            <p className="text-slate-600">{currencyCode}</p>
          </div>
          <div>
            <p className="font-medium text-slate-700">{dueLabel}</p>
            <p className="text-slate-600">{formatDate(dueValue)}</p>
          </div>
          <div>
            <p className="font-medium text-slate-700">Notes</p>
            <p className="text-slate-600">{notes || "No notes recorded."}</p>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {totals.map(([label, value]) => (
            <SummaryMetric key={label} label={label} value={value} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function LinesCard({
  lines,
  currencyCode
}: {
  lines: {
    id: string;
    description: string;
    quantity: string;
    unitPrice: string;
    taxRateName: string | null;
    taxRatePercent: string;
    lineTotal: string;
  }[];
  currencyCode: string;
}) {
  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold">Line Items</h3>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="px-3 py-2 font-medium">Description</th>
                <th className="px-3 py-2 font-medium">Qty</th>
                <th className="px-3 py-2 font-medium">Unit</th>
                <th className="px-3 py-2 font-medium">Tax</th>
                <th className="px-3 py-2 font-medium">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {lines.map((line) => (
                <tr key={line.id}>
                  <td className="px-3 py-3">{line.description}</td>
                  <td className="px-3 py-3">{line.quantity}</td>
                  <td className="px-3 py-3">{money(line.unitPrice, currencyCode)}</td>
                  <td className="px-3 py-3">
                    {line.taxRateName ? `${line.taxRateName} (${line.taxRatePercent}%)` : "No tax"}
                  </td>
                  <td className="px-3 py-3">{money(line.lineTotal, currencyCode)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function PaymentsCard({
  payments,
  currencyCode
}: {
  payments: {
    id: string;
    paymentDate: string;
    amount: string;
    method: string;
    reference: string | null;
  }[];
  currencyCode: string;
}) {
  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold">Payments</h3>
      </CardHeader>
      <CardContent>
        {payments.length === 0 ? (
          <p className="text-sm text-slate-500">No payments recorded yet.</p>
        ) : (
          <div className="space-y-3">
            {payments.map((payment) => (
              <div
                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 p-3"
                key={payment.id}
              >
                <div>
                  <p className="font-medium text-slate-800">{payment.method}</p>
                  <p className="text-sm text-slate-500">
                    {formatDate(payment.paymentDate)}
                    {payment.reference ? ` • ${payment.reference}` : ""}
                  </p>
                </div>
                <p className="font-semibold text-slate-900">
                  {money(payment.amount, currencyCode)}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function AttachmentsCard({
  attachments
}: {
  attachments: {
    id: string;
    originalFileName: string;
    mimeType: string;
    sizeBytes: number;
    metadata: Record<string, unknown> | null;
  }[];
}) {
  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold">Attachments</h3>
      </CardHeader>
      <CardContent>
        {attachments.length === 0 ? (
          <p className="text-sm text-slate-500">No attachment metadata linked yet.</p>
        ) : (
          <div className="space-y-3">
            {attachments.map((file) => (
              <div
                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 p-3"
                key={file.id}
              >
                <div>
                  <p className="font-medium text-slate-800">{file.originalFileName}</p>
                  <p className="text-sm text-slate-500">
                    {file.mimeType} • {file.sizeBytes.toLocaleString()} bytes
                  </p>
                </div>
                <p className="text-sm text-slate-500">
                  {String(file.metadata?.label ?? "Attachment")}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StatusEventsCard({
  events
}: {
  events: {
    id: string;
    action: string;
    fromStatus: string | null;
    toStatus: string | null;
    message: string | null;
    createdAt: string;
  }[];
}) {
  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold">Status Timeline</h3>
      </CardHeader>
      <CardContent>
        {events.length === 0 ? (
          <p className="text-sm text-slate-500">No status history recorded.</p>
        ) : (
          <div className="space-y-3">
            {events.map((event) => (
              <div className="rounded-lg border border-slate-200 p-3" key={event.id}>
                <p className="font-medium text-slate-800">{event.action}</p>
                <p className="text-sm text-slate-500">
                  {event.fromStatus ?? "Start"} → {event.toStatus ?? "Unchanged"} •{" "}
                  {formatDate(event.createdAt)}
                </p>
                <p className="mt-1 text-sm text-slate-600">
                  {event.message || "No message recorded."}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ComplianceCard({ document }: { document: SalesInvoiceDetail }) {
  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold">Compliance Metadata</h3>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div>
          <p className="font-medium text-slate-700">UUID</p>
          <p className="text-slate-600 break-all">{document.compliance!.uuid}</p>
        </div>
        <div>
          <p className="font-medium text-slate-700">Previous Hash</p>
          <p className="text-slate-600 break-all">
            {document.compliance!.previousHash ?? "Genesis"}
          </p>
        </div>
        <div>
          <p className="font-medium text-slate-700">Current Hash</p>
          <p className="text-slate-600 break-all">{document.compliance!.currentHash}</p>
        </div>
        <div>
          <p className="font-medium text-slate-700">QR Payload</p>
          <p className="text-slate-600 break-all">{document.compliance!.qrPayload}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function SummaryMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-lg font-semibold text-slate-900">{value}</p>
    </div>
  );
}
