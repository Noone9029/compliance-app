import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { DebugSessionPanel } from "./debug-session-panel";

describe("DebugSessionPanel", () => {
  it("renders current session details", () => {
    render(
      <DebugSessionPanel
        capabilities={{ roleKey: "OWNER", permissions: ["shell.home.read"] }}
        currentOrganization={{ id: "org_1", name: "Nomad Events Arabia Limited", slug: "nomad-events" }}
        memberships={[
          {
            id: "mem_1",
            organizationId: "org_1",
            organizationName: "Nomad Events Arabia Limited",
            organizationSlug: "nomad-events",
            roleKey: "OWNER",
            status: "ACTIVE"
          }
        ]}
        session={{
          authenticated: true,
          user: { id: "user_1", email: "owner@daftar.local", fullName: "Daftar Owner" },
          organization: { id: "org_1", name: "Nomad Events Arabia Limited", slug: "nomad-events" },
          membership: { id: "mem_1", roleKey: "OWNER", status: "ACTIVE" }
        }}
      />
    );

    expect(screen.getByText("Authenticated Debug Session")).toBeTruthy();
    expect(screen.getByText(/owner@daftar.local/i)).toBeTruthy();
    expect(screen.getAllByText(/nomad-events/i)).toHaveLength(2);
  });
});
