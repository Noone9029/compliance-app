import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("../api", () => ({
  fetchServerJson: vi.fn(async (endpoint: string) => {
    if (endpoint === "/v1/billing/summary") {
      return {
        stripeCustomerId: "cus_123",
        billingEmail: "finance@example.com",
        subscriptionId: "sub_123",
        planCode: "GROWTH",
        status: "ACTIVE",
        seats: 8,
        currentPeriodStart: "2026-05-01T00:00:00.000Z",
        currentPeriodEnd: "2026-05-31T23:59:59.000Z",
        cancelAtPeriodEnd: false
      };
    }

    return [
      {
        id: "invoice_1",
        organizationId: "org_1",
        stripeSubscriptionId: "sub_123",
        stripeInvoiceId: "in_123",
        invoiceNumber: "SUB-0001",
        status: "paid",
        total: "299.00",
        currencyCode: "USD",
        issuedAt: "2026-05-01T00:00:00.000Z",
        dueAt: "2026-05-05T00:00:00.000Z",
        paidAt: "2026-05-03T00:00:00.000Z",
        hostedInvoiceUrl: null,
        createdAt: "2026-05-01T00:00:00.000Z"
      }
    ];
  })
}));

vi.mock("../week2/route-utils", () => ({
  getCapabilities: vi.fn(async () => ({
    roleKey: "OWNER",
    permissions: ["billing.read", "billing.write"]
  })),
  hasPermission: vi.fn(() => true)
}));

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    push: vi.fn(),
    refresh: vi.fn()
  })
}));

import { renderBillingPage } from "./billing-page";

describe("billing page", () => {
  it("renders the add-ons posture with live subscription metrics", async () => {
    render(await renderBillingPage("nomad-events", ["subscription", "add-ons"]));

    expect(screen.getAllByText("Add-ons").length).toBeGreaterThanOrEqual(2);
    expect(screen.getByText("GROWTH")).toBeTruthy();
    expect(screen.getByText("8")).toBeTruthy();
  });

  it("renders invoice history on the invoices section", async () => {
    render(await renderBillingPage("nomad-events", ["subscription", "invoices"]));

    expect(screen.getByText("Billing Invoices")).toBeTruthy();
    expect(screen.getByText("SUB-0001")).toBeTruthy();
    expect(screen.getByText("paid")).toBeTruthy();
  });
});
