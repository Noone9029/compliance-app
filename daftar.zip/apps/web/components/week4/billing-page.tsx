import React from "react";
import type { BillingInvoiceRecord, BillingSummaryRecord } from "@daftar/types";
import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";

import { fetchServerJson } from "../api";
import { SectionNav } from "../week2/section-nav";
import { getCapabilities, hasPermission } from "../week2/route-utils";
import { formatDate, money } from "../week3/shared";
import { BillingInvoiceForm, BillingSummaryForm } from "./billing-forms";

function subscriptionNav(orgSlug: string, activeKey: string) {
  return [
    { href: `/${orgSlug}/subscription`, label: "Summary", active: activeKey === "summary" },
    { href: `/${orgSlug}/subscription/billing`, label: "Billing", active: activeKey === "billing" },
    { href: `/${orgSlug}/subscription/add-ons`, label: "Add-ons", active: activeKey === "addons" },
    { href: `/${orgSlug}/subscription/invoices`, label: "Invoices", active: activeKey === "invoices" }
  ];
}

export async function renderBillingPage(orgSlug: string, segments: string[]) {
  const section = segments[1] ?? "summary";
  const capabilities = await getCapabilities();
  const canWrite = hasPermission(capabilities, "billing.write");
  const [summary, invoices] = await Promise.all([
    fetchServerJson<BillingSummaryRecord>("/v1/billing/summary"),
    fetchServerJson<BillingInvoiceRecord[]>("/v1/billing/invoices")
  ]);

  return (
    <div className="space-y-6">
      <SectionNav items={subscriptionNav(orgSlug, section)} title="Subscription" />
      {(section === "summary" || section === "billing") ? (
        <BillingSummaryForm
          canWrite={canWrite}
          endpoint="/v1/billing/summary"
          initialValues={{
            stripeCustomerId: summary.stripeCustomerId ?? "",
            billingEmail: summary.billingEmail ?? "",
            subscriptionId: summary.subscriptionId ?? "",
            planCode: summary.planCode ?? "STARTER",
            status: summary.status ?? "TRIALING",
            seats: String(summary.seats || 1),
            currentPeriodStart: summary.currentPeriodStart?.slice(0, 10) ?? "",
            currentPeriodEnd: summary.currentPeriodEnd?.slice(0, 10) ?? "",
            cancelAtPeriodEnd: summary.cancelAtPeriodEnd
          }}
        />
      ) : null}

      {section === "add-ons" ? (
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold">Add-ons</h2>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-3">
            <Metric label="Plan" value={summary.planCode ?? "Not configured"} />
            <Metric label="Seats" value={String(summary.seats)} />
            <Metric
              label="Renewal"
              value={summary.currentPeriodEnd ? formatDate(summary.currentPeriodEnd) : "N/A"}
            />
          </CardContent>
        </Card>
      ) : null}

      {(section === "summary" || section === "invoices") ? (
        <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold">Billing Invoices</h2>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {invoices.map((invoice) => (
                  <div
                    className="rounded-lg border border-slate-200 p-3"
                    key={invoice.id}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium text-slate-800">{invoice.invoiceNumber}</p>
                        <p className="text-sm text-slate-500">
                          {formatDate(invoice.issuedAt)} • {money(invoice.total, invoice.currencyCode)}
                        </p>
                      </div>
                      <StatusBadge label={invoice.status} tone={invoice.status === "paid" ? "success" : "warning"} />
                    </div>
                  </div>
                ))}
                {invoices.length === 0 ? (
                  <p className="text-sm text-slate-500">No billing invoices recorded yet.</p>
                ) : null}
              </div>
            </CardContent>
          </Card>
          <BillingInvoiceForm canWrite={canWrite} endpoint="/v1/billing/invoices" />
        </div>
      ) : null}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">{label}</p>
      <p className="mt-2 text-lg font-semibold text-slate-900">{value}</p>
    </div>
  );
}
