"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";

import type { OrganizationSummary } from "@daftar/types";

export function OrgSwitcher({
  currentOrgSlug,
  organizations
}: {
  currentOrgSlug: string;
  organizations: OrganizationSummary[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [nextOrgSlug, setNextOrgSlug] = useState(currentOrgSlug);
  const apiBaseUrl = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000",
    []
  );

  if (organizations.length <= 1) {
    return null;
  }

  function onChange(orgSlug: string) {
    setNextOrgSlug(orgSlug);

    startTransition(async () => {
      const response = await fetch(`${apiBaseUrl}/v1/organizations/switch`, {
        method: "POST",
        credentials: "include",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify({ orgSlug })
      });

      if (!response.ok) {
        setNextOrgSlug(currentOrgSlug);
        return;
      }

      router.push(`/${orgSlug}`);
      router.refresh();
    });
  }

  return (
    <label className="flex items-center gap-2 text-sm text-slate-600">
      <span className="whitespace-nowrap">Organization</span>
      <select
        className="min-w-44 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
        disabled={isPending}
        onChange={(event) => onChange(event.target.value)}
        value={nextOrgSlug}
      >
        {organizations.map((organization) => (
          <option key={organization.id} value={organization.slug}>
            {organization.name}
          </option>
        ))}
      </select>
    </label>
  );
}
