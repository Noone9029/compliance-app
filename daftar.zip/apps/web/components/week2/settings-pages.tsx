import React from "react";
import type {
  ConnectorAccountRecord,
  ConnectorSyncLogRecord,
  ConnectorSyncPreviewRecord,
  CurrencyRecord,
  CustomOrganizationSettingsRecord,
  EmailTemplateRecord,
  InvoiceSettingsRecord,
  OrganizationTaxDetailRecord,
  TaxRateRecord,
  TrackingCategoryRecord
} from "@daftar/types";
import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";
import { notFound } from "next/navigation";

import { fetchServerJson } from "../api";
import { ResourceManager } from "./resource-manager";
import { SectionNav } from "./section-nav";
import { SettingsHub } from "./settings-hub";
import { SingletonForm } from "./singleton-form";
import { getCapabilities, hasPermission, settingsNav } from "./route-utils";
import { ActionButton } from "../week3/action-button";

export async function renderSettingsPage(orgSlug: string, segments: string[]) {
  if (segments.length === 1) {
    return <SettingsHub orgSlug={orgSlug} />;
  }

  const section = segments[1];
  const capabilities = await getCapabilities();
  const nav = settingsNav(orgSlug, section);
  const canWrite = hasPermission(capabilities, "setup.write");

  if (section === "tax-rates") {
    const taxRates = await fetchServerJson<TaxRateRecord[]>("/v1/setup/tax-rates");

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <ResourceManager
          canWrite={canWrite}
          columns={[
            { label: "Name", render: (item) => item.name },
            { label: "Code", render: (item) => item.code ?? "None" },
            { label: "Rate", render: (item) => `${item.rate}%` },
            { label: "Scope", render: (item) => item.scope },
            {
              label: "Status",
              render: (item) => (
                <div className="flex gap-2">
                  {item.isDefault ? <StatusBadge label="Default" tone="success" /> : null}
                  <StatusBadge
                    label={item.isActive ? "Active" : "Inactive"}
                    tone={item.isActive ? "success" : "warning"}
                  />
                </div>
              )
            }
          ]}
          createPath="/v1/setup/tax-rates"
          description="Maintain organization tax rates used across setup screens."
          emptyState="No tax rates have been created yet."
          fields={[
            { name: "name", label: "Name", type: "text" },
            { name: "code", label: "Code", type: "text" },
            { name: "rate", label: "Rate", type: "number" },
            {
              name: "scope",
              label: "Scope",
              type: "select",
              options: [
                { label: "Sales", value: "SALES" },
                { label: "Purchase", value: "PURCHASE" },
                { label: "Both", value: "BOTH" }
              ]
            },
            { name: "isDefault", label: "Default", type: "checkbox" },
            { name: "isActive", label: "Active", type: "checkbox" }
          ]}
          items={taxRates}
          mapFormToPayload={(form) => ({
            name: form.name,
            code: form.code || null,
            rate: form.rate,
            scope: form.scope,
            isDefault: Boolean(form.isDefault),
            isActive: Boolean(form.isActive)
          })}
          mapItemToForm={(item) => ({
            name: item.name,
            code: item.code ?? "",
            rate: item.rate,
            scope: item.scope,
            isDefault: item.isDefault,
            isActive: item.isActive
          })}
          newItem={{
            name: "",
            code: "",
            rate: "15.00",
            scope: "BOTH",
            isDefault: false,
            isActive: true
          }}
          title="Tax Rates"
          updatePath={(id) => `/v1/setup/tax-rates/${id}`}
        />
      </div>
    );
  }

  if (section === "organisation-tax-details") {
    const taxDetail = await fetchServerJson<OrganizationTaxDetailRecord | null>(
      "/v1/setup/organisation-tax-details"
    );

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <SingletonForm
          canWrite={canWrite}
          description="Store legal registration and tax profile details for the current organization."
          endpoint="/v1/setup/organisation-tax-details"
          fields={[
            { name: "legalName", label: "Legal Name", type: "text" },
            { name: "taxNumber", label: "Tax Number", type: "text" },
            { name: "countryCode", label: "Country Code", type: "text" },
            { name: "taxOffice", label: "Tax Office", type: "text" },
            { name: "registrationNumber", label: "Registration Number", type: "text" },
            { name: "addressLine1", label: "Address Line 1", type: "text" },
            { name: "addressLine2", label: "Address Line 2", type: "text" },
            { name: "city", label: "City", type: "text" },
            { name: "postalCode", label: "Postal Code", type: "text" }
          ]}
          initialValues={{
            legalName: taxDetail?.legalName ?? "",
            taxNumber: taxDetail?.taxNumber ?? "",
            countryCode: taxDetail?.countryCode ?? "SA",
            taxOffice: taxDetail?.taxOffice ?? "",
            registrationNumber: taxDetail?.registrationNumber ?? "",
            addressLine1: taxDetail?.addressLine1 ?? "",
            addressLine2: taxDetail?.addressLine2 ?? "",
            city: taxDetail?.city ?? "",
            postalCode: taxDetail?.postalCode ?? ""
          }}
          title="Organisation Tax Details"
        />
      </div>
    );
  }

  if (section === "tracking") {
    const trackingCategories = await fetchServerJson<TrackingCategoryRecord[]>(
      "/v1/setup/tracking-categories"
    );

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <ResourceManager
          canWrite={canWrite}
          columns={[
            { label: "Name", render: (item) => item.name },
            { label: "Description", render: (item) => item.description ?? "None" },
            {
              label: "Options",
              render: (item) => item.options.map((option) => option.name).join(", ")
            },
            {
              label: "Status",
              render: (item) => (
                <StatusBadge
                  label={item.isActive ? "Active" : "Inactive"}
                  tone={item.isActive ? "success" : "warning"}
                />
              )
            }
          ]}
          createPath="/v1/setup/tracking-categories"
          description="Create internal tracking categories and option sets."
          emptyState="No tracking categories exist yet."
          fields={[
            { name: "name", label: "Name", type: "text" },
            { name: "description", label: "Description", type: "textarea", rows: 3 },
            {
              name: "optionsCsv",
              label: "Options (one per line, optional color after a pipe)",
              type: "textarea",
              rows: 5
            },
            { name: "isActive", label: "Active", type: "checkbox" }
          ]}
          items={trackingCategories}
          mapFormToPayload={(form) => ({
            name: form.name,
            description: form.description || null,
            isActive: Boolean(form.isActive),
            options: String(form.optionsCsv || "")
              .split(/\r?\n/)
              .map((line) => line.trim())
              .filter(Boolean)
              .map((line) => {
                const [name, color] = line.split("|").map((value) => value.trim());
                return {
                  name,
                  color: color || null,
                  isActive: true
                };
              })
          })}
          mapItemToForm={(item) => ({
            name: item.name,
            description: item.description ?? "",
            optionsCsv: item.options
              .map((option) => `${option.name}${option.color ? ` | ${option.color}` : ""}`)
              .join("\n"),
            isActive: item.isActive
          })}
          newItem={{
            name: "",
            description: "",
            optionsCsv: "",
            isActive: true
          }}
          title="Tracking Categories"
          updatePath={(id) => `/v1/setup/tracking-categories/${id}`}
        />
      </div>
    );
  }

  if (section === "currencies") {
    const currencies = await fetchServerJson<CurrencyRecord[]>("/v1/setup/currencies");

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <ResourceManager
          canWrite={canWrite}
          columns={[
            { label: "Code", render: (item) => item.code },
            { label: "Name", render: (item) => item.name },
            { label: "Symbol", render: (item) => item.symbol },
            { label: "Rate", render: (item) => item.exchangeRate },
            {
              label: "Flags",
              render: (item) => (
                <div className="flex gap-2">
                  {item.isBase ? <StatusBadge label="Base" tone="success" /> : null}
                  <StatusBadge
                    label={item.isActive ? "Active" : "Inactive"}
                    tone={item.isActive ? "success" : "warning"}
                  />
                </div>
              )
            }
          ]}
          createPath="/v1/setup/currencies"
          description="Enable currencies and maintain reference exchange rates."
          emptyState="No currencies configured."
          fields={[
            { name: "code", label: "Code", type: "text" },
            { name: "name", label: "Name", type: "text" },
            { name: "symbol", label: "Symbol", type: "text" },
            { name: "exchangeRate", label: "Exchange Rate", type: "number" },
            { name: "isBase", label: "Base Currency", type: "checkbox" },
            { name: "isActive", label: "Active", type: "checkbox" }
          ]}
          items={currencies}
          mapFormToPayload={(form) => ({
            code: String(form.code || "").toUpperCase(),
            name: form.name,
            symbol: form.symbol,
            exchangeRate: form.exchangeRate,
            isBase: Boolean(form.isBase),
            isActive: Boolean(form.isActive)
          })}
          mapItemToForm={(item) => ({
            code: item.code,
            name: item.name,
            symbol: item.symbol,
            exchangeRate: item.exchangeRate,
            isBase: item.isBase,
            isActive: item.isActive
          })}
          newItem={{
            code: "SAR",
            name: "",
            symbol: "SAR",
            exchangeRate: "1.000000",
            isBase: false,
            isActive: true
          }}
          title="Currencies"
          updatePath={(id) => `/v1/setup/currencies/${id}`}
        />
      </div>
    );
  }

  if (section === "invoice-settings") {
    const invoiceSettings = await fetchServerJson<InvoiceSettingsRecord>(
      "/v1/setup/invoice-settings"
    );

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <SingletonForm
          canWrite={canWrite}
          description="Store invoice numbering defaults and footer content."
          endpoint="/v1/setup/invoice-settings"
          fields={[
            { name: "invoicePrefix", label: "Invoice Prefix", type: "text" },
            { name: "defaultDueDays", label: "Default Due Days", type: "number" },
            { name: "footerNote", label: "Footer Note", type: "textarea", rows: 4 },
            { name: "whatsappEnabled", label: "WhatsApp Placeholder Enabled", type: "checkbox" }
          ]}
          initialValues={{
            invoicePrefix: invoiceSettings.invoicePrefix,
            defaultDueDays: String(invoiceSettings.defaultDueDays),
            footerNote: invoiceSettings.footerNote,
            whatsappEnabled: invoiceSettings.whatsappEnabled
          }}
          title="Invoice Settings"
        />
      </div>
    );
  }

  if (section === "email-templates") {
    const emailTemplates = await fetchServerJson<EmailTemplateRecord[]>(
      "/v1/setup/email-templates"
    );

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <ResourceManager
          canWrite={canWrite}
          columns={[
            { label: "Key", render: (item) => item.key },
            { label: "Name", render: (item) => item.name },
            { label: "Subject", render: (item) => item.subject },
            {
              label: "Flags",
              render: (item) => (
                <div className="flex gap-2">
                  {item.isDefault ? <StatusBadge label="Default" tone="success" /> : null}
                  <StatusBadge
                    label={item.isActive ? "Active" : "Inactive"}
                    tone={item.isActive ? "success" : "warning"}
                  />
                </div>
              )
            }
          ]}
          createPath="/v1/setup/email-templates"
          description="Maintain outbound template content used across future flows."
          emptyState="No email templates configured."
          fields={[
            { name: "key", label: "Key", type: "text" },
            { name: "name", label: "Name", type: "text" },
            { name: "subject", label: "Subject", type: "text" },
            { name: "body", label: "Body", type: "textarea", rows: 6 },
            { name: "isDefault", label: "Default", type: "checkbox" },
            { name: "isActive", label: "Active", type: "checkbox" }
          ]}
          items={emailTemplates}
          mapFormToPayload={(form) => ({
            key: form.key,
            name: form.name,
            subject: form.subject,
            body: form.body,
            isDefault: Boolean(form.isDefault),
            isActive: Boolean(form.isActive)
          })}
          mapItemToForm={(item) => ({
            key: item.key,
            name: item.name,
            subject: item.subject,
            body: item.body,
            isDefault: item.isDefault,
            isActive: item.isActive
          })}
          newItem={{
            key: "",
            name: "",
            subject: "",
            body: "",
            isDefault: false,
            isActive: true
          }}
          title="Email Templates"
          updatePath={(id) => `/v1/setup/email-templates/${id}`}
        />
      </div>
    );
  }

  if (section === "custom-organisation-settings") {
    const customSettings = await fetchServerJson<CustomOrganizationSettingsRecord>(
      "/v1/setup/custom-organisation-settings"
    );

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <SingletonForm
          canWrite={canWrite}
          description="Store operational defaults that are organization-specific."
          endpoint="/v1/setup/custom-organisation-settings"
          fields={[
            { name: "defaultLanguage", label: "Default Language", type: "text" },
            { name: "timezone", label: "Timezone", type: "text" },
            { name: "fiscalYearStartMonth", label: "Fiscal Year Start Month", type: "number" },
            { name: "notes", label: "Notes", type: "textarea", rows: 4 }
          ]}
          initialValues={{
            defaultLanguage: customSettings.defaultLanguage,
            timezone: customSettings.timezone,
            fiscalYearStartMonth: String(customSettings.fiscalYearStartMonth),
            notes: customSettings.notes
          }}
          title="Custom Organisation Settings"
        />
      </div>
    );
  }

  if (section === "connector-settings") {
    const [accounts, logs] = await Promise.all([
      fetchServerJson<ConnectorAccountRecord[]>("/v1/connectors/accounts"),
      fetchServerJson<ConnectorSyncLogRecord[]>("/v1/connectors/logs")
    ]);
    const previews = await Promise.all(
      accounts.map((account) =>
        fetchServerJson<ConnectorSyncPreviewRecord>(
          `/v1/connectors/accounts/${account.id}/export-preview`
        ).catch(() => null)
      )
    );
    const previewMap = new Map(
      previews
        .filter((preview): preview is ConnectorSyncPreviewRecord => Boolean(preview))
        .map((preview) => [preview.connectorAccountId, preview])
    );
    const canSync = hasPermission(capabilities, "connectors.sync");

    return (
      <div className="space-y-6">
        <SectionNav items={nav} title="Settings" />
        <ResourceManager
          canWrite={hasPermission(capabilities, "connectors.write")}
          columns={[
            { label: "Provider", render: (item) => item.provider },
            { label: "Display Name", render: (item) => item.displayName },
            { label: "Status", render: (item) => item.status },
            { label: "External Tenant", render: (item) => item.externalTenantId ?? "None" },
            { label: "Scopes", render: (item) => item.scopes.join(", ") || "None" }
          ]}
          createPath="/v1/connectors/accounts"
          description="Maintain connector account metadata and run export previews or sync attempts."
          emptyState="No connector accounts configured."
          fields={[
            {
              name: "provider",
              label: "Provider",
              type: "select",
              options: [
                { label: "Xero", value: "XERO" },
                { label: "QuickBooks Online", value: "QUICKBOOKS_ONLINE" },
                { label: "Zoho Books", value: "ZOHO_BOOKS" }
              ]
            },
            { name: "displayName", label: "Display Name", type: "text" },
            {
              name: "status",
              label: "Status",
              type: "select",
              options: [
                { label: "Pending", value: "PENDING" },
                { label: "Connected", value: "CONNECTED" },
                { label: "Disconnected", value: "DISCONNECTED" },
                { label: "Error", value: "ERROR" }
              ]
            },
            { name: "externalTenantId", label: "External Tenant ID", type: "text" },
            {
              name: "scopesCsv",
              label: "Scopes (comma separated)",
              type: "textarea",
              rows: 4
            }
          ]}
          items={accounts}
          mapFormToPayload={(form) => ({
            provider: form.provider,
            displayName: form.displayName,
            status: form.status,
            externalTenantId: form.externalTenantId || null,
            scopes: String(form.scopesCsv || "")
              .split(",")
              .map((value) => value.trim())
              .filter(Boolean),
            metadata: {}
          })}
          mapItemToForm={(item) => ({
            provider: item.provider,
            displayName: item.displayName,
            status: item.status,
            externalTenantId: item.externalTenantId ?? "",
            scopesCsv: item.scopes.join(", ")
          })}
          newItem={{
            provider: "XERO",
            displayName: "",
            status: "PENDING",
            externalTenantId: "",
            scopesCsv: ""
          }}
          title="Connector Accounts"
          updatePath={(id) => `/v1/connectors/accounts/${id}`}
        />

        <div className="grid gap-6 xl:grid-cols-2">
          {accounts.map((account) => (
            <Card key={account.id}>
              <CardHeader>
                <div className="space-y-1">
                  <h2 className="text-xl font-semibold">{account.displayName}</h2>
                  <p className="text-sm text-slate-500">{account.provider}</p>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  {(previewMap.get(account.id)?.scopes ?? []).map((scope) => (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3" key={scope.scope}>
                      <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">
                        {scope.scope}
                      </p>
                      <p className="mt-2 text-lg font-semibold text-slate-900">
                        {scope.recordCount}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3">
                  <ActionButton
                    canWrite={canSync}
                    endpoint={`/v1/connectors/accounts/${account.id}/sync`}
                    label="Run Export Sync"
                    pendingLabel="Syncing..."
                    body={{ direction: "EXPORT" }}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <div className="space-y-1">
              <h2 className="text-xl font-semibold">Connector Sync Logs</h2>
              <p className="text-sm text-slate-500">
                Export attempts now create retryable logs and provider-specific preview metadata.
              </p>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead>
                  <tr className="text-left text-slate-500">
                    <th className="px-3 py-2 font-medium">Direction</th>
                    <th className="px-3 py-2 font-medium">Scope</th>
                    <th className="px-3 py-2 font-medium">Status</th>
                    <th className="px-3 py-2 font-medium">Message</th>
                    <th className="px-3 py-2 font-medium">Retry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.map((log) => (
                    <tr key={log.id}>
                      <td className="px-3 py-3">{log.direction}</td>
                      <td className="px-3 py-3">{log.scope}</td>
                      <td className="px-3 py-3">
                        <StatusBadge
                          label={log.status}
                          tone={log.status === "SUCCESS" ? "success" : "warning"}
                        />
                      </td>
                      <td className="px-3 py-3 text-slate-700">{log.message ?? "None"}</td>
                      <td className="px-3 py-3">
                        {log.retryable ? (
                          <ActionButton
                            canWrite={canSync}
                            endpoint={`/v1/connectors/logs/${log.id}/retry`}
                            label="Retry"
                            pendingLabel="Retrying..."
                          />
                        ) : (
                          <span className="text-sm text-slate-500">Not needed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {logs.length === 0 ? (
                    <tr>
                      <td className="px-3 py-6 text-slate-500" colSpan={5}>
                        No connector logs recorded.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  notFound();
}
