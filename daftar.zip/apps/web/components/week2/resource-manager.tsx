"use client";

import React, { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";

import { Button, Card, CardContent, CardHeader } from "@daftar/ui";

type FormValue = string | boolean;
type FormState = Record<string, FormValue>;

type ResourceField =
  | {
      name: string;
      label: string;
      type: "text" | "number";
      placeholder?: string;
    }
  | {
      name: string;
      label: string;
      type: "textarea";
      placeholder?: string;
      rows?: number;
    }
  | {
      name: string;
      label: string;
      type: "checkbox";
    }
  | {
      name: string;
      label: string;
      type: "select";
      options: { label: string; value: string }[];
    };

type ResourceColumn<T> = {
  label: string;
  render: (item: T) => React.ReactNode;
};

export function ResourceManager<T extends { id: string }>({
  title,
  description,
  items,
  columns,
  fields,
  emptyState,
  createPath,
  updatePath,
  canWrite,
  createLabel = "Create",
  updateLabel = "Save changes",
  newItem,
  mapItemToForm,
  mapFormToPayload
}: {
  title: string;
  description: string;
  items: T[];
  columns: ResourceColumn<T>[];
  fields: ResourceField[];
  emptyState: string;
  createPath: string;
  updatePath: (id: string) => string;
  canWrite: boolean;
  createLabel?: string;
  updateLabel?: string;
  newItem: FormState;
  mapItemToForm: (item: T) => FormState;
  mapFormToPayload: (form: FormState) => Record<string, unknown>;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(newItem);
  const [error, setError] = useState<string | null>(null);
  const apiBaseUrl = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000",
    []
  );

  const selectedItem = selectedId
    ? items.find((item) => item.id === selectedId) ?? null
    : null;

  function selectItem(item: T | null) {
    if (!item) {
      setSelectedId(null);
      setForm(newItem);
      return;
    }

    setSelectedId(item.id);
    setForm(mapItemToForm(item));
  }

  function updateField(name: string, value: FormValue) {
    setForm((current) => ({
      ...current,
      [name]: value
    }));
  }

  function submit() {
    setError(null);

    startTransition(async () => {
      const endpoint = selectedItem ? updatePath(selectedItem.id) : createPath;
      const method = selectedItem ? "PATCH" : "POST";
      const response = await fetch(`${apiBaseUrl}${endpoint}`, {
        method,
        credentials: "include",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(mapFormToPayload(form))
      });

      if (!response.ok) {
        const message = await response.text();
        setError(message || "Request failed.");
        return;
      }

      setSelectedId(null);
      setForm(newItem);
      router.refresh();
    });
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1.3fr_0.9fr]">
      <Card>
        <CardHeader>
          <div className="space-y-1">
            <h2 className="text-xl font-semibold">{title}</h2>
            <p className="text-sm text-slate-500">{description}</p>
          </div>
        </CardHeader>
        <CardContent>
          {items.length === 0 ? (
            <p className="text-sm text-slate-500">{emptyState}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead>
                  <tr className="text-left text-slate-500">
                    {columns.map((column) => (
                      <th className="px-3 py-2 font-medium" key={column.label}>
                        {column.label}
                      </th>
                    ))}
                    {canWrite ? <th className="px-3 py-2 font-medium">Actions</th> : null}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item) => (
                    <tr key={item.id}>
                      {columns.map((column) => (
                        <td className="px-3 py-3 align-top" key={column.label}>
                          {column.render(item)}
                        </td>
                      ))}
                      {canWrite ? (
                        <td className="px-3 py-3 align-top">
                          <button
                            className="text-sm font-medium text-slate-700 underline underline-offset-4"
                            onClick={() => selectItem(item)}
                            type="button"
                          >
                            Edit
                          </button>
                        </td>
                      ) : null}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="space-y-1">
            <h3 className="text-lg font-semibold">
              {selectedItem ? "Edit record" : "New record"}
            </h3>
            <p className="text-sm text-slate-500">
              {canWrite
                ? "Create and update records directly from the Week 2 setup UI."
                : "Your current role has read-only access."}
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {fields.map((field) => (
            <label className="block space-y-2 text-sm" key={field.name}>
              <span className="font-medium text-slate-700">{field.label}</span>
              {field.type === "textarea" ? (
                <textarea
                  className="min-h-24 w-full rounded-md border border-slate-300 px-3 py-2"
                  disabled={!canWrite || isPending}
                  onChange={(event) => updateField(field.name, event.target.value)}
                  placeholder={field.placeholder}
                  rows={field.rows ?? 4}
                  value={String(form[field.name] ?? "")}
                />
              ) : null}
              {field.type === "text" || field.type === "number" ? (
                <input
                  className="w-full rounded-md border border-slate-300 px-3 py-2"
                  disabled={!canWrite || isPending}
                  onChange={(event) => updateField(field.name, event.target.value)}
                  placeholder={field.placeholder}
                  type={field.type}
                  value={String(form[field.name] ?? "")}
                />
              ) : null}
              {field.type === "select" ? (
                <select
                  className="w-full rounded-md border border-slate-300 px-3 py-2"
                  disabled={!canWrite || isPending}
                  onChange={(event) => updateField(field.name, event.target.value)}
                  value={String(form[field.name] ?? "")}
                >
                  {field.options.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ) : null}
              {field.type === "checkbox" ? (
                <input
                  checked={Boolean(form[field.name])}
                  className="h-4 w-4 rounded border-slate-300"
                  disabled={!canWrite || isPending}
                  onChange={(event) => updateField(field.name, event.target.checked)}
                  type="checkbox"
                />
              ) : null}
            </label>
          ))}

          {error ? <p className="text-sm text-rose-600">{error}</p> : null}

          <div className="flex flex-wrap gap-3">
            <Button disabled={!canWrite || isPending} onClick={submit} type="button">
              {selectedItem ? updateLabel : createLabel}
            </Button>
            {selectedItem ? (
              <button
                className="rounded-md border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700"
                disabled={!canWrite || isPending}
                onClick={() => selectItem(null)}
                type="button"
              >
                Cancel
              </button>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
