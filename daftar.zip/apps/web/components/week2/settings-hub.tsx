import React from "react";

import { Card, CardContent, CardHeader } from "@daftar/ui";

const settingSections = [
  {
    key: "tax-rates",
    label: "Tax Rates",
    description: "Manage sales and purchase tax rates."
  },
  {
    key: "organisation-tax-details",
    label: "Organisation Tax Details",
    description: "Maintain tax registration and address details."
  },
  {
    key: "tracking",
    label: "Tracking",
    description: "Define operational categories and options."
  },
  {
    key: "currencies",
    label: "Currencies",
    description: "Enable currencies and exchange rates."
  },
  {
    key: "invoice-settings",
    label: "Invoice Settings",
    description: "Store invoice prefix, due days, and footer defaults."
  },
  {
    key: "email-templates",
    label: "Email Templates",
    description: "Maintain reusable outbound email content."
  },
  {
    key: "custom-organisation-settings",
    label: "Custom Organisation Settings",
    description: "Track organization-level operational defaults."
  },
  {
    key: "connector-settings",
    label: "Connector Settings",
    description: "Manage connector accounts and view sync logs."
  }
] as const;

export function SettingsHub({ orgSlug }: { orgSlug: string }) {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {settingSections.map((section) => (
        <Card key={section.key}>
          <CardHeader>
            <h2 className="text-lg font-semibold">{section.label}</h2>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-slate-500">{section.description}</p>
            <a
              className="inline-flex text-sm font-medium text-slate-900 underline underline-offset-4"
              href={`/${orgSlug}/settings/${section.key}`}
            >
              Open
            </a>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
