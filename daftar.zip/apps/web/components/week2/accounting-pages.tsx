import React from "react";
import type { AccountRecord, BankAccountRecord } from "@daftar/types";
import { StatusBadge } from "@daftar/ui";

import { fetchServerJson } from "../api";
import { hasPermission, getCapabilities } from "./route-utils";
import { ResourceManager } from "./resource-manager";

export async function renderAccountingSetupPage(
  routeKey: "accounting-bank-accounts" | "accounting-chart-of-accounts"
) {
  if (routeKey === "accounting-bank-accounts") {
    const capabilities = await getCapabilities();
    const bankAccounts = await fetchServerJson<BankAccountRecord[]>(
      "/v1/setup/bank-accounts"
    );

    return (
      <ResourceManager
        canWrite={hasPermission(capabilities, "setup.write")}
        columns={[
          { label: "Name", render: (item) => item.name },
          { label: "Bank", render: (item) => item.bankName },
          { label: "Currency", render: (item) => item.currencyCode },
          { label: "Opening Balance", render: (item) => item.openingBalance },
          {
            label: "Flags",
            render: (item) => (
              <div className="flex gap-2">
                {item.isPrimary ? <StatusBadge label="Primary" tone="success" /> : null}
                <StatusBadge
                  label={item.isActive ? "Active" : "Inactive"}
                  tone={item.isActive ? "success" : "warning"}
                />
              </div>
            )
          }
        ]}
        createPath="/v1/setup/bank-accounts"
        description="Maintain organization bank accounts used by downstream accounting modules."
        emptyState="No bank accounts configured."
        fields={[
          { name: "name", label: "Name", type: "text" },
          { name: "bankName", label: "Bank Name", type: "text" },
          { name: "accountName", label: "Account Name", type: "text" },
          { name: "accountNumberMasked", label: "Account Number", type: "text" },
          { name: "iban", label: "IBAN", type: "text" },
          { name: "currencyCode", label: "Currency Code", type: "text" },
          { name: "openingBalance", label: "Opening Balance", type: "number" },
          { name: "isPrimary", label: "Primary", type: "checkbox" },
          { name: "isActive", label: "Active", type: "checkbox" }
        ]}
        items={bankAccounts}
        mapFormToPayload={(form) => ({
          name: form.name,
          bankName: form.bankName,
          accountName: form.accountName,
          accountNumberMasked: form.accountNumberMasked,
          iban: form.iban || null,
          currencyCode: form.currencyCode,
          openingBalance: form.openingBalance,
          isPrimary: Boolean(form.isPrimary),
          isActive: Boolean(form.isActive)
        })}
        mapItemToForm={(item) => ({
          name: item.name,
          bankName: item.bankName,
          accountName: item.accountName,
          accountNumberMasked: item.accountNumberMasked,
          iban: item.iban ?? "",
          currencyCode: item.currencyCode,
          openingBalance: item.openingBalance,
          isPrimary: item.isPrimary,
          isActive: item.isActive
        })}
        newItem={{
          name: "",
          bankName: "",
          accountName: "",
          accountNumberMasked: "",
          iban: "",
          currencyCode: "SAR",
          openingBalance: "0.00",
          isPrimary: false,
          isActive: true
        }}
        title="Bank Accounts"
        updatePath={(id) => `/v1/setup/bank-accounts/${id}`}
      />
    );
  }

  const capabilities = await getCapabilities();
  const accounts = await fetchServerJson<AccountRecord[]>("/v1/setup/chart-of-accounts");

  return (
    <ResourceManager
      canWrite={hasPermission(capabilities, "setup.write")}
      columns={[
        { label: "Code", render: (item) => item.code },
        { label: "Name", render: (item) => item.name },
        { label: "Type", render: (item) => item.type },
        { label: "Description", render: (item) => item.description ?? "None" },
        {
          label: "Flags",
          render: (item) => (
            <div className="flex gap-2">
              {item.isSystem ? <StatusBadge label="System" tone="warning" /> : null}
              <StatusBadge
                label={item.isActive ? "Active" : "Inactive"}
                tone={item.isActive ? "success" : "warning"}
              />
            </div>
          )
        }
      ]}
      createPath="/v1/setup/chart-of-accounts"
      description="Maintain the Week 2 chart of accounts baseline."
      emptyState="No accounts configured."
      fields={[
        { name: "code", label: "Code", type: "text" },
        { name: "name", label: "Name", type: "text" },
        {
          name: "type",
          label: "Type",
          type: "select",
          options: [
            { label: "Asset", value: "ASSET" },
            { label: "Liability", value: "LIABILITY" },
            { label: "Equity", value: "EQUITY" },
            { label: "Revenue", value: "REVENUE" },
            { label: "Expense", value: "EXPENSE" }
          ]
        },
        { name: "description", label: "Description", type: "textarea", rows: 4 },
        { name: "isSystem", label: "System", type: "checkbox" },
        { name: "isActive", label: "Active", type: "checkbox" }
      ]}
      items={accounts}
      mapFormToPayload={(form) => ({
        code: form.code,
        name: form.name,
        type: form.type,
        description: form.description || null,
        isSystem: Boolean(form.isSystem),
        isActive: Boolean(form.isActive)
      })}
      mapItemToForm={(item) => ({
        code: item.code,
        name: item.name,
        type: item.type,
        description: item.description ?? "",
        isSystem: item.isSystem,
        isActive: item.isActive
      })}
      newItem={{
        code: "",
        name: "",
        type: "ASSET",
        description: "",
        isSystem: false,
        isActive: true
      }}
      title="Chart of Accounts"
      updatePath={(id) => `/v1/setup/chart-of-accounts/${id}`}
    />
  );
}
