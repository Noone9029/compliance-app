"use client";

import React, { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";

import { Button, Card, CardContent, CardHeader } from "@daftar/ui";

type SingletonField =
  | {
      name: string;
      label: string;
      type: "text" | "number";
      placeholder?: string;
    }
  | {
      name: string;
      label: string;
      type: "textarea";
      rows?: number;
      placeholder?: string;
    }
  | {
      name: string;
      label: string;
      type: "checkbox";
    };

type FormState = Record<string, string | boolean>;

export function SingletonForm({
  title,
  description,
  fields,
  initialValues,
  endpoint,
  canWrite,
  submitLabel = "Save"
}: {
  title: string;
  description: string;
  fields: SingletonField[];
  initialValues: FormState;
  endpoint: string;
  canWrite: boolean;
  submitLabel?: string;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [form, setForm] = useState<FormState>(initialValues);
  const [error, setError] = useState<string | null>(null);
  const apiBaseUrl = useMemo(
    () => process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000",
    []
  );

  function updateField(name: string, value: string | boolean) {
    setForm((current) => ({
      ...current,
      [name]: value
    }));
  }

  function submit() {
    setError(null);

    startTransition(async () => {
      const response = await fetch(`${apiBaseUrl}${endpoint}`, {
        method: "PUT",
        credentials: "include",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(form)
      });

      if (!response.ok) {
        setError((await response.text()) || "Request failed.");
        return;
      }

      router.refresh();
    });
  }

  return (
    <Card>
      <CardHeader>
        <div className="space-y-1">
          <h2 className="text-xl font-semibold">{title}</h2>
          <p className="text-sm text-slate-500">{description}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {fields.map((field) => (
          <label className="block space-y-2 text-sm" key={field.name}>
            <span className="font-medium text-slate-700">{field.label}</span>
            {field.type === "textarea" ? (
              <textarea
                className="min-h-24 w-full rounded-md border border-slate-300 px-3 py-2"
                disabled={!canWrite || isPending}
                onChange={(event) => updateField(field.name, event.target.value)}
                placeholder={field.placeholder}
                rows={field.rows ?? 4}
                value={String(form[field.name] ?? "")}
              />
            ) : null}
            {field.type === "text" || field.type === "number" ? (
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2"
                disabled={!canWrite || isPending}
                onChange={(event) => updateField(field.name, event.target.value)}
                placeholder={field.placeholder}
                type={field.type}
                value={String(form[field.name] ?? "")}
              />
            ) : null}
            {field.type === "checkbox" ? (
              <input
                checked={Boolean(form[field.name])}
                className="h-4 w-4 rounded border-slate-300"
                disabled={!canWrite || isPending}
                onChange={(event) => updateField(field.name, event.target.checked)}
                type="checkbox"
              />
            ) : null}
          </label>
        ))}

        {error ? <p className="text-sm text-rose-600">{error}</p> : null}

        <Button disabled={!canWrite || isPending} onClick={submit} type="button">
          {submitLabel}
        </Button>
      </CardContent>
    </Card>
  );
}
