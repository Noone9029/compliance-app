"use client";

import React, { useMemo, useState } from "react";

import type { ContactGroupRecord, ContactSummary } from "@daftar/types";
import { Card, CardContent, CardHeader, StatusBadge } from "@daftar/ui";

import { ContactForm } from "./contact-form";

export function ContactsManager({
  orgSlug,
  title,
  description,
  contacts,
  groups,
  canWrite
}: {
  orgSlug: string;
  title: string;
  description: string;
  contacts: ContactSummary[];
  groups: ContactGroupRecord[];
  canWrite: boolean;
}) {
  const [search, setSearch] = useState("");

  const filteredContacts = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) {
      return contacts;
    }

    return contacts.filter((contact) =>
      [
        contact.displayName,
        contact.companyName,
        contact.email,
        ...contact.groupNames
      ]
        .filter(Boolean)
        .some((value) => value!.toLowerCase().includes(query))
    );
  }, [contacts, search]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="space-y-1">
            <h2 className="text-xl font-semibold">{title}</h2>
            <p className="text-sm text-slate-500">{description}</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <input
            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search contacts, companies, emails, or groups"
            value={search}
          />

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="px-3 py-2 font-medium">Contact</th>
                  <th className="px-3 py-2 font-medium">Type</th>
                  <th className="px-3 py-2 font-medium">Financials</th>
                  <th className="px-3 py-2 font-medium">Groups</th>
                  <th className="px-3 py-2 font-medium">Open</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredContacts.map((contact) => (
                  <tr key={contact.id}>
                    <td className="px-3 py-3">
                      <div className="space-y-1">
                        <p className="font-medium text-slate-900">{contact.displayName}</p>
                        <p className="text-slate-500">{contact.companyName ?? contact.email}</p>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-wrap gap-2">
                        {contact.isCustomer ? (
                          <StatusBadge label="Customer" tone="success" />
                        ) : null}
                        {contact.isSupplier ? (
                          <StatusBadge label="Supplier" tone="warning" />
                        ) : null}
                      </div>
                    </td>
                    <td className="px-3 py-3 text-slate-700">
                      <p>AR: {contact.receivableBalance}</p>
                      <p>AP: {contact.payableBalance}</p>
                    </td>
                    <td className="px-3 py-3 text-slate-700">
                      {contact.groupNames.length > 0 ? contact.groupNames.join(", ") : "None"}
                    </td>
                    <td className="px-3 py-3">
                      <a
                        className="font-medium text-slate-900 underline underline-offset-4"
                        href={`/${orgSlug}/contacts/${contact.id}`}
                      >
                        Detail
                      </a>
                    </td>
                  </tr>
                ))}
                {filteredContacts.length === 0 ? (
                  <tr>
                    <td className="px-3 py-6 text-slate-500" colSpan={5}>
                      No contacts match the current filter.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <ContactForm
        canWrite={canWrite}
        description="Week 2 create flow for contacts, customers, and suppliers."
        endpoint="/v1/contacts"
        groups={groups}
        method="POST"
        submitLabel="Create contact"
        title="New Contact"
      />
    </div>
  );
}
