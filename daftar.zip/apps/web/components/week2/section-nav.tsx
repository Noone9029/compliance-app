import React from "react";

import { Card, CardContent } from "@daftar/ui";

type SectionNavItem = {
  href: string;
  label: string;
  active: boolean;
};

export function SectionNav({
  title,
  items
}: {
  title: string;
  items: SectionNavItem[];
}) {
  return (
    <Card>
      <CardContent className="space-y-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
            {title}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {items.map((item) => (
            <a
              className={
                item.active
                  ? "rounded-full bg-slate-900 px-3 py-2 text-sm font-medium text-white"
                  : "rounded-full bg-slate-100 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-200"
              }
              href={item.href}
              key={item.href}
            >
              {item.label}
            </a>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
