import React from "react";
import { Card, CardContent, CardHeader } from "@daftar/ui";
import type { CapabilitySnapshot, MembershipSummary, OrganizationSummary, SessionSnapshot } from "@daftar/types";

export function DebugSessionPanel({
  session,
  currentOrganization,
  memberships,
  capabilities
}: {
  session: SessionSnapshot;
  currentOrganization: OrganizationSummary | null;
  memberships: MembershipSummary[];
  capabilities: CapabilitySnapshot;
}) {
  return (
    <Card>
      <CardHeader>
        <h2 className="text-xl font-semibold">Authenticated Debug Session</h2>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2">
          <pre className="overflow-auto rounded-lg bg-slate-950 p-4 text-xs text-slate-100">
            {JSON.stringify(session, null, 2)}
          </pre>
          <pre className="overflow-auto rounded-lg bg-slate-950 p-4 text-xs text-slate-100">
            {JSON.stringify(
              {
                currentOrganization,
                memberships,
                capabilities
              },
              null,
              2
            )}
          </pre>
        </div>
      </CardContent>
    </Card>
  );
}
