import React from "react";
import { notFound } from "next/navigation";

import { createServerPlatformClient } from "../../../components/api";
import { DebugSessionPanel } from "../../../components/debug-session-panel";
import { PlaceholderPage } from "../../../components/placeholder-page";
import { resolveTenantRoute } from "../../../components/route-map";
import { renderAccountingSetupPage } from "../../../components/week2/accounting-pages";
import { renderContactsPage } from "../../../components/week2/contacts-pages";
import { renderSettingsPage } from "../../../components/week2/settings-pages";
import { renderWeek3AccountingPage } from "../../../components/week3/accounting-pages";
import { renderChartsPage } from "../../../components/week3/charts-page";
import { renderCompliancePage } from "../../../components/week3/compliance-page";
import { renderReportsPage } from "../../../components/week3/reports-page";
import { renderWeek4AccountingPage } from "../../../components/week4/accounting-pages";
import { renderBillingPage } from "../../../components/week4/billing-page";

export const dynamic = "force-dynamic";

export default async function TenantCatchAllPage({
  params
}: {
  params: Promise<{ orgSlug: string; segments?: string[] }>;
}) {
  const { orgSlug, segments = [] } = await params;

  if (segments[0] === "settings") {
    return renderSettingsPage(orgSlug, segments);
  }

  if (segments[0] === "contacts") {
    return renderContactsPage(orgSlug, segments);
  }

  if (
    segments[0] === "accounting" &&
    ["sales", "purchases"].includes(segments[1] ?? "") &&
    !["credit-notes", "repeating", "orders"].includes(segments[2] ?? "")
  ) {
    return renderWeek3AccountingPage(orgSlug, segments);
  }

  if (
    segments[0] === "accounting" &&
    ((segments[1] === "sales" && ["credit-notes", "repeating"].includes(segments[2] ?? "")) ||
      (segments[1] === "purchases" &&
        ["credit-notes", "orders", "repeating"].includes(segments[2] ?? "")) ||
      segments[1] === "fixed-assets")
  ) {
    return renderWeek4AccountingPage(orgSlug, segments);
  }

  if (
    segments[0] === "accounting" &&
    segments[1] === "quotes"
  ) {
    return renderWeek3AccountingPage(orgSlug, segments);
  }

  if (segments[0] === "e-invoice-integration") {
    return renderCompliancePage(orgSlug);
  }

  if (segments[0] === "reports" && segments.length === 1) {
    return renderReportsPage();
  }

  if (segments[0] === "charts" && segments.length === 1) {
    return renderChartsPage();
  }

  if (segments[0] === "subscription") {
    return renderBillingPage(orgSlug, segments);
  }

  const route = resolveTenantRoute(segments);

  if (!route) {
    notFound();
  }

  if (route.key === "debug-session") {
    const client = await createServerPlatformClient();
    const [session, currentOrganization, memberships, capabilities] = await Promise.all([
      client.session(),
      client.currentOrganization(),
      client.memberships(),
      client.capabilities()
    ]);

    return (
      <DebugSessionPanel
        capabilities={capabilities}
        currentOrganization={currentOrganization}
        memberships={memberships}
        session={session}
      />
    );
  }

  if (
    route.key === "accounting-bank-accounts" ||
    route.key === "accounting-chart-of-accounts"
  ) {
    return renderAccountingSetupPage(route.key);
  }

  return <PlaceholderPage description={route.description} title={route.title} />;
}
