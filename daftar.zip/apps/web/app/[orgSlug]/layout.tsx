import { redirect } from "next/navigation";

import { AppShell } from "@daftar/ui";
import type { CapabilitySnapshot } from "@daftar/types";

import { createServerPlatformClient } from "../../components/api";
import { OrgSwitcher } from "../../components/org-switcher";
import { tenantRoutes } from "../../components/route-map";

export const dynamic = "force-dynamic";

export default async function TenantLayout({
  children,
  params
}: {
  children: React.ReactNode;
  params: Promise<{ orgSlug: string }>;
}) {
  const { orgSlug } = await params;
  const client = await createServerPlatformClient();
  const session = await client.session().catch(() => null);

  if (!session?.authenticated) {
    redirect("/sign-in");
  }

  const capabilities: CapabilitySnapshot = await client
    .capabilities()
    .catch(() => ({ roleKey: null, permissions: [] }));
  const currentOrganization = await client.currentOrganization().catch(() => null);
  const organizations = await client.organizations().catch(() => []);

  if (currentOrganization?.slug && currentOrganization.slug !== orgSlug) {
    redirect(`/${currentOrganization.slug}`);
  }

  const navItems = tenantRoutes
    .filter((route) => route.key !== "debug-session")
    .map((route) => ({
      label: route.title,
      href: route.href(orgSlug),
      visible: capabilities.permissions.includes(route.requiredPermission)
    }));

  return (
    <AppShell
      headerActions={
        currentOrganization ? (
          <OrgSwitcher
            currentOrgSlug={currentOrganization.slug}
            organizations={organizations}
          />
        ) : null
      }
      navItems={navItems}
      orgName={currentOrganization?.name ?? orgSlug}
      orgSlug={orgSlug}
      pageTitle="Daftar"
    >
      {children}
    </AppShell>
  );
}
