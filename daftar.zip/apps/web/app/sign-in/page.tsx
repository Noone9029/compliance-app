"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Button, Card, CardContent, CardHeader } from "@daftar/ui";

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = useState("owner@daftar.local");
  const [password, setPassword] = useState("Password123!");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000"}/v1/auth/sign-in`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "content-type": "application/json"
          },
          body: JSON.stringify({ email, password })
        }
      );

      if (!response.ok) {
        throw new Error("Invalid credentials.");
      }

      const data = (await response.json()) as { organization: { slug: string } | null };
      router.push(`/${data.organization?.slug ?? ""}`);
      router.refresh();
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : "Unable to sign in.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <h1 className="text-2xl font-semibold">Sign in to Daftar</h1>
          <p className="mt-1 text-sm text-slate-500">
            Week 1 platform authentication. Seeded password: <strong>Password123!</strong>
          </p>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={onSubmit}>
            <label className="block space-y-2 text-sm">
              <span>Email</span>
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2"
                onChange={(event) => setEmail(event.target.value)}
                type="email"
                value={email}
              />
            </label>
            <label className="block space-y-2 text-sm">
              <span>Password</span>
              <input
                className="w-full rounded-md border border-slate-300 px-3 py-2"
                onChange={(event) => setPassword(event.target.value)}
                type="password"
                value={password}
              />
            </label>
            {error ? <p className="text-sm text-rose-600">{error}</p> : null}
            <div className="flex items-center justify-between gap-4">
              <a className="text-sm text-slate-500" href="/password/reset-request">
                Forgot password?
              </a>
              <Button disabled={submitting} type="submit">
                {submitting ? "Signing in..." : "Sign in"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </main>
  );
}
