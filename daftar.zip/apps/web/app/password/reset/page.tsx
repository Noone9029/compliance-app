import { PlaceholderPage } from "../../../components/placeholder-page";

export default function ResetPasswordPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl items-center px-6 py-10">
      <div className="w-full">
        <PlaceholderPage
          title="Reset Password"
          description="Week 1 stub page. Credential reset completion is deferred."
        />
      </div>
    </main>
  );
}
