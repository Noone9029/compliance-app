import { PlaceholderPage } from "../../../components/placeholder-page";

export default function ResetRequestPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl items-center px-6 py-10">
      <div className="w-full">
        <PlaceholderPage
          title="Password Reset Request"
          description="Week 1 stub page. External email delivery is intentionally out of scope."
        />
      </div>
    </main>
  );
}
