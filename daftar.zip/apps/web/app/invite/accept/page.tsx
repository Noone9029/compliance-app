import { PlaceholderPage } from "../../../components/placeholder-page";

export default function InviteAcceptPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl items-center px-6 py-10">
      <div className="w-full">
        <PlaceholderPage
          title="Invitation Acceptance"
          description="Week 1 stub only. The API route exists, but external delivery and full invite workflows are deferred."
          todo="Submit a token to the stubbed API endpoint in later slices. No external email delivery is implemented in Week 1."
        />
      </div>
    </main>
  );
}
