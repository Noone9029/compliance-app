import type { Metadata } from "next";

import "./globals.css";

export const metadata: Metadata = {
  title: "Daftar",
  description: "Daftar Week 1 platform foundation"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
