import { Queue } from "bullmq";
import IORedis from "ioredis";

import { loadEnv, queueNames } from "@daftar/config";

async function bootstrap() {
  const env = loadEnv();
  const connection = new IORedis(env.REDIS_URL, {
    maxRetriesPerRequest: null
  });

  const queue = new Queue(queueNames.platform, { connection });

  console.log(
    JSON.stringify({
      app: "daftar-worker",
      status: "ready",
      queue: queue.name
    })
  );
}

bootstrap();
